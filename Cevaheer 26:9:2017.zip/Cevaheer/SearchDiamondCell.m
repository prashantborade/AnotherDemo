//
//  SearchDiamondCell.m
//  Cevaheer App
//
//  Created by   on 27/03/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "SearchDiamondCell.h"

    
@implementation SearchDiamondCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

- (IBAction)btnMessageClicked:(id)sender {
}

- (IBAction)btnCallClicked:(id)sender {
}


@end
