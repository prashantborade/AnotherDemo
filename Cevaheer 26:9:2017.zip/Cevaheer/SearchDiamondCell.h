//
//  SearchDiamondCell.h
//  Cevaheer App
//
//  Created by   on 27/03/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchDiamondCell : UITableViewCell

@property ( weak) IBOutlet UILabel *lblShapeValue;

@property ( weak) IBOutlet UILabel *lblCaratValue;

@property (weak) IBOutlet UILabel *lblColorValue;

@property ( weak) IBOutlet UILabel *lblClarityValue;

@property ( weak) IBOutlet UILabel *lblLabValue;

@property ( weak) IBOutlet UILabel *lblDiscountValue;

@property ( weak) IBOutlet UILabel *lblCutValue;

@property ( weak) IBOutlet UILabel *lblTabValue;

@property ( weak) IBOutlet UILabel *lblListValue;

@property ( weak) IBOutlet UILabel *lblPolValue;

@property ( weak) IBOutlet UILabel *lblDepValue;

@property ( weak) IBOutlet UILabel *lblPcValue;

@property ( weak) IBOutlet UILabel *lblSymValue;

@property (weak) IBOutlet UILabel *lblMesValue;

@property ( weak) IBOutlet UILabel *lblTtlValue;

@property (weak) IBOutlet UILabel *lblMCValue;

@property (weak) IBOutlet UILabel *lblStkValue;

@property (weak) IBOutlet UILabel *lblSlrValue;

@property ( weak) IBOutlet UILabel *lblFlorValue;

@property (weak) IBOutlet UILabel *lblLocValue;

@property (weak) IBOutlet UILabel *lblSelStkValu;

@property ( weak) IBOutlet UIButton *btnMessage;

@property ( weak) IBOutlet UIButton *btnCall;

- (IBAction)btnMessageClicked:(id)sender;

- (IBAction)btnCallClicked:(id)sender;
@end
