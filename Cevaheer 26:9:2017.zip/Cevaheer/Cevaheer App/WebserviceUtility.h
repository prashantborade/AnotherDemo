//
//  WebserviceUtility.h
//  DDEBBIE passenger
//
//  Created by Admin on 19/02/16.
//  Copyright © 2016 appsplanet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JsonUtils.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h" 

@interface WebserviceUtility : NSObject{
id localCopy; // to avoid exec_bad_access with arc
ASIHTTPRequest *getRequest;
ASIFormDataRequest *postRequest;
}

@property (nonatomic, retain) id delegate;
@property (nonatomic, readwrite) SEL callback;
@property (nonatomic, readwrite) SEL errorCallback;


- (void)performPostRequestWithString:(NSString *)string stringDictionary:(NSDictionary *)stringParam dataDictionary:(NSDictionary *)dataDictionary delegate:(id)requestDelegate requestSelector:(SEL)requestSelector errorSelector:(SEL)errorSelector auth:(BOOL)authorization reqType:(NSString*)type;
- (void)performPostRequestForURL:(NSString *)string stringDictionary:(NSDictionary *)stringDictionary dataDictionary:(NSDictionary *)dataDictionary delegate:(id)requestDelegate requestSelector:(SEL)requestSelector errorSelector:(SEL)errorSelector auth:(BOOL)authorization reqType:(NSString*)type;

@end
