//
//  WebServices.m
//  WeddSource
//
//  Created by appsplanet on 10/31/15.
//  Copyright (c) 2015 AppsPlanet. All rights reserved.
//

#import "WebServices.h"

#import <UIKit/UIKit.h>

#import "SVProgressHUD.h"
#import "Reachability.h"



@implementation WebServices
{
    
}
//+ (NSString *)getUrl
//{
//    NSString * urlString =(NSString *)mainUrl;
//    return urlString;
//}

+(void)getDataFromServer:(SEL)strSelector target:(id)class withParameter:(NSString *)parameter
{
    NSString* webStringURL = [[NSString stringWithFormat:@"%@",parameter] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL* url = [NSURL URLWithString:webStringURL];
    NSLog(@"URL : %@",url);
    
    if ([WebServices checkForNetwork]) {
        dispatch_async(kBgQueue, ^{
            
            NSData* data = [NSData dataWithContentsOfURL:url];
            
            [class performSelectorOnMainThread:strSelector withObject:data waitUntilDone:YES];
            
        });
        

    }
    else
    {
        [SVProgressHUD dismiss];
        //[Constant showAlert:[Alerts alertForNetWorkError]];
    }
}
//Syncronus Call
//+(void)getDataFromServersync:(SEL)strSelector target:(id)class withParameter:(NSString *)parameter
//{
//    NSString* webStringURL = [[NSString stringWithFormat:@"%@%@",mainUrl,parameter] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSURL* url = [NSURL URLWithString:webStringURL];
//    
//    if ([WebServices checkForNetwork]) {
//        dispatch_sync(kBgQueue, ^{
//            
//            NSData* data = [NSData dataWithContentsOfURL:url];  
//            [class performSelectorOnMainThread:strSelector withObject:data waitUntilDone:YES];
//            //NSThread *th = [[NSThread alloc]initWithTarget:nil selector:strSelector object:data];
//            //[NSThread detachNewThreadSelector: strSelector toTarget:nil withObject:data];
//        });
//    }
//    else
//    {
//        
//    }
//}

+ (BOOL)checkForNetwork
{
    // check if we've got network connectivity
    Reachability *myNetwork = [Reachability reachabilityWithHostName:@"google.com"];
    NetworkStatus myStatus = [myNetwork currentReachabilityStatus];
    
    switch (myStatus) {
        case NotReachable:
            NSLog(@"There's no internet connection at all. Display error message now.");
            return NO;
            break;
        case ReachableViaWiFi:
        {
            NSLog(@"The internet is working via WIFI.");
            return YES;
            
            break;
        }
        case ReachableViaWWAN:
        {
            NSLog(@"The internet is working via WWAN.");
            return YES;
            break;
        }
        default:
            break;
    }
    return NO;
}


@end
