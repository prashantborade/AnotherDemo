//
//  ColorCodes.h
//  Cevaheer App
//
//  Created by   on 12/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#ifndef ColorCodes_h
#define ColorCodes_h


#define APP_GREY_COLOR @"#eaebeb"
#define APP_BLUE_COLOR @"#0087be"


#endif /* ColorCodes_h */
