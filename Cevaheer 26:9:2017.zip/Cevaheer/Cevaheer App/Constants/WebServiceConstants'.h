//
//  WebServiceConstants'.h
//  Cevaheer App
//
//  Created by  on 28/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#ifndef WebServiceConstants__h
#define WebServiceConstants__h

#define BASE_URL @"http://webservice.cevaheer.com/api/"

#define BASE_URL2 @"http://webservice.cevaheer.flexsin.in/api/"


#define LOGIN_URL BASE_URL @"Login?"

#define SIGN_UP_URL BASE_URL @"SignUp?"

#define FIND_PEOPLE BASE_URL @"FindPeople?"

#define RECIVE_MESSAGE BASE_URL @"ReceivedMessage?"

#define SENT_MESSAGE BASE_URL @"SentMessage?"

#define SEND_MESSAGE BASE_URL @"SendMessage?"

#define ACCOUNT_SETTING BASE_URL @"ProfileInformation?"

#define WELCOME BASE_URL @"ProfileInformation?"

#define ACCOUNT_SETTING_EDIT BASE_URL @"AccountSettingEdit?"

#define FORGOT_PAASWORD BASE_URL @"ForgotPassword?"

#define EDIT_USER_PROFILE BASE_URL @"EditUserProfile?"

#define DELETE_SENT_MESSAGE BASE_URL @"DeleteSentMessage?"

#define DELETE_RECEIVE_MESSAGE BASE_URL @"DeleteReceivedMessage?"

#define FIND_PEOPLE2 BASE_URL @"FindPeople?"

#define PRICE_LIST BASE_URL @"CalculatePrice?"

#define CHANGE_PASSWORD BASE_URL @"ChangePassword?"

#define GET_BUSSINESSTYPE BASE_URL @"Businesstype?"

#define GET_COUNTRYLIST BASE_URL @"CountryList?"

#define MY_LISTING BASE_URL @"MyListing?"

#define SEARCH_DIAMOND_RESULT BASE_URL @"NormalSearch?"

#define SEARCH_DIAMOND_RESULT_SORTING BASE_URL @"NormalSearch?"

#define GET_PRICE_LIST BASE_URL @"DiamondPriceList/GetPriceList"

#define GET_BUYERS_EMAIL BASE_URL2 @"EmailAddress/buyers"

#define GET_SUPLIERS_EMAIL BASE_URL2 @"EmailAddress/supplier"


#define GET_BANER_AD BASE_URL @"Banner?"

#endif /* WebServiceConstants__h */
