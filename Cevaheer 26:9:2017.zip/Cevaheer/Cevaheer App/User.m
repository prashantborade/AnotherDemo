//
//  User.m
//  Cevaheer App
//
//  Created by SMS Systems on 11/22/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "User.h"

@implementation User

@end
