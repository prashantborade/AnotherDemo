//
//  JsonUtils.h
//  ComboTrip
//
//  Created by Swapnil Deshmukh on 03/06/15.
//  Copyright (c) 2015 Appsplanet. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JsonUtils : NSObject

+(NSString *)getJSONfromDictinory:(NSDictionary *)dic;
+(NSArray *)getJSONfromString:(NSString *)str;

@end
