//
//  JsonUtils.m
//  ComboTrip
//
//  Created by Swapnil Deshmukh on 03/06/15.
//  Copyright (c) 2015 Appsplanet. All rights reserved.
//

#import "JsonUtils.h"

@implementation JsonUtils

+(NSString *)getJSONfromDictinory:(NSDictionary *)dic
{
    NSError * error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
        return jsonString;
    }

    return nil;
}

+(NSArray *)getJSONfromString:(NSString *)str
{
    NSError * error;
    NSArray *jsonObject = [NSJSONSerialization JSONObjectWithData:[str dataUsingEncoding:NSUTF8StringEncoding]
                                                          options:0 error:&error];
    return jsonObject;
}
@end
