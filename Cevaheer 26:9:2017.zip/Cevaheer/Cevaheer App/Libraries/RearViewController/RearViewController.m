/*
 
 Copyright (c) 2013 Joan Lluch <joan.lluch@sweetwilliamsl.com>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is furnished
 to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
 */

#import "RearViewController.h"
#import "SWRevealViewController.h"
#import "WelcomeViewController.h"


@interface RearViewController()
{
    NSInteger _presentedRow;
}

@end

@implementation RearViewController

@synthesize rearTableView = _rearTableView;


- (void)viewDidLoad
{
    [super viewDidLoad];
     
    _rearTableView.tableFooterView=[UIView new];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    SWRevealViewController *parentRevealController = self.revealViewController;
    SWRevealViewController *grandParentRevealController = parentRevealController.revealViewController;
    
    
    if ( grandParentRevealController )
    {
        NSInteger level=0;
        UIViewController *controller = grandParentRevealController;
        while( nil != (controller = [controller revealViewController]) )
            level++;
        
    }
    
    parentRevealController.view.backgroundColor=[UIColor colorWithHexString:APP_GREY_COLOR];
    grandParentRevealController.view.backgroundColor=[UIColor colorWithHexString:APP_GREY_COLOR];
     
    self.navigationController.navigationBarHidden = TRUE;
    
    arrayOfTitles = [[NSMutableArray alloc]initWithObjects:NSLocalizedString(@"HOME", @"HOME"),
                                NSLocalizedString(@"ACCOUNT_SETTINGS", @"account settings"), NSLocalizedString(@"MESSAGE", @"messages"),NSLocalizedString(@"FIND_DIAMONDS", @"Find diamonds") , NSLocalizedString(@"CALCULATOR", @"Calculator") ,NSLocalizedString(@"FIND_PEOPLE", @"find diamonds"),NSLocalizedString(@"LOGOUT", @"Logout"), nil];
    
    
    
    arrayOfImages = [[NSMutableArray alloc]initWithObjects:
                                      @"home_uncolor",
                                      @"setting",
                                      @"message",
                                      @"diamond",
                                      @"calculator",
                                      @"profile",@"logout",
                                      nil];
    
    
    [self.view setBackgroundColor:[UIColor colorWithHexString:APP_GREY_COLOR]];
    [self.rearTableView setBackgroundColor:[UIColor colorWithHexString:APP_GREY_COLOR]];
    
    //  lbl_header.text = @"Home";
    
    //lbl_header.text = [[NSUserDefaults standardUserDefaults]objectForKey:@"navigationFrom"];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    SWRevealViewController *grandParentRevealController = self.revealViewController.revealViewController;
    [self.view addGestureRecognizer: self.revealViewController.panGestureRecognizer];
    grandParentRevealController.bounceBackOnOverdraw = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    SWRevealViewController *grandParentRevealController = self.revealViewController.revealViewController;
    grandParentRevealController.bounceBackOnOverdraw = NO;
}


#pragma marl - UITableView Data Source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayOfTitles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"RearViewTableViewCell";
    
    
    RearViewTableViewCell *cell=(RearViewTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
   if(cell == nil)
    {
        cell = [[RearViewTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.titleLblOutlet.text=[arrayOfTitles objectAtIndex:indexPath.row];
    cell.imageViewoutlet.image=[UIImage imageNamed:[arrayOfImages objectAtIndex:indexPath.row]];
    
    [cell.contentView setBackgroundColor:[UIColor colorWithHexString:APP_GREY_COLOR]];
    
 //   cell.contentView.backgroundColor=[UIColor colorWithHexString:@"#ff0000"];
    [cell setLayoutMargins:UIEdgeInsetsZero];
    [cell setSeparatorInset:UIEdgeInsetsZero];
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Grab a handle to the reveal controller, as if you'd do with a navigtion controller via self.navigationController.
    SWRevealViewController *revealController = self.revealViewController;
    
    // selecting row
    
//    
//    [[NSUserDefaults standardUserDefaults]setObject:[arrayOfNavigationScreen objectAtIndex:indexPath.row] forKey:@"navigationFrom"];
   
    /*
     ACCOUNT SETTINGS - 0
     MESSAGE - 1
     FIND DAIMONDS - 2
     CALCULATOR - 3
     FIND PEOPLE - 4
     MY LISTINGS - 5
     LOGOUT - 6
     
     */
    //
    UIViewController *newFrontController = nil;
    if(indexPath.row == 0)
    {
        WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    
        newFrontController = [[UINavigationController alloc] initWithRootViewController:WelcomeVC];
        
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        //_presentedRow = row;  // <- store the presented row
        
    }
    else if(indexPath.row == 1)
    {
        WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
        
        MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
//        
//        AccountSetting *AccountSettingVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"AccountSetting"];
        //[self.navigationController pushViewController:mEquipmentController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:MemberProfileVC];
        
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        //_presentedRow = row;  // <- store the presented row
        
    }
    else if(indexPath.row == 2)
    {
        Messages *MessagesVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"Messages"];
        // [self.navigationController pushViewController:mCompanySearchController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:MessagesVC];
        
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        //_presentedRow = row;  // <- store the presented row
    }
    else if(indexPath.row == 3)
    {
        FindDiamond *FindDiamondVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"FindDiamond"];
        //[self.navigationController pushViewController:mEquipmentController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:FindDiamondVC];
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        // _presentedRow = row;  // <- store the presented row
    }

    //FindDiamond
    else if(indexPath.row == 4)
    {
        Calculator *CalculatorVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"Calculator"];
        //[self.navigationController pushViewController:mEquipmentController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:CalculatorVC];
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        // _presentedRow = row;  // <- store the presented row
    }
    else if(indexPath.row == 5)
    {
        FindPeople *FindPeopleVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"FindPeople"];
        //[self.navigationController pushViewController:mEquipmentController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:FindPeopleVC];
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];
        
        // _presentedRow = row;  // <- store the presented row
    }
//
    else if(indexPath.row == 6)
    {
        
        
        [Constant setIsAlreadyLogin:NO];
        LoginViewController *LoginVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"LoginViewController"];
        // [self.navigationController pushViewController:mSettingController animated:YES];
        
        newFrontController = [[UINavigationController alloc] initWithRootViewController:LoginVC];
        
        revealController.navigationController.navigationBarHidden=YES;
        [revealController pushFrontViewController:newFrontController animated:YES];

//        MyListings *MyListingsVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"MyListings"];
//        // [self.navigationController pushViewController:mSettingController animated:YES];
//        
//        
//        newFrontController = [[UINavigationController alloc] initWithRootViewController:MyListingsVC];
//        
//        revealController.navigationController.navigationBarHidden=YES;
//        [revealController pushFrontViewController:newFrontController animated:YES];
//        
        // _presentedRow = row;  // <- store the presented row
        
    }
//    else if(indexPath.row == 6)
//    {
//        [Constant setIsAlreadyLogin:NO];
//        LoginViewController *LoginVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"LoginViewController"];
//        // [self.navigationController pushViewController:mSettingController animated:YES];
//        
//        newFrontController = [[UINavigationController alloc] initWithRootViewController:LoginVC];
//        
//        revealController.navigationController.navigationBarHidden=YES;
//        [revealController pushFrontViewController:newFrontController animated:YES];
//        
//        //_presentedRow = row;  // <- store the presented row
//        
//    }
    
}

- (IBAction)menu_btn_click:(id)sender {
    
    
    self.navigationController.navigationBarHidden = TRUE;
    
    SWRevealViewController *revealController = self.revealViewController;
    [revealController setFrontViewPosition:FrontViewPositionLeft animated:YES];
    return;
    
}
@end