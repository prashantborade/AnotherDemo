//
//  RearViewTableViewCell.h
//  Cevaheer App
//
//  Created by   on 14/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RearViewTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageViewoutlet;

@property (strong, nonatomic) IBOutlet UILabel *titleLblOutlet;

@end
