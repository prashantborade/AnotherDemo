//
//  JSONUtility.h
//  ; By
//
//  Created by AppsPlanet on 18/06/16.
//  Copyright © 2016 AppsPlanet. All rights reserved.
//

#import "JSONModel.h"
#import "response.h"
#import "Result.h"
#import "MessageResult.h"
#import "User.h"


@interface JSONUtility : JSONModel
@property (nonatomic,assign) NSString <Optional>*Statuscode;
@property (nonatomic,assign) NSString <Optional>*Message;
@property (nonatomic,assign) NSDictionary <Optional>*Result;
@property(nonatomic,strong) NSArray<Optional>*User;


@property (nonatomic,assign) NSString <Optional>*Email;
@property (nonatomic,strong) NSString <Optional>*Password;
@property (nonatomic,strong) NSString <Optional>*FirstName;
@property (nonatomic,strong) NSString <Optional>*LastName;
@property (nonatomic,strong) NSString <Optional>*Community;
@property (nonatomic,strong) NSString <Optional>*CustID;
@property (nonatomic,strong) NSArray <Optional>*subjects;
@property (nonatomic,strong) NSString <Optional>*Subject;
@property (nonatomic,strong) NSArray <Optional>*subject_id_list;
@property (nonatomic,strong) NSArray <Optional>*verse_id_list;
@property (nonatomic,strong) NSArray <Optional>*verse_list;
@property (nonatomic,strong) NSArray <Optional>*subject_ids;
@property (nonatomic,strong) NSArray <Optional>*verse_detailed_list;
@property (nonatomic,strong) NSArray <Optional>*favorite_list;
@property (nonatomic,strong) NSString <Optional>*content_name;
@property (nonatomic,strong) NSString <Optional>*content;
@property (nonatomic,strong) NSString <Optional>*quick_start_content;


@end
