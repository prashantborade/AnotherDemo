//
//  Result.h
//  Cevaheer App
//
//  Created by   on 28/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "JSONModel.h"

@interface Result : JSONModel

@property (strong,nonatomic) NSString <Optional>*CompanyName;
@property (strong,nonatomic) NSString <Optional>*EmailAddress;
@property (strong,nonatomic) NSString <Optional>*UserId;
@property(nonatomic,strong) NSArray<Optional>*User;

@end
