//
//  UpdateProfile.h
//  Cevaheer App
//
//  Created by  on 10/3/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebserviceClass.h"

@interface UpdateProfile : UIViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *strUserId;
    NSString *strEmail;
    int flag;
    
}

#pragma mark - Outlets

@property (weak, nonatomic) IBOutlet UIButton *btnUploadPhoto;
@property (strong, nonatomic) IBOutlet UITextField *txtFirstName;
@property (strong, nonatomic) IBOutlet UITextField *txtLastName;
@property (strong, nonatomic) IBOutlet UITextField *txtCompName;
@property (strong, nonatomic) IBOutlet UITextField *txtCompType;
@property (strong, nonatomic) IBOutlet UITextField *txtCevaheerId;
@property (strong, nonatomic) IBOutlet UITextField *txtLocation;
@property (strong, nonatomic) IBOutlet UITextField *txtCountry;
@property (strong, nonatomic) IBOutlet UITextField *txtState;
@property (strong, nonatomic) IBOutlet UITextField *txtCity;
@property (strong, nonatomic) IBOutlet UITextField *txtTelephone;
@property (strong, nonatomic) IBOutlet UITextField *txtDiamondCount;
@property (strong, nonatomic) IBOutlet UITextField *txtWebsite;
@property(nonatomic,strong) NSMutableArray *jsonArray;

#pragma mark - IBAction

- (IBAction)btnUploadPhotoClicked:(id)sender;
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

@end
