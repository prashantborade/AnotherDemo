//
//  Messages.m
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "Messages.h"
#import "MessageDetails.h"

@interface Messages ()

@end
#pragma mark - Lifecycle
@implementation Messages

- (void)viewDidLoad {
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [self.navigationItem setHidesBackButton:YES];
    
    _searBar.delegate=self;
    _searBar.enablesReturnKeyAutomatically=NO;
    flag=0;

    // _searchBar.delegate = self;

    _jsonArrayRecived=[[NSMutableArray alloc] init];
    _jsonArraySentMessage=[[NSMutableArray alloc] init];
    
    webserviceClass=[[WebserviceClass alloc]init];

    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _emailAddress =[defaults valueForKey:@"EmailAddress"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];
    
     self.screenName=@"Message";
    
}

#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    if (flag == 0) {
        
        if (isFiltered) {
            
            return [filteredReciveArray count];
     
        }
        else{
             return _jsonArrayRecived.count;
        }
       
    }
    else{
        
        if (isFiltered) {
        
            return [filteredSentArray count];
            
        }
        else{
            return _jsonArraySentMessage.count;
        }
        
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        static NSString *cellIdentifier = @"MessageCell";
        
        MessageCell *cell = (MessageCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[MessageCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        
        if (flag == 0) {
            
            if (!isFiltered) {
                
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                
                
                @try {
                    
                    NSString *strUserName=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
                    
                    if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                        cell.lblUserName.text=@"";
                        
                    }
                    else
                    {
                        cell.lblUserName.text=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
                    }
                    
                }
                @catch (NSException *exception) {
                    
                    NSLog(@"Exeception =%@",exception);
                }
                
                
                @try {
                    
                    NSString *strSubject=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                    
                    if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                        cell.lblSubject.text=@"";
                        
                    }
                    else
                    {
                        cell.lblSubject.text=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                    }
                    
                }
                @catch (NSException *exception) {
                    
                    NSLog(@"Exeception =%@",exception);
                }
                
                
                @try {
                    
                    NSString *strMessageContente=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Body"];
                    
                    if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                        cell.lblMessageContent.text=@"";
                        
                    }
                    else
                    {
                        cell.lblMessageContent.text=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Body"];
                    }
                    
                }
                @catch (NSException *exception) {
                    
                    NSLog(@"Exeception =%@",exception);
                }
                
                @try {
                    
                    NSString *FromEmail=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
                    
                    if (FromEmail ==(id)[NSNull null] || [FromEmail isEqualToString:@""] || FromEmail==nil || [FromEmail length]==0) {
                        _strFromEmail=@"";
                        
                    }
                    else
                    {
                        _strFromEmail=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
                    }
                    
                }
                @catch (NSException *exception) {
                    
                    NSLog(@"Exeception =%@",exception);
                }

                
            }
            else{ // isfiltered
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                
                NSString *strUserName=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
                
                if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                    cell.lblUserName.text=@"";
                    
                }
                else
                {
                    cell.lblUserName.text=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
                }
                
                NSString *strSubject=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                
                if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                    cell.lblSubject.text=@"";
                    
                }
                else
                {
                    cell.lblSubject.text=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                }
                
                
                NSString *strMessageContente=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
                
                if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                    cell.lblMessageContent.text=@"";
                    
                }
                else
                {
                    cell.lblMessageContent.text=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
                }
            }
            
        }
        else if(flag == 1){ // flag
            
            if (!isFiltered) {
                
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                
                NSString *strUserName=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
                
                if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                    cell.lblUserName.text=@"";
                    
                }
                else
                {
                    cell.lblUserName.text=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
                }
                
                NSString *strSubject=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                
                if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                    cell.lblSubject.text=@"";
                    
                }
                else
                {
                    cell.lblSubject.text=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                }

                
                
                NSString *strMessageContente=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Body"];
                
                if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                    cell.lblMessageContent.text=@"";
                    
                }
                else
                {
                    cell.lblMessageContent.text=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Body"];
                }
                
                NSString *strToEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
                
                if (strToEmail ==(id)[NSNull null] || [strToEmail isEqualToString:@""] || strToEmail==nil || [strToEmail length]==0) {
                    _strToEmail=@"";
                    
                }
                else
                {
                    _strToEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
                }
                
            }
            else{ // isfiltered
                
                cell.selectionStyle=UITableViewCellSelectionStyleNone;
                
                NSString *strUserName=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
                
                if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                    cell.lblUserName.text=@"";
                    
                }
                else
                {
                    cell.lblUserName.text=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
                }
                
                NSString *strSubject=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                
                if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                    cell.lblSubject.text=@"";
                    
                }
                else
                {
                    cell.lblSubject.text=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
                }

                
                NSString *strMessageContente=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
                
                if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                    cell.lblMessageContent.text=@"";
                    
                }
                else
                {
                    cell.lblMessageContent.text=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
                }
                
                NSString *strToEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
                
                if (strToEmail ==(id)[NSNull null] || [strToEmail isEqualToString:@""] || strToEmail==nil || [strToEmail length]==0) {
                    _strToEmail=@"";
                    
                }
                else
                {
                    _strToEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
                }
                
            }
            
        }
        
        if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
            //        cell.lblSubjectHeight.constant=60;
            //        cell.lblSubjectIDHeight.constant=60;
        }
        
        return cell;
    }
    @catch (NSException *exception) {
        
        NSLog(@"Exception Occures =%@",exception);
        }
   
    
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (flag == 0) {
        
        if (!isFiltered) {
            
            MessageDetails *msgDetails=[self.storyboard instantiateViewControllerWithIdentifier:@"MessageDetails"];
            
            NSString *strUserName=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
            
            if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                msgDetails.userName=@"";
                
            }
            else
            {
                msgDetails.userName=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
            }
            
            NSString *strSubject=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            
            if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
               msgDetails.subjects=@"";
                
            }
            else
            {
                msgDetails.subjects=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            }

            
            NSString *strMessageContente=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Body"];
            
            if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                msgDetails.messageContent=@"";
                
            }
            else
            {
                msgDetails.messageContent=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"Body"];
            }
            
            NSString *FromEmail=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
            
            if (FromEmail ==(id)[NSNull null] || [FromEmail isEqualToString:@""] || FromEmail==nil || [FromEmail length]==0) {
                
                msgDetails.FromEmail=@"";
            }
            else
            {
               msgDetails.FromEmail=[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
            }

            
            
            [self.navigationController pushViewController:msgDetails animated:YES];
            
            
        }
        else{ // isfiltered
            
            MessageDetails *msgDetails=[self.storyboard instantiateViewControllerWithIdentifier:@"MessageDetails"];
            
            NSString *strUserName=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
            
            if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                msgDetails.userName=@"";
                
            }
            else
            {
                msgDetails.userName=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"SentBy1"];
            }
            
            NSString *strSubject=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            
            if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                msgDetails.subjects=@"";
                
            }
            else
            {
                msgDetails.subjects=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            }
            
            NSString *strMessageContente=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
            
            if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                msgDetails.messageContent=@"";
                
            }
            else
            {
                msgDetails.messageContent=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
            }
            
            NSString *FromEmail=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
            
            if (FromEmail ==(id)[NSNull null] || [FromEmail isEqualToString:@""] || FromEmail==nil || [FromEmail length]==0) {
                msgDetails.FromEmail=@"";
                
            }
            else
            {
                msgDetails.FromEmail=[[filteredReciveArray objectAtIndex:indexPath.row] valueForKey:@"FromEmail"];
            }
            
            [self.navigationController pushViewController:msgDetails animated:YES];
            
            
        }
        
    }
    else if(flag == 1){ // flag
        
        if (!isFiltered) {
            
            MessageDetails *msgDetails=[self.storyboard instantiateViewControllerWithIdentifier:@"MessageDetails"];
            
            NSString *strUserName=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
            
            if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                msgDetails.userName=@"";
                
            }
            else
            {
                msgDetails.userName=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
            }
            
            NSString *strSubject=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            
            if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                msgDetails.subjects=@"";
                
            }
            else
            {
                msgDetails.subjects=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            }

            
            NSString *strMessageContente=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Body"];
            
            if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                msgDetails.messageContent=@"";
                
            }
            else
            {
                msgDetails.messageContent=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"Body"];
            }
            
            NSString *strToEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
            
            if (strToEmail ==(id)[NSNull null] || [strToEmail isEqualToString:@""] || strToEmail==nil || [strToEmail length]==0) {
                msgDetails.FromEmail=@"";
                
            }
            else
            {
                msgDetails.FromEmail=[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
            }
            
            [self.navigationController pushViewController:msgDetails animated:YES];
            
        }
        else{ // isfiltered
            
            MessageDetails *msgDetails=[self.storyboard instantiateViewControllerWithIdentifier:@"MessageDetails"];
            
            NSString *strUserName=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
            
            if (strUserName ==(id)[NSNull null] || [strUserName isEqualToString:@""] || strUserName==nil || [strUserName length]==0) {
                msgDetails.userName=@"";
                
            }
            else
            {
                msgDetails.userName=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"SentTo1"];
            }
            
            NSString *strSubject=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            
            if (strSubject ==(id)[NSNull null] || [strSubject isEqualToString:@""] || strSubject==nil || [strSubject length]==0) {
                msgDetails.subjects=@"";
                
            }
            else
            {
                msgDetails.subjects=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Subject"];
            }
            
            NSString *strMessageContente=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
            
            if (strMessageContente ==(id)[NSNull null] || [strMessageContente isEqualToString:@""] || strMessageContente==nil || [strMessageContente length]==0) {
                msgDetails.messageContent=@"";
                
            }
            else
            {
                msgDetails.messageContent=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"Body"];
            }
            
            NSString *strToEmail=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
            
            if (strToEmail ==(id)[NSNull null] || [strToEmail isEqualToString:@""] || strToEmail==nil || [strToEmail length]==0) {
                msgDetails.FromEmail=@"";
                
            }
            else
            {
                msgDetails.FromEmail=[[filteredSentArray objectAtIndex:indexPath.row] valueForKey:@"ToEmail"];
            }
            
            [self.navigationController pushViewController:msgDetails animated:YES];
        }
        
    }

}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
        return UITableViewCellEditingStyleDelete;
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    // If row is deleted, remove it from the list.
    if (flag == 0) {
        
        flag=3;
        
        NSString *strMessageID=[NSString stringWithFormat:@"%@",[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"MessageID"]];
        
        if (strMessageID ==(id)[NSNull null] || [strMessageID isEqualToString:@""] || strMessageID==nil || [strMessageID length]==0) {
            MessageID=@"";
            
        }
        else
        {
            MessageID =[NSString stringWithFormat:@"%@",[[_jsonArrayRecived objectAtIndex:indexPath.row] valueForKey:@"MessageID"]];
        }
        

    }
    else{
        flag=2;
        NSString *strMessageID=[NSString stringWithFormat:@"%@",[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"MessageID"]];
        
        if (strMessageID ==(id)[NSNull null] || [strMessageID isEqualToString:@""] || strMessageID==nil || [strMessageID length]==0) {
            MessageID=@"";
            
        }
        else
        {
            MessageID =[NSString stringWithFormat:@"%@",[[_jsonArraySentMessage objectAtIndex:indexPath.row] valueForKey:@"MessageID"]];
        }

        
    }
    
    
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
    
        
        NSLog(@"_emailAddress=%@",_emailAddress);
        NSLog(@"MessageID=%@",MessageID);

        
        if (flag == 0) {
             NSLog(@"flag=%d",flag);
        }
        else if(flag == 1){
            NSLog(@"flag=%d",flag);
            
        }
        else if(flag == 2){
            NSLog(@"flag=%d",flag);
            [self DeleteSentMessage];
        }else if(flag == 3){
            NSLog(@"flag=%d",flag);
            [self DeleteReceivedMessage];
        }

    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}
-(void)viewWillAppear:(BOOL)animated{
    [self reciveMessage];
    
   
    
   // [self btnSentItemClicked:self];
    
    _btnInbox.backgroundColor=[UIColor darkGrayColor];
    [_btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    //Not selected
    _btnSentItem.backgroundColor=[UIColor whiteColor];
    [_btnSentItem setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
#pragma mark - UISearchBarDelegate
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
  
    if (flag == 0) {
        
        if (searchText.length == 0) {
            
            isFiltered = NO;
        }
        else
        {
            isFiltered = YES;
            
            filteredReciveArray =[[NSMutableArray alloc] init];
            
            
            for (NSDictionary *str in _jsonArrayRecived) {
                
                NSString *countryStr=[str objectForKey:@"SentBy1"];
            
                NSRange stringRang=[countryStr rangeOfString:searchText options:NSCaseInsensitiveSearch];
    
                if (stringRang.location != NSNotFound )
                {
                    
                    [ filteredReciveArray addObject:str];
                    
                    NSLog(@"filteredReciveArray =%@",filteredReciveArray);
                    
                }
            }
        }
        
    }
    else{
        
        
        if (searchText.length == 0) {
            
            isFiltered = NO;
        }
        else
        {
            isFiltered = YES;
            
            filteredSentArray =[[NSMutableArray alloc] init];
            
            
            for (NSDictionary *str in _jsonArraySentMessage) {
                
                NSString *countryStr=[str objectForKey:@"SentTo1"];
            
                NSRange stringRang=[countryStr rangeOfString:searchText options:NSCaseInsensitiveSearch];
    
                if (stringRang.location != NSNotFound)
                {
                    
                    [ filteredSentArray addObject:str];
                    
                    NSLog(@"filteredSentArray =%@",filteredSentArray);
                    
                }
            }
        }
        
    }
    
 [_tblvwMessages reloadData];
        
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
    [_tblvwMessages resignFirstResponder];
     [searchBar resignFirstResponder];
}


#pragma mark - IBActions on TabBar

- (IBAction)btnCloseClicked:(id)sender {
    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];
    
    [self searchBarSearchButtonClicked:_searBar];
}                   

- (IBAction)btnNewEmailClicked:(id)sender {
    NewMail *NewMailVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"NewMail"];
    [self.navigationController pushViewController:NewMailVC animated:YES];
}


#pragma mark - IBAction For Inbox
- (IBAction)btnInboxClicked:(id)sender {
    
    [self reciveMessage];
    
    //Selected
    _btnInbox.backgroundColor=[UIColor darkGrayColor];
    [_btnInbox setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnSentItem.backgroundColor=[UIColor whiteColor];
    [_btnSentItem setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

#pragma mark - IBAction For SentItem

- (IBAction)btnSentItemClicked:(id)sender {
    
    [self sentItem];
    
    //Selected
    _btnSentItem.backgroundColor=[UIColor darkGrayColor];
    [_btnSentItem setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnInbox.backgroundColor=[UIColor whiteColor];
    [_btnInbox setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}

#pragma mark Webservice Methods
-(void)reciveMessage
{
    //[_jsonArray removeAllObjects];
    flag=0;
    
    NSString* parameterString=[NSString stringWithFormat:@"%@ReceiverID=%@",RECIVE_MESSAGE,_emailAddress];
    
    NSLog(@"Paramerter String =%@",parameterString);
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString:nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
 
      NSLog(@"strRequest=%@",parameterString);
}
-(void)sentItem
{
    
    //[_jsonArray removeAllObjects];
    flag=1;
    
    NSString* parameterString=[NSString stringWithFormat:@"%@SenderId=%@",SENT_MESSAGE,_emailAddress];
    
    NSLog(@"Paramerter String =%@",parameterString);
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString:nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
     NSLog(@"strRequest=%@",parameterString);
    
}
-(void)DeleteSentMessage
{
    flag=2;

    NSString *strRequest=DELETE_SENT_MESSAGE;
    NSString *parameterString=[NSString stringWithFormat:@"SenderEmail=%@&MessageId=%@",_emailAddress,MessageID];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];
    
    strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"strRequest=%@",strRequest);
    
}
-(void)DeleteReceivedMessage
{
    flag=3;
    NSString *strRequest=DELETE_RECEIVE_MESSAGE;
    NSString *parameterString=[NSString stringWithFormat:@"ReceiverEmail=%@&MessageId=%@",_emailAddress,MessageID];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];
    
    strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
 
}
- (void)requestSucceeded:(NSString *)response
{
    self.view.userInteractionEnabled=YES;
    NSError *error;
    NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
}

- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{

    if (flag == 0) {
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
                
                NSDictionary *subDict= [json objectForKey:@"Result"];
                
                _jsonArrayRecived = [subDict objectForKey:@"Email"];
            }
            
        }
       [self.tblvwMessages reloadData];
    }
    else if(flag ==1){
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
//                UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"MSG_TITLE",@"Congratulations") message:NSLocalizedString(@"MSG",@"your message has been sent") delegate:self cancelButtonTitle:nil otherButtonTitles:@"ok",nil];
//                [alertMsg show];

                NSDictionary *subDict= [json objectForKey:@"Result"];
                
                _jsonArraySentMessage = [subDict objectForKey:@"Email"];
                
            }
            
        }
       [self.tblvwMessages reloadData];
    }
    else if(flag ==2){
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
                UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@"MSG_DELETE",@"Deleted") delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"ok"),nil];
                [alertMsg show];

               
                [self sentItem];
            
            }
            
        }
        [self.tblvwMessages reloadData];
    }
    else {
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
            
                 [self showMessage:Message];
                 [self reciveMessage];
                
            }
            
        }
        
        [self.tblvwMessages reloadData];
    }


}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:@"ok",nil];
    [alertMsg show];
    
}

- (IBAction)btnHomeClicked:(id)sender {
    
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];
}

- (IBAction)btnMyListingClicked:(id)sender {
    
    MyListings *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MyListings"];
    [self.navigationController pushViewController:objVC animated:YES];

    
}
- (IBAction)btnFindDiamondClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnCalculatorClicked:(id)sender {
    
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnMemberProfileClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}
@end
