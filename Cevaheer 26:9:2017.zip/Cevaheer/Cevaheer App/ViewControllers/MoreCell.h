//
//  MoreCell.h
//  Cevaheer App
//
//  Created by  on 10/7/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *btnMoreShape;
@property (weak, nonatomic) IBOutlet UILabel *moreShapeName;
@property NSInteger myCellIndex;
- (IBAction)btnMoreShapeClicked:(id)sender;


@end
