//
//  SortCellTwo.h
//  Cevaheer App
//
//  Created by SMS on 11/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SortCellTwo : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblSortTwoName;
@property (strong, nonatomic) IBOutlet UIButton *btnAdd;
- (IBAction)btnAddClicked:(id)sender;

@end
