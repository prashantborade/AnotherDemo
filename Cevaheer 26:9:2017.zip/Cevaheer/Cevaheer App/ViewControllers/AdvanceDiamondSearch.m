//
//  AdvanceDiamondSearch.m
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "AdvanceDiamondSearch.h"

@interface AdvanceDiamondSearch ()

@end

@implementation AdvanceDiamondSearch
#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    _tblVwMore.tableFooterView=[UIView new];
    /*
     Marquise_Black
     Marquise
     Heart_Black
     Heart
     Oval_Black
     Oval
     Pear_Black
     Pear
     Round_Black
     Round
     EmeraId_Black
     EmeraId
     Princess_Black
     Princess
     */
    
    // Do any additional setup after loading the view.
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"MoreCell";
    
    MoreCell *cell = (MoreCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[MoreCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[KGModal sharedInstance]hideAnimated:YES];
    //    MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
    //    [self.navigationController pushViewController:MemberInfoVC animated:YES];
    
}


#pragma mark - IBACtions
- (IBAction)btnResetClicked:(id)sender {
}

- (IBAction)btnSearchClicked:(id)sender {
    
    SearchDiamondResult *SearchDiamondResultVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"SearchDiamondResult"];
    [self.navigationController pushViewController:SearchDiamondResultVC animated:YES];
    
}

- (IBAction)btnCuletMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}
@end
