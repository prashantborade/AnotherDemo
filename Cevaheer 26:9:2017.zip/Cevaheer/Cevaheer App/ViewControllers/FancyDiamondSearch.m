//
//  FancyDiamondSearch.m
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "FancyDiamondSearch.h"

@interface FancyDiamondSearch ()

@end

@implementation FancyDiamondSearch

#pragma mark - Lifecy
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _innerViewHeightContraint.constant=_innerViewHeightContraint.constant-850.0f;
    
    [_btnMarquise setImage:[UIImage imageNamed:@"Marquise_Black"] forState:UIControlStateNormal];
    [_btnMarquise setImage:[UIImage imageNamed:@"Marquise"] forState:UIControlStateSelected];
    
    [_btnHeart setImage:[UIImage imageNamed:@"Heart_Black"] forState:UIControlStateNormal];
    [_btnHeart setImage:[UIImage imageNamed:@"Heart"] forState:UIControlStateSelected];
    
    [_btnOval setImage:[UIImage imageNamed:@"Oval_Black"] forState:UIControlStateNormal];
    [_btnOval setImage:[UIImage imageNamed:@"Oval"] forState:UIControlStateSelected];
    
    [_btnPear setImage:[UIImage imageNamed:@"Pear_Black"] forState:UIControlStateNormal];
    [_btnPear setImage:[UIImage imageNamed:@"Pear"] forState:UIControlStateSelected];
    
    [_btnRound setImage:[UIImage imageNamed:@"Round_Black"] forState:UIControlStateNormal];
    [_btnRound setImage:[UIImage imageNamed:@"Round"] forState:UIControlStateSelected];
    
    [_btnEmeraId setImage:[UIImage imageNamed:@"EmeraId_Black"] forState:UIControlStateNormal];
    [_btnEmeraId setImage:[UIImage imageNamed:@"EmeraId"] forState:UIControlStateSelected];
    
    [_btnPrincess setImage:[UIImage imageNamed:@"Princess_Black"] forState:UIControlStateNormal];
    [_btnPrincess setImage:[UIImage imageNamed:@"Princess"] forState:UIControlStateSelected];
    _tblVwMore.tableFooterView=[UIView new];
    // Do any additional setup after loading the view.
    
    // for hidding supplier and diamond btn
   
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"MoreCell";
    
    MoreCell *cell = (MoreCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[MoreCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[KGModal sharedInstance]hideAnimated:YES];
    //    MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
    //    [self.navigationController pushViewController:MemberInfoVC animated:YES];
    
}

#pragma mark - IBACtions
- (IBAction)btnResetClicked:(id)sender {
}



- (IBAction)btnSearchClicked:(id)sender {
    
    SearchDiamondResult *SearchDiamondResultVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"SearchDiamondResult"];
    [self.navigationController pushViewController:SearchDiamondResultVC animated:YES];
}
- (IBAction)btnLabMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

- (IBAction)btnColorMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

- (IBAction)btnFancyOvertoneMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

- (IBAction)btnShapeMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

#pragma mark - Actions For Shape
- (IBAction)btnRoundClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
    
}
- (IBAction)btnEmeraIdClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnPearClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnPrincessClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnOvalClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnCushionClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnCusModClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnHeartClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnMarquiseClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnRadiantClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}



- (IBAction)btnInfoClicked:(id)sender {
    

//    [[KGModal sharedInstance]showWithContentView:_popUpView];
//    [[KGModal sharedInstance] hideAnimated:YES];
  
}
- (IBAction)btnAdvancedSearchClicked:(id)sender {
    
    _btnAdvancedSearch.hidden=YES;
    _btnAdvancedSertchHeightContraint.constant=0.1f;
    
    [UIView animateWithDuration:0.3 animations:^{
        
        _innerViewHeightContraint.constant=_innerViewHeightContraint.constant+800.0f;
        
    }];
    
}
#pragma mark - Actions For Lab
- (IBAction)btnGIAClicked:(id)sender {
}

- (IBAction)btnHRDClicked:(id)sender {
}

- (IBAction)btnAGSClicked:(id)sender {
}

- (IBAction)btnIGIClicked:(id)sender {
}

- (IBAction)btnEGLClicked:(id)sender {
}

#pragma mark - Actions For Intensity
- (IBAction)btnIntensityANYClicked:(id)sender {
}

- (IBAction)btnIntensityFTClicked:(id)sender {
}

- (IBAction)btnIntensityVLClicked:(id)sender {
}

- (IBAction)btnIntensityLClicked:(id)sender {
}

- (IBAction)btnIntensityFLClicked:(id)sender {
}

- (IBAction)btnIntensityFClicked:(id)sender {
}

- (IBAction)btnIntensityFDKClicked:(id)sender {
}

- (IBAction)btnIntensityFIClicked:(id)sender {
}

- (IBAction)btnIntensityFVClicked:(id)sender {
}

- (IBAction)btnIntensityFDPClicked:(id)sender {
}

#pragma mark - Action For Overtone
- (IBAction)btnOvertoneAClicked:(id)sender {
}

- (IBAction)btnOvertoneBClicked:(id)sender {
}

- (IBAction)btnOvertoneCClicked:(id)sender {
}

- (IBAction)btnOvertoneDClicked:(id)sender {
}

- (IBAction)btnOvertoneEClicked:(id)sender {
}

- (IBAction)btnOvertoneFClicked:(id)sender {
}

- (IBAction)btnOvertoneGClicked:(id)sender {
}

- (IBAction)btnOvertoneHClicked:(id)sender {
}

- (IBAction)btnOvertoneIClicked:(id)sender {
}

- (IBAction)btnOvertoneJClicked:(id)sender {
}

- (IBAction)btnOvertoneMoreClicked:(id)sender {
}

#pragma mark - Actions For Clarity
- (IBAction)btnClarityFLClicked:(id)sender {
}

- (IBAction)btnClarityILClicked:(id)sender {
}

- (IBAction)btnClarityVVS1Clicked:(id)sender {
}

- (IBAction)btnClarityVVS2Clicked:(id)sender {
}

- (IBAction)btnClarityVS1Clicked:(id)sender {
}

- (IBAction)btnClarityVS2Clicked:(id)sender {
}

- (IBAction)btnClaritySI1Clicked:(id)sender {
}

- (IBAction)btnClaritySI2Clicked:(id)sender {
}

- (IBAction)btnClaritySI3Clicked:(id)sender {
}

- (IBAction)btnClarityI1Clicked:(id)sender {
}

- (IBAction)btnClarityI2Clicked:(id)sender {
}

- (IBAction)btnClarityI3Clicked:(id)sender {
}


#pragma mark - Actions For Cut
- (IBAction)btnCutIClicked:(id)sender {
}

- (IBAction)btnCutEXClicked:(id)sender {
}

- (IBAction)btnCutVGClicked:(id)sender {
}

- (IBAction)btnCutGClicked:(id)sender {
}

- (IBAction)btnCutFClicked:(id)sender {
}

- (IBAction)btnCutPClicked:(id)sender {
}

#pragma  mark - Actions For Polish
- (IBAction)btnPolishIClicked:(id)sender {
}

- (IBAction)btnPolishEXClicked:(id)sender {
}

- (IBAction)btnPolishVGClicked:(id)sender {
}

- (IBAction)btnPolishGClicked:(id)sender {
}

- (IBAction)btnPolishFClicked:(id)sender {
}

- (IBAction)btnPolishPClicked:(id)sender {
}


#pragma mark - Actions For Symmetry
- (IBAction)btnSymmetryIClicked:(id)sender {
}

- (IBAction)btnSymmetryEXClicked:(id)sender {
}

- (IBAction)btnSymmetryVGClicked:(id)sender {
}

- (IBAction)btnSymmetryGClicked:(id)sender {
}

- (IBAction)btnSymmetryFClicked:(id)sender {
}

- (IBAction)btnSymmetryPClicked:(id)sender {
}

#pragma mark - Actions For Fluorescent
- (IBAction)btnFluorescentNClicked:(id)sender {
}

- (IBAction)btnFluorescentVSLClicked:(id)sender {
}

- (IBAction)btnFluorescentFClicked:(id)sender {
}

- (IBAction)btnFluorescentMClicked:(id)sender {
}

- (IBAction)btnFluorescentSBClicked:(id)sender {
}

- (IBAction)btnFluorescentVSTBClicked:(id)sender {
}

#pragma mark - Actions For Price
- (IBAction)btnPriceCTClicked:(id)sender {
}

- (IBAction)btnPriceTotalClicked:(id)sender {
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
