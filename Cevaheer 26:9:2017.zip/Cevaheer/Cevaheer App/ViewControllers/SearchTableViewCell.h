//
//  SearchTableViewCell.h
//  Cevaheer App
//
//  Created by Avion on 8/18/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTableViewCell : UITableViewCell

@end
