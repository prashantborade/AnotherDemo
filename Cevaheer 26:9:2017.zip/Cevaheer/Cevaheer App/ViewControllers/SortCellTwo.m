//
//  SortCellTwo.m
//  Cevaheer App
//
//  Created by SMS on 11/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "SortCellTwo.h"

@implementation SortCellTwo

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnAddClicked:(id)sender {
}
@end
