//
//  FilterListing.m
//  Cevaheer App
//
//  Created by  on 10/4/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "FilterListing.h"

@interface FilterListing ()

@end

@implementation FilterListing
#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - IBActions


- (IBAction)btnBackClicked:(id)sender {
}
@end
