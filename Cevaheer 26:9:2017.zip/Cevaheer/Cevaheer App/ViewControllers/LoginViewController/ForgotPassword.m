//
//  ForgotPassword.m
//  Cevaheer App
//
//  Created by SMS Systems on 11/24/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "ForgotPassword.h"

@interface ForgotPassword ()

@end

@implementation ForgotPassword

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeView];
    
    [self setPaddingToTextField:_txtEmailId];
    
    webserviceClass=[[WebserviceClass alloc] init];
    
    // Do any additional setup after loading the view.
}
-(void)initializeView
{
    self.upperImgView.backgroundColor=[UIColor colorWithHexString:APP_GREY_COLOR];
    [_btnSubmit setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_btnCancel setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    
    _btnSubmit.layer.borderWidth=1.0F;
    _btnCancel.layer.borderWidth=1.0F;
    _txtEmailId.layer.borderWidth=1.0F;
    
    _btnSubmit.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _btnCancel.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtEmailId.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    

}
- (IBAction)btnSubmitClicked:(id)sender {
    
    
    if (![self validateEmailWithString:[_txtEmailId text]]) {
        [self showMessage:NSLocalizedString(@"VALIDATE_EMAIL", @"Please Enter Valid Email id !")];
        _txtEmailId.text= @"";
        [_txtEmailId becomeFirstResponder];

    }
    else
    {
    NSString *strRequest=FORGOT_PAASWORD;
    NSString *parameterString=[NSString stringWithFormat:@"Email=%@",_txtEmailId.text];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];

     strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    }
    
}

- (IBAction)btnCancelClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    if(json == nil)
    {
        // [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if ([Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];
            _txtEmailId.text=@"";
            [_txtEmailId becomeFirstResponder];
        }
        else
        {
            [self showMessage];
        }
        
    }
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}

-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:2.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}

#pragma mark - TextFieldLeftPadding
-(void)setPaddingToTextField:(UITextField*)textField
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


@end
