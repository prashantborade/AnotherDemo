//
//  ForgotPassword.h
//  Cevaheer App
//
//  Created by SMS Systems on 11/24/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebserviceClass.h"
@interface ForgotPassword : UIViewController
{
    
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
  
}
#pragma mark - Outlets

@property (strong, nonatomic) IBOutlet UIImageView *upperImgView;
@property (strong, nonatomic) IBOutlet UITextField *txtEmailId;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;

#pragma mark - IBAction
- (IBAction)btnSubmitClicked:(id)sender;
- (IBAction)btnCancelClicked:(id)sender;



@end
