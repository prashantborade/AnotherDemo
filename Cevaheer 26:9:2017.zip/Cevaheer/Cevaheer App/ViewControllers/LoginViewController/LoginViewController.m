//
//  LoginViewController.m
//  Cevaheer App
//
//  Created by   on 12/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "LoginViewController.h"
#import <Firebase/Firebase.h>
@import Firebase;

@interface LoginViewController ()


@end

@implementation LoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:NO];
    [self.navigationItem setHidesBackButton:YES animated:YES];
   
    [self setPaddingToTextField:_userNameOutlet];
    [self setPaddingToTextField:_passwordOutlet];
    
    
    
    [self initializeView];
    _notRegisteredOutlet.hidden=YES;
    
//    _userNameOutlet.text=@"musti_sumatran@hotmail.com";
//    _passwordOutlet.text=@"12345678";
    _userNameOutlet.text=@"rajratna.godboley@aviontechnology.net";
    _passwordOutlet.text=@"Welcome12";
    
//        _userNameOutlet.text=@"arun.jadhav@aviontechnology.net";
//        _passwordOutlet.text=@"Welcome123";
    
}

-(void)initializeView
{
    self.upperImageViewOutlet.backgroundColor=[UIColor colorWithHexString:APP_GREY_COLOR];
    [_loginBtnOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_forgotpwrdOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_notRegisteredOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    _loginBtnOutlet.layer.borderWidth=1.0F;
    _userNameOutlet.layer.borderWidth=1.0F;
    _passwordOutlet.layer.borderWidth=1.0F;
    _notRegisteredOutlet.layer.borderWidth=1.0F;
    
    _userNameOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _loginBtnOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _passwordOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _notRegisteredOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        
        [_btnRemberMe setImage:[UIImage imageNamed:@"uncheck-box"]
                      forState:UIControlStateNormal];
        [_btnRemberMe setImage:[UIImage imageNamed:@"check-box"]
                      forState:UIControlStateSelected];
        [_btnRemberMe setImage:[UIImage imageNamed:@"check-box"]
                      forState:UIControlStateHighlighted];
        _btnRemberMe.adjustsImageWhenHighlighted=YES;
    }
    else
    {
        [_btnRemberMe setImage:[UIImage imageNamed:@"uncheck-box_ipade"]
                      forState:UIControlStateNormal];
        [_btnRemberMe setImage:[UIImage imageNamed:@"check-box_ipad"]
                      forState:UIControlStateSelected];
        [_btnRemberMe setImage:[UIImage imageNamed:@"check-box_ipad"]
                      forState:UIControlStateHighlighted];
        _btnRemberMe.adjustsImageWhenHighlighted=YES;
    }
    [Constant setIsAlreadyLogin:NO];
    webserviceClass=[[WebserviceClass alloc]init];
      self.screenName=@"Login";
}

- (IBAction)forgotPwrdAction:(id)sender
{
    ForgotPassword *forgotPwdVC=[self.storyboard instantiateViewControllerWithIdentifier:@"ForgotPassword"];
    [self.navigationController pushViewController:forgotPwdVC animated:YES];
}

- (IBAction)notRegisterdAction:(id)sender
{
    RegistrationViewController *registrationViewController=[[self storyboard]instantiateViewControllerWithIdentifier:@"RegistrationViewController"];
    [self.navigationController pushViewController:registrationViewController animated:NO];
    
//    please click here to sign up - Kayıt olmak için lütfen buraya tıklayın
//    Sign up - Kayıt ol
    
//    UIAlertController *controller=[UIAlertController alertControllerWithTitle:NSLocalizedString(@"SIGN_UP",@"Sign up") message:NSLocalizedString(@"SIGN_UP_TITLE",@"Please click here to sign up") preferredStyle:UIAlertControllerStyleAlert];
//    
//    UIAlertAction *actionSignUp=[UIAlertAction actionWithTitle:NSLocalizedString(@"SIGN_UP",@"Sign up") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
//    
//        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.cevaheer.com/registration"]];
//    }];
//    
//    
//    [controller addAction:actionSignUp];
//    [self presentViewController:controller animated:YES completion:nil];
//    
//    
    
    
    
}

- (IBAction)loginBtnAction:(id)sender
{
    if ([_userNameOutlet.text isEqualToString:@""] && ![_passwordOutlet.text isEqualToString:strPassword])
    {
        [self showMessage:NSLocalizedString(@"VALIDATE_EMAIL", @"Please Enter Valid Email id !")];
       _userNameOutlet.text= @"";
        [_userNameOutlet becomeFirstResponder];
    }
//    if (![_passwordOutlet.text isEqualToString:strPassword]) {
//        
//        [self showMessage:@"Email or PassWord incorrect!"];
//        _passwordOutlet.text=@"";
//        [_passwordOutlet becomeFirstResponder];
//    }
    
   // if(_userNameOutlet.text containsString:<#(nonnull NSString *)#>)
   // username=rajratna.godboley@aviontechnology.net&password=Welcome12
    
   NSString* parameterString=[NSString stringWithFormat:@"%@username=%@&password=%@",LOGIN_URL,_userNameOutlet.text,_passwordOutlet.text];

    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"%@",parameterString);
    
}

- (IBAction)btnRemberClicked:(id)sender
{
    if(_btnRemberMe.isSelected)
    {
        [_btnRemberMe setSelected:NO];
        [Constant setIsAlreadyLogin:NO];
    }else
    {
        [_btnRemberMe setSelected:YES];
        [Constant setIsAlreadyLogin:YES];
    }
    
    
//    //check box button status
//    if([_btnRemberMe isSelected]==YES)
//    {
//        [_btnRemberMe setSelected:NO];
//    }
//    else
//    {
//        [_btnRemberMe setSelected:YES];
//        
//    }
    
    
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}
#pragma mark Webservice Methods

- (void)requestSucceeded:(NSString *)response
{
    self.view.userInteractionEnabled=YES;
    NSError *error;
    NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];

}

- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    NSLog(@"json === %@", json);
    
    if(json == nil)
    {
        //  [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithDictionary:json error:&error];
        
        
       
        if ([objJSONUtility.Statuscode isEqualToString:@"1"])
        {
            //[Constant setIsAlreadyLogin:YES];
            Result *objResult=[[JSONUtility alloc]initWithDictionary:objJSONUtility.Result error:&error];
            
            NSArray *UserArray=[objResult valueForKey:@"User"];
            
            for (NSDictionary *result in UserArray) {
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                NSString *strEmail=[NSString stringWithFormat:@"%@",[result objectForKey:@"Email"]];
                 [defaults synchronize];
                
                if (strEmail ==(id)[NSNull null] || [strEmail isEqualToString:@""] || strEmail==nil || [strEmail length]==0 || [strEmail isEqualToString:@"<null>"] ) {
                  
                    
                }
                else
                {
                    strEmailid=[NSString stringWithFormat:@"%@",[result objectForKey:@"Email"]];
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    [defaults setValue:[result objectForKey:@"Email"] forKey:@"EmailAddress"];
                    [defaults synchronize];

                }
                
                NSString *strPwd=[NSString stringWithFormat:@"%@",[result objectForKey:@"Password"]];

                if (strPwd ==(id)[NSNull null] || [strPwd isEqualToString:@""] || strPwd==nil || [strPwd length]==0 || [strPwd isEqualToString:@"<null>"] ) {
                    
                    strPassword=@"";
                }
                else
                {
                    strPassword=[NSString stringWithFormat:@"%@",[result objectForKey:@"Password"]];
                }
                
                NSString *strUserID=[NSString stringWithFormat:@"%@",[result objectForKey:@"UserID"]];
                
                if (strUserID ==(id)[NSNull null] || [strUserID isEqualToString:@""] || strUserID==nil || [strUserID length]==0 || [strUserID isEqualToString:@"<null>"]) {
                    
                    NSLog(@"User is Invalide");
                }
                else
                {
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    [defaults setValue:[result objectForKey:@"UserID"] forKey:@"UserId"];
                    [defaults synchronize];
                    
                }
                
                NSString *strIsActive=[NSString stringWithFormat:@"%@",[result objectForKey:@"IsActive"]];
                
                if (strIsActive ==(id)[NSNull null] || [strIsActive isEqualToString:@""] || strIsActive==nil || [strIsActive length]==0 || [strIsActive isEqualToString:@"<null>"]) {
                    
                    NSLog(@"User is Invalide");
                }
                else
                {
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
               
                    [defaults setValue:[result objectForKey:@"IsActive"] forKey:@"IsActive"];
                    _strIsActive=[NSString stringWithFormat:@"%@",[defaults objectForKey:@"IsActive"]];
                    [defaults synchronize];
                    
                }

            }
            
            if ([_strIsActive isEqualToString:@"1"])  {
                
                
             /*   [FIRAnalytics logEventWithName:kFIREventSelectContent
                                    parameters:@{
                                                 kFIRParameterItemID:[NSString stringWithFormat:@"id-%@", self.title],
                                                 kFIRParameterItemName:self.title,
                                                 kFIRParameterContentType:@"diamond"
                                                 }];
              
              */
                WelcomeViewController *welcomeViewController=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
                [self.navigationController pushViewController:welcomeViewController animated:NO];
            }
            else
            {
                [self showMessage:@"User is inactive !"];
            }
            }
        else
        {
        }
    }
}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}

#pragma mark - TextFieldLeftPadding

-(void)setPaddingToTextField:(UITextField*)textField
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
}

#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
@end
