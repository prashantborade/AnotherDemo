//
//  LoginViewController.h
//  Cevaheer App
//
//  Created by  on 12/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "WebserviceClass.h"
#import "Result.h"
#import "ForgotPassword.h"

@class FindDiamond;


@class WebserviceClass;


@interface LoginViewController : GAITrackedViewController<WebserviceProtocol,MBProgressHUDDelegate,UITextFieldDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *strPassword;
    NSString *strEmailid;
}

//Outlets
@property (strong, nonatomic) IBOutlet UIButton *forgotpwrdOutlet;
@property (strong, nonatomic) IBOutlet UIButton *notRegisteredOutlet;
@property (strong, nonatomic) IBOutlet UIButton *loginBtnOutlet;

@property (strong, nonatomic) IBOutlet UITextField *userNameOutlet;
@property (strong, nonatomic) IBOutlet UITextField *passwordOutlet;

@property (strong, nonatomic) IBOutlet UIImageView *upperImageViewOutlet;
@property(strong ,nonatomic) NSString *strIsActive;
@property (weak, nonatomic) IBOutlet UIButton *btnRemberMe;

//Scroll View outlet




//Actions
- (IBAction)forgotPwrdAction:(id)sender;
- (IBAction)notRegisterdAction:(id)sender;

- (IBAction)loginBtnAction:(id)sender;
- (IBAction)btnRemberClicked:(id)sender;

@end
