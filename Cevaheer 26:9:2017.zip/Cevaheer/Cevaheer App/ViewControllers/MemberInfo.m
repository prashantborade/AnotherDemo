//
//  MemberInfo.m
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MemberInfo.h"

@interface MemberInfo ()

@end

@implementation MemberInfo

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     _membershipExpireDateLbl.text=_membershipExpireDate;
    _memberNameLbl.text=_memberName;
    _compNameLbl.text=_compName;
    _locationLbl.text=_location;
    _ceveheerIDLbl.text=_ceveheerID;
    _compTypeLbl.text=_compType;
    _countryLbl.text=_country;
    _cityLbl.text=_city;
    _stateLbl.text=_state;
    _telephoneLbl.text=_telephone;
    _diamondsListedLbl.text=_diamondsListed;
    _websiteLbl.text=_website;
 
}


#pragma mark - IBActions
- (IBAction)btnBackClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
