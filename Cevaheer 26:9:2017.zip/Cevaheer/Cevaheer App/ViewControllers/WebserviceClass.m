//
//  WebserviceClass.m
//  WaitTimerApp
//
//  Created by Mobility Team on 14/04/16.

//

#import "WebserviceClass.h"

@implementation WebserviceClass
@synthesize apiReturnData;
@synthesize delegate ;


-(void)callServcieUsingRequestAndGET :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view
{
    
    
    HUD = _HUD;
    current_view = view;
    HUD = [[MBProgressHUD alloc] initWithView:view];
    HUD.delegate = self;
    HUD.label.text = @"Loading...";
    [view addSubview:HUD];
    [HUD showAnimated:YES];
    
    delegate = delegateObject;
    
    
    apiReturnData=[[NSMutableData alloc]init];
    
    request=[[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString:strRequest]];
    
    
    NSLog(@"url is %@  parameter = %@", request , dataRequest);
    [request setHTTPMethod:@"GET"];
    [request addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
    [request addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
    //[request setHTTPBody: [dataRequest dataUsingEncoding:NSUTF8StringEncoding]];
    theConnection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    [theConnection start];

    if( theConnection )
    {
        apiReturnData= [NSMutableData data];
    }
    
}


-(void)callServcieUsingRequestAndPOST :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view
{
    
    HUD = _HUD;
    current_view = view;
    HUD = [[MBProgressHUD alloc] initWithView:view];
    HUD.delegate = self;
    HUD.label.text = @"Loading....";
    [view addSubview:HUD];
    [HUD showAnimated:YES];
    
    delegate = delegateObject;
    
    apiReturnData=[[NSMutableData alloc]init];
    
    
    request=[[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString:strRequest]];
    
    NSLog(@"url is %@  parameter = %@", request , dataRequest);
    [request setHTTPMethod:@"POST"];
    [request addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
    [request addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
    [request setHTTPBody: [dataRequest dataUsingEncoding:NSUTF8StringEncoding]];
    theConnection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    [theConnection start];
    
    if( theConnection )
    {
        apiReturnData= [NSMutableData data];
    }
    
    
}
-(void)getDataUsingRequestToPost_Image :(NSString *) strRequest :  (NSDictionary *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view andHUDText : (NSString *) _hudlabelText;
{
    HUD = _HUD;
    current_view = view;
    
    HUD = [[MBProgressHUD alloc] initWithView:view];
    HUD.delegate = self;
    HUD.label.text = _hudlabelText;
    [view addSubview:HUD];
    [HUD showAnimated:YES];
    
    
    delegate = delegateObject;
    
    NSLog(@"str url == %@", strRequest);
    
    NSLog(@"datrequest  == %@", dataRequest);
    
    apiReturnData=[[NSMutableData alloc]init];
    
    
    NSError *error;
    
    NSData *postdata = [NSJSONSerialization dataWithJSONObject:dataRequest options:0 error:&error];
    
    request=[[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString:strRequest]];
    
   
    
    
    [request setHTTPMethod: @"POST"];
    [request setHTTPBody: postdata];
    [request setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    theConnection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    [theConnection start];
    
    
    if( theConnection )
    {
        apiReturnData= [NSMutableData data];
    }
    
}



-(void)getDataUsingRequestToPost_Image_try :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view andHUDText : (NSString *) _hudlabelText;
{
    HUD = _HUD;
    current_view = view;
    
    HUD = [[MBProgressHUD alloc] initWithView:view];
    HUD.delegate = self;
    HUD.labelText = _hudlabelText;
    // HUD setBackgroundColor:[UIColor colorWithCGColor:<#(CGColorRef)#>]
    [view addSubview:HUD];
    [HUD show:YES];
    
    
    delegate = delegateObject;
    
    NSLog(@"str url == %@", strRequest);
    
   NSLog(@"datrequest  == %@", dataRequest);
    
    apiReturnData=[[NSMutableData alloc]init];
    
     
    //NSData *postdata = [NSJSONSerialization dataWithJSONObject:dataRequest options:0 error:&error];
    
    request=[[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString:strRequest]];
    
    //text/html; charset=utf-8
    
    [request setHTTPMethod:@"GET"];
    [request addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
    [request addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
    [request setHTTPBody: [dataRequest dataUsingEncoding:NSUTF8StringEncoding]];
//    [request setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    
    
    theConnection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
    [theConnection start];
    
    
    
 
    if( theConnection )
    {
        apiReturnData= [NSMutableData data];
    }
}


#pragma NSURLConnection delegate

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [HUD hideAnimated:YES];
    
    if (delegate && [delegate respondsToSelector:@selector(sendError:)])
    {
        [delegate sendError:error];
    }
    
    NSLog(@"Connection Error : %@ ", error.localizedDescription);
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [apiReturnData appendData:data];
       //[HUD hide:YES];
    
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"Connection Started");
    
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSString* myString;
    myString = [[NSString alloc] initWithData:apiReturnData encoding:NSASCIIStringEncoding];
    
     [HUD hideAnimated:YES];
    NSLog(@"mySTring === %@", myString);
 
    
    if (delegate && [delegate respondsToSelector:@selector(sendResponse:)])
    {
        [delegate sendResponse:apiReturnData];
    }
    
}


-(void) showAlert : (NSString *) messageToShow
{
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:messageToShow delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
}


@end
