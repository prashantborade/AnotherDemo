//
//  MyListingCell.m
//  Cevaheer App
//
//  Created by  on 10/4/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MyListingCell.h"

@implementation MyListingCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnNewMailClicked:(id)sender {
}

- (IBAction)btnCallingClicked:(id)sender {
}
@end
