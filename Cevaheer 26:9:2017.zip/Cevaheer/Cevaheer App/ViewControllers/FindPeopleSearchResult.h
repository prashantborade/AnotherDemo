//
//  FindPeopleSearchResult.h
//  Cevaheer App
//
//  Created by  on 9/27/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchCell.h"
#import "MemberInfo.h"
#import "WebserviceClass.h"
#import "FindDiamond.h"
#import "WelcomeViewController.h"
#import "MyListings.h"
#import "MemberProfile.h"
#import "Messages.h"

@class WebserviceClass;

@interface FindPeopleSearchResult : UIViewController<UISearchBarDelegate,WebserviceProtocol>
{
        UIAlertView *alert;
        WebserviceClass *webserviceClass;
        NSDictionary *json;
        BOOL isFiltered;
        NSMutableArray *filteredArray;
        NSString *Statuscode;
         NSString *Message,*Lid,*language;
        int flag;
    
}
//Outlets
@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UITableView *tblVwSearchResult;
@property(nonatomic,strong) NSMutableArray *jsonArray;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) IBOutlet UIView *footerView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *footerViewContraintHeight;

@property (strong, nonatomic) IBOutlet UIButton *btnReset;
@property (strong, nonatomic) IBOutlet UIButton *btnSearch;
@property (strong, nonatomic) IBOutlet UIImageView *BanerAdImageView;

#pragma mark -Footer Menu
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnMyListingClicked:(id)sender;
- (IBAction)btnMessageClicked:(id)sender;
- (IBAction)btnFindDiamondClicked:(id)sender;
- (IBAction)btnMemberClicked:(id)sender;


#pragma mark - WebParameter
@property(nonatomic,strong) NSString *strCompName;
@property(nonatomic,strong) NSString *strMemberName;
@property(nonatomic,strong) NSString *strcompCode;  
@property(nonatomic,strong) NSString *strCompType;
@property(nonatomic,strong) NSString *strCountry;
@property(nonatomic,strong) NSString *strCity;
@property(nonatomic,strong) NSString *strState;
@property(nonatomic,strong) NSString *strTelephone;
@property(nonatomic,strong) NSString *strCevaheerId;
@property(nonatomic,strong) NSString *strStarRatingValue;



//Actions

- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSerchingClicked:(id)sender;

- (IBAction)btnMenuClicked:(id)sender;


@end
