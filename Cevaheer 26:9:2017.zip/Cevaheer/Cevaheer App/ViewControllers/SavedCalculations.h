//
//  SavedCalculations.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalculationsCell.h"
#import "SaveCalculation.h"

@interface SavedCalculations : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblVwCalculations;
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnEditClicked:(id)sender;

@end
