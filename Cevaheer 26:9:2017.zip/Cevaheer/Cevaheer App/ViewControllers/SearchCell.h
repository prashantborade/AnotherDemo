//
//  SearchCell.h
//  Cevaheer App
//
//  Created by  on 9/27/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HCSStarRatingView.h"

@interface SearchCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *locationLbl;
@property (strong, nonatomic) IBOutlet UILabel *compTypeLbl;

@property (strong, nonatomic) IBOutlet UILabel *ratingLbl;
@property (strong, nonatomic) IBOutlet UILabel *cavaheerIDLbl;
@property (strong, nonatomic) IBOutlet UILabel *comNameLbl;
@property (strong, nonatomic) IBOutlet HCSStarRatingView *StarRatingView;

@end
