//
//  MemberProfile.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UpdateProfile.h"
#import "WebserviceClass.h"
#import "CustomCell.h"
#import "CompanyTypeCell.h"
#import "CountryCell.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "NIDropDown.h"

#import <Google/Analytics.h>
#import "GAITrackedViewController.h"


@interface MemberProfile : GAITrackedViewController<UITextFieldDelegate,NIDropDownDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *strEmail;
    NSString *strUserID;
    NSString *language;
    NSString *Lid;
    
    NSString  *firstName;
    NSString *lastName;

    
    BOOL flag,flag1,flag2,flag3;
   
    BOOL flagCity;
    BOOL flagState;
    BOOL flagCountry;
    BOOL flagCompanyType;
    
    NIDropDown *dropDown;
}

#pragma mark - Outlets

@property(nonatomic,strong) NSMutableArray *countrydataArray;
@property (strong, nonatomic) IBOutlet UITableView *countryTableView;

@property (strong, nonatomic) IBOutlet UILabel *firstNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *lastNameLbl;

@property (strong, nonatomic) IBOutlet UILabel *memberNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *membershipExpireDateLbl;
@property (strong, nonatomic) IBOutlet UILabel *compNameLbl;
//@property (strong, nonatomic) IBOutlet UILabel *locationLbl;
//@property (strong, nonatomic) IBOutlet UILabel *compTypeLbl;
//@property (strong, nonatomic) IBOutlet UILabel *ceveheerIDLbl;
//@property (strong, nonatomic) IBOutlet UILabel *cityLbl;
//@property (strong, nonatomic) IBOutlet UILabel *countryLbl;
//@property (strong, nonatomic) IBOutlet UILabel *stateLbl;
//@property (strong, nonatomic) IBOutlet UILabel *telephoneLbl;
//@property (strong, nonatomic) IBOutlet UILabel *diamondsListedLbl;
//@property (strong, nonatomic) IBOutlet UILabel *websiteLbl;
@property (strong, nonatomic) IBOutlet UITextField *txtTelephone;
@property (strong, nonatomic) IBOutlet UITextField *txtCevaheerID;
@property (strong, nonatomic) IBOutlet UITextField *txtDiamondListed;
@property (strong, nonatomic) IBOutlet UIButton *btnCompanyType;

@property (strong, nonatomic) IBOutlet UITextField *txtCity;
@property (strong, nonatomic) IBOutlet UITextField *txtState;
@property (strong, nonatomic) IBOutlet UIButton *btnCountry;


@property(nonatomic,strong) NSMutableArray *jsonArray;
@property(nonatomic,strong) NSMutableArray *jsonArrayCompanyType;
@property(nonatomic,strong) NSMutableArray *jsonArrayCountry;


- (IBAction)brnBackClicked:(id)sender;
- (IBAction)btnEditClicked:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *popUpViewchangePwd;


- (IBAction)btnCompanyTypeClicked:(id)sender;
- (IBAction)btnCountryClicked:(id)sender;


- (IBAction)btnChangePasswordClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)btnCancelPopUpClicked:(id)sender;

#pragma mark - ComboBox

@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewCompanyType;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewCountry;

@property(nonatomic,strong) NSMutableArray *companyTypeArray;
@property(nonatomic,strong) NSMutableArray *CountryArry;

#pragma mark - PopupView Change Password

@property (strong, nonatomic) IBOutlet UITextField *txtOldPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtNewPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtConfirmPassword;

@property (strong, nonatomic) IBOutlet UIButton *btnPopupSave;

- (IBAction)btnPopupSaveClicked:(id)sender;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollVIewOutlet;
@property (strong, nonatomic) IBOutlet UIButton *btnCancelPopup;

@property(strong,nonatomic)id companyTypeSenderId;
@property(strong,nonatomic)id countryId;


@end
