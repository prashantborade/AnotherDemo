//
//  MoreCell2.h
//  Cevaheer App
//
//  Created by SMS on 10/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreCell2 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *ColorName;

@end
