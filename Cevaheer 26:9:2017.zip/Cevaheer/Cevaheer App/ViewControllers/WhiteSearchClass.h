//
//  WhiteSearchClass.h
//  Cevaheer App
//
//  Created by SMS Systems on 11/14/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WhiteSearchClass : NSObject
@property(nonatomic,strong) NSString *strShape;

@end
