//
//  FindPeople.m
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "FindPeople.h"
#import "WelcomeViewController.h"
#import "HCSStarRatingView.h"

@interface FindPeople ()

@end

@implementation FindPeople

#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [self.navigationItem setHidesBackButton:YES];
    [self StarRatingView];
    
    _btnCompany.hidden=YES;
    _btnCompanyHeight.constant=0.1f;
    
    _btnMember.hidden=YES;
    _btnCompanyHeight.constant=0.1f;
    
    

}

-(void)starRatingView
{
    HCSStarRatingView *starRatingView = [HCSStarRatingView new];
    starRatingView.maximumValue = 10;
    starRatingView.minimumValue = 0;
    starRatingView.value = 4;
    starRatingView.tintColor = [UIColor redColor];
    starRatingView.allowsHalfStars = YES;
    starRatingView.emptyStarImage = [[UIImage imageNamed:@"heart-empty"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    starRatingView.filledStarImage = [[UIImage imageNamed:@"heart-full"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    //[starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:starRatingView];
    
    // auto layout
    starRatingView.translatesAutoresizingMaskIntoConstraints = NO;
//    [[NSLayoutConstraint constraintWithItem:starRatingView
//                                  attribute:NSLayoutAttributeTop
//                                  relatedBy:NSLayoutRelationEqual
//                                     toItem:self.lastRatingTitleLabel
//                                  attribute:NSLayoutAttributeBottom
//                                 multiplier:1.f
//                                   constant:8.f] setActive:YES];
    [[NSLayoutConstraint constraintWithItem:starRatingView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:self.view
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1.f
                                   constant:0.f] setActive:YES];
    [[NSLayoutConstraint constraintWithItem:starRatingView
                                  attribute:NSLayoutAttributeWidth
                                  relatedBy:NSLayoutRelationLessThanOrEqual
                                     toItem:self.view
                                  attribute:NSLayoutAttributeWidth
                                 multiplier:.9f
                                   constant:0.f] setActive:YES];

}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    _scroll.contentSize=CGSizeMake(self.view.frame.size.width, 840);
    
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - IBActions
- (IBAction)btnSearchClicked:(id)sender {
   
//    if(![self validateAlphabets:_txtCompName.text])
//    {
//        [self showMessage:@"Enter Valid CompanyName!"];
//    }
//    else if (![self validateAlphabets:_txtMemberName.text]){
//        [self showMessage:@"Enter Valid MemberName!"];
//        
//    }else if (![self validateAlphabets:_txtCompType.text]){
//        [self showMessage:@"Enter Valid CompanyType!"];
//        
//    }else if (![self validateAlphabets:_txtCountry.text]){
//        [self showMessage:@"Enter Valid CountryName!"];
//        
//    }else if (![self validateAlphabets:_txtCity.text]){
//        [self showMessage:@"Enter Valid CityName!"];
//        
//    }else if (![self validateAlphabets:_txtState.text]){
//        [self showMessage:@"Enter Valid StateName!"];
//    }
//    else{
//        
//    }
    
    FindPeopleSearchResult *findPeopleSearchResult=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindPeopleSearchResult"];
    
    findPeopleSearchResult.strCompName=_txtCompName.text;
    findPeopleSearchResult.strMemberName=_txtMemberName.text;
    //  findPeopleSearchResult.strcompCode=_txtCompCode.text;
    findPeopleSearchResult.strCompType=_txtCompType.text;
    findPeopleSearchResult.strCountry=_txtCountry.text;
    findPeopleSearchResult.strCity=_txtCity.text;
    findPeopleSearchResult.strState=_txtState.text;
    findPeopleSearchResult.strTelephone=_txtTelephone.text;
    findPeopleSearchResult.strStarRatingValue=_starRatingValue;
    
    findPeopleSearchResult.strCevaheerId=[NSString  stringWithFormat:@"%@",_txtCevaheerId.text];
    
    [self.navigationController pushViewController:findPeopleSearchResult animated:YES];
}
-(BOOL) validateAlphabets: (NSString *)alpha
{
    NSString *abnRegex = @"[A-Za-z]+"; // check for one or more occurrence of string you can also use * instead + for ignoring null value
    NSPredicate *abnTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", abnRegex];
    BOOL isValid = [abnTest evaluateWithObject:alpha];
    return isValid;
}
- (BOOL)validatePhone:(NSString *)phoneNumber
{
    NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    
    return [phoneTest evaluateWithObject:phoneNumber];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}
- (IBAction)btnMenuClicked:(id)sender {
    
    //goto Dashboard
// WelcomeViewController *WelcomeViewControllerVC=[self.storyboard instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
// 
//      [self.navigationController showViewController:WelcomeViewControllerVC sender:nil];
//    [self.navigationController dismissModalViewControllerAnimated:YES];
    
    
    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];
}

- (IBAction)btnResetClicked:(id)sender {
    
    _txtMemberName.text=@"";
    _txtCompName.text=@"";
    _txtCompType.text=@"";
    _txtCountry.text=@"";
    _txtCity.text=@"";
    _txtState.text=@"";
    _txtTelephone.text=@"";
    _txtCevaheerId.text=@"";
    _StarRatingView.value=0;
}

- (IBAction)didChangeValue:(HCSStarRatingView *)sender {
    
    NSLog(@"Changed rating to %.1f",sender.value);
    
    _starRatingValue=[NSString stringWithFormat:@"%f",sender.value];
    
    
}

@end
