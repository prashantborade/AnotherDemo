//Project Name:-  Cevaheer App
//Class Name:-    WelcomeViewController.h
//Created by:-    Mobile Team
//Creation Date:- on 14/09/16.
//


#import <UIKit/UIKit.h>

#import "RearViewController.h"
#import "SWRevealViewController.h"
#import "WebserviceClass.h"
#import "MyListings.h"
#import "MemberProfile.h"
#import "Messages.h"
#import "Calculator.h"
#import "FindDiamond.h"
#import <Google/Analytics.h>
#import "GAITrackedViewController.h"
#import "Reachability.h"
#import "UIImage+animatedGIF.h"


@interface WelcomeViewController : GAITrackedViewController<SWRevealViewControllerDelegate>
{
    
        WebserviceClass *webserviceClass;
        NSDictionary *json;
        NSString *Statuscode;
        NSString *Message;
        NSString *strEmail;
        NSString  *firstName;
        NSString *lastName;
    
    
    
}

@property(nonatomic,strong) NSMutableArray *jsonArray;

#pragma Outlets
//@property (strong, nonatomic) IBOutlet UILabel *lblDiamondListing;
//@property (strong, nonatomic) IBOutlet UILabel *lblBuyRequests;
//@property (strong, nonatomic) IBOutlet UILabel *lblMembershipValid;

@property (strong, nonatomic) IBOutlet UILabel *lblName;

@property (strong, nonatomic) IBOutlet UILabel *lblMembershipExpireDate;
@property (strong, nonatomic) IBOutlet UIImageView *BanerAdImageView;


#pragma IBActions

- (IBAction)menuBtnAction:(id)sender;

#pragma  mark - Main menu

- (IBAction)SearchDiamondClicked:(id)sender;

- (IBAction)CalculatorClicked:(id)sender;

- (IBAction)InboxClicked:(id)sender;

- (IBAction)AccountSettingClicked:(id)sender;





@end
