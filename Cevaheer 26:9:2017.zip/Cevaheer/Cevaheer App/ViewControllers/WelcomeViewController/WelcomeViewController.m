//Project Name:-  Cevaheer App
//Class Name:-    WelcomeViewController.m
//Created by:-    Mobile Team
//Creation Date:- on 14/09/16.
//

#import "WelcomeViewController.h"

@implementation WelcomeViewController
{
    int flag,flag2;
    NSString *urlString;
    
}

-(void)viewDidLoad
{
    [super viewDidLoad]; 
    
    //webserviceClass=[[WebserviceClass alloc] init];
   // [self callBanerAddWebservice];
    
    
    [self callServiceForBanerAd];
    
    flag =0;
    flag2 =0 ;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strEmail= [defaults valueForKey:@"EmailAddress"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];
    
    webserviceClass=[[WebserviceClass alloc] init];
    [self welcomeaWebservice];
   
    self.navigationController.navigationBarHidden=YES;
    
    self.screenName=@"Dashboard";
  
     [self callServiceForLastListPriceSaved:GET_PRICE_LIST paraeters:nil];
    
}

- (IBAction)btnFindDiamonClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];
    
}

- (IBAction)btnMyListingClicked:(id)sender {
   
    MyListings *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MyListings"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnMessageClicked:(id)sender {
    
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnCalculatorClicked:(id)sender {
    
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnMemberProfileClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}

- (IBAction)menuBtnAction:(id)sender
{
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];

}
#pragma mark Webservice Methods
-(void)welcomeaWebservice
{
    flag = 1;
    
    NSString *strRequest=WELCOME;
    NSString *parameterString=[NSString stringWithFormat:@"EmailId=%@",strEmail];
    
    strRequest=[strRequest stringByAppendingString:parameterString];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
 
}
-(void)callBanerAddWebservice
{
    flag=0;
   
    
    NSString* parameterString=[NSString stringWithFormat:@"%@PageName=%@",GET_BANER_AD,@"Home%20Page"];
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"%@",parameterString);

    
}

-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    
 
        
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    if(json == nil)
    {
        // [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if (![Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];
            
        }
        else
        {
            if (![json objectForKey:@"Result"]) {
                
                
            }
            else
            {
                NSDictionary *subDict= [json objectForKey:@"Result"];
                _jsonArray = [subDict objectForKey:@"Table"];
                
                for (NSDictionary *result in _jsonArray) {
                    
                    
                    NSString *strFirstName=[result objectForKey:@"FirstName"];
                    
                    if (strFirstName ==(id)[NSNull null] || [strFirstName isEqualToString:@""] || strFirstName==nil || [strFirstName length]==0 || [strFirstName isEqualToString:@"<null>"]) {
                        
                      firstName=@"";
                        
                    }
                    else
                    {
                      firstName=[result objectForKey:@"FirstName"];
                    }
                    
                    NSString *strLastName=[result objectForKey:@"LastName"];
                    
                    if (strLastName ==(id)[NSNull null] || [strLastName isEqualToString:@""] || strLastName==nil || [strLastName length]==0 || [strLastName isEqualToString:@"<null>"]) {
                        
                        lastName = @"";
                    }
                    else
                    {
                        lastName=[result objectForKey:@"LastName"];
                    }
                    
                    NSString *strRemoveSpace =[NSString stringWithFormat:@"%@ %@",firstName,lastName];

                  //  NSString *strName = [strRemoveSpace stringByTrimmingCharactersInSet:
                                   //   [NSCharacterSet whitespaceCharacterSet]];

                    _lblName.text=[strRemoveSpace stringByTrimmingCharactersInSet:
                                   [NSCharacterSet whitespaceCharacterSet]];
                    
                    
                    NSString *ValidTo=[NSString stringWithFormat:@"%@",[result objectForKey:@"ValidTo"]];
                   
                    if (ValidTo ==(id)[NSNull null] || [ValidTo isEqualToString:@""] || ValidTo==nil || [ValidTo length]==0 || [ValidTo isEqualToString:@"<null>"]) {
                        
                    _lblMembershipExpireDate.text=@"";
                        
                    }
                    else
                    {
                        NSString *ValidTo=[NSString stringWithFormat:@"%@",[result objectForKey:@"ValidTo"]];

                         NSString *subString = [ValidTo substringToIndex:10];
                        _lblMembershipExpireDate.text=subString;
                    }
                    
                    
                }
                
            }
            
            
        }
        
    }
    
    
   }


-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:1.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}
- (IBAction)SearchDiamondClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)CalculatorClicked:(id)sender {
    
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];
    
}

- (IBAction)InboxClicked:(id)sender {
    
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)AccountSettingClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}


#pragma mark-Service call for date to price list web service

-(void)callServiceForLastListPriceSaved:(NSString *)completeURL paraeters:(NSString *)param
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
    
          //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:completeURL];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
               NSString *params = param;
            [urlRequest setHTTPMethod:@"GET"];
            [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
            [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
            [urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
            
            //Create task
         NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
                                              NSError* error1;
                                              NSDictionary *json1 = [NSJSONSerialization
                                                                     JSONObjectWithData:data options:kNilOptions error:&error1];
                                          
                                              NSDictionary *resultDict=[json1  valueForKey:@"Result"];
                                              
                                              NSArray *tableArray=[resultDict valueForKey:@"Table"];
                                              
                                              NSDictionary *lastUpdatedDateDict=[tableArray objectAtIndex:0];
                                              
                                              NSString *truncated=[[lastUpdatedDateDict valueForKey:@"UpdatedOn"] substringToIndex:10];
                                              
                                              NSLog(@"Truncated String  :%@",truncated);

                                              [Constant setDateFromService:truncated];
                                          }];
        [dataTask resume];
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
}

-(void)callServiceForBanerAd
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
        
        //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:@"http://webservice.cevaheer.com/api/Banner?PageName=Home%20Page"];
        //Home%20Page
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
       
        [urlRequest setHTTPMethod:@"GET"];
        [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
        [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
        //[urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
        
        //Create task
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
            NSError* error1;
            NSDictionary *json1 = [NSJSONSerialization
                                   JSONObjectWithData:data options:kNilOptions error:&error1];
            
            
            NSNumber *strStatus=[json1 valueForKey:@"Statuscode"];
            
            if (strStatus.integerValue==0 )
            {
                
                _BanerAdImageView.hidden=YES;
                
                
            }
            else
            {
                _BanerAdImageView.hidden=NO;

                NSDictionary *resultDict=[json1  valueForKey:@"Result"];
                
                NSArray *tableArray=[resultDict valueForKey:@"Table"];
                
                for (NSDictionary *result in tableArray) {
                    
                    
                    urlString=[result valueForKey:@"Bannerimage"];
                    
                    
                    
                    //   _BanerAdImageView = [UIImage animatedImageWithAnimatedGIFURL:[NSURL URLWithString:urlString]];
                    NSLog(@"callServiceForBanerAd :%@",json1);
                    
                    dispatch_queue_t imageQueue = dispatch_queue_create("Image Queue",NULL);
                    dispatch_async(imageQueue, ^{
                        
                        NSURL *url = [NSURL URLWithString:urlString];
                        //                    NSData *imageData = [NSData dataWithContentsOfURL:url];
                        //                    UIImage *image = [UIImage imageWithData:imageData];
                        
                        UIImage *loadingImage = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:url]];
                        
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            // Update the UI
                            
                            _BanerAdImageView.animationImages = loadingImage.images;
                            _BanerAdImageView.animationDuration = loadingImage.duration;
                            _BanerAdImageView.animationRepeatCount = 0;
                            _BanerAdImageView.image = loadingImage.images.lastObject;
                            [_BanerAdImageView startAnimating];
                        });
                        
                    });
                    
                }
                    
            }
          
           
           // [Constant setDateFromService:truncated];
        }];
        [dataTask resume];
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
}



@end
