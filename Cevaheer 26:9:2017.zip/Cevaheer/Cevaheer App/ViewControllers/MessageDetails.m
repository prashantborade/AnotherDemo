//
//  MessageDetails.m
//  Cevaheer App
//
//  Created by SMS on 04/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "MessageDetails.h"
#import "ReplyViewController.h"
#import "NewMail.h"
@interface MessageDetails ()

@end

@implementation MessageDetails

- (void)viewDidLoad {	
    [super viewDidLoad];

    _userNameLbl.text=_userName;
    _subjectLbl.text=_subjects;
    _MessageContentView.text=_messageContent;
    _MessageContentView.userInteractionEnabled=NO;
    
    NSLog(@"_FromEmail = %@",_FromEmail);
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnback:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnReplyClicked:(id)sender {
    
//    
//    _userNameLbl.text=@"To:";
//    _subjectLbl.text=@"";
//    _MessageContentView.text=@"Reply your message";
//    
//    _MessageContentView.userInteractionEnabled=YES;

    ReplyViewController *childvc=[[self storyboard]instantiateViewControllerWithIdentifier:@"ReplyViewController"];
    childvc.replyTOEmail=_FromEmail;
//   [self addChildViewController:childvc];
//    [self.view addSubview:childvc.view];
//   // _scroll.contentSize=CGSizeMake(self.view.frame.size.width, childvc.view.frame.size.height);
//    [childvc didMoveToParentViewController:self];
    
    [self.navigationController pushViewController:childvc animated:YES];
    
}

- (IBAction)btnForwardClicked:(id)sender {
    
    NewMail *NewMailVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"NewMail"];
    [self.navigationController pushViewController:NewMailVC animated:YES];

}
@end
