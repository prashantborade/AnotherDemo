//
//  MyListingCell.h
//  Cevaheer App
//
//  Created by  on 10/4/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyListingCell : UITableViewCell

//Outlets
@property (strong, nonatomic) IBOutlet UILabel *shapeLbl;
@property (strong, nonatomic) IBOutlet UILabel *colorClarityLbl;
@property (strong, nonatomic) IBOutlet UILabel *labLbl;
@property (strong, nonatomic) IBOutlet UILabel *cutLbl;
@property (strong, nonatomic) IBOutlet UILabel *polLbl;
@property (strong, nonatomic) IBOutlet UILabel *symLbl;
@property (strong, nonatomic) IBOutlet UILabel *florLbl;
@property (strong, nonatomic) IBOutlet UILabel *tabLbl;
@property (strong, nonatomic) IBOutlet UILabel *depLbl;
@property (strong, nonatomic) IBOutlet UILabel *mesLbl;
@property (strong, nonatomic) IBOutlet UILabel *locLbl;
@property (strong, nonatomic) IBOutlet UILabel *priceLbl;
@property (strong, nonatomic) IBOutlet UILabel *discountLbl;
@property (strong, nonatomic) IBOutlet UILabel *totalLbl;
@property (strong, nonatomic) IBOutlet UILabel *sellerLbl;
@property (strong, nonatomic) IBOutlet UIButton *btnNewMail;
@property (strong, nonatomic) IBOutlet UIButton *btnCalling;

- (IBAction)btnNewMailClicked:(id)sender;

- (IBAction)btnCallingClicked:(id)sender;


@end
