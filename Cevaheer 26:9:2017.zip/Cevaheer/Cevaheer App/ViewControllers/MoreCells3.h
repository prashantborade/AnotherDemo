//
//  MoreCells3.h
//  Cevaheer App
//
//  Created by SMS on 10/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreCells3 : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *LabName;
@end
