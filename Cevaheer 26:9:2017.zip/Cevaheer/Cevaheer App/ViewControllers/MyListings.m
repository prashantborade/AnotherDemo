//
//  MyListings.m
//  Cevaheer App
//
//  Created by  on 9/27/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MyListings.h"

@interface MyListings ()

@end

@implementation MyListings
#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [self.navigationItem setHidesBackButton:YES];
    //_menuView.alpha=0;
    _menuView.hidden=YES;
   // _transView.alpha=0;
    _transView.hidden=YES;
    
    
    //set index to -1 saying no cell is expanded should expand
    selectedIndex=-1;
    //to check expanded or not
    selectedIndexArray = [[NSMutableArray alloc]init];
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    UserID =[defaults valueForKey:@"UserId"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];
        
    _jsonArray=[[NSMutableArray alloc] init];
    
    webserviceClass=[[WebserviceClass alloc]init];
    NSString* parameterString=[NSString stringWithFormat:@"%@UserID=%@",MY_LISTING,UserID];
    [webserviceClass callServcieUsingRequestAndGET:parameterString:nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"URL=%@",FIND_PEOPLE);
    
    
    // Do any additional setup after loading the view.
}
#pragma mark - UITabVarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    if (item.tag==5)
    {
        MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
        [self.navigationController pushViewController:MemberProfileVC animated:YES];
    }
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _jsonArray.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"MyListingCell";
    
    MyListingCell *cell = (MyListingCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[MyListingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }

    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    NSString *strShape=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
    if (strShape ==(id)[NSNull null] || [strShape isEqualToString:@""] || strShape==nil || [strShape length]==0) {
        cell.shapeLbl.text=@"";
    }
    else
    {
        cell.shapeLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
    }
    
    
   
    NSString *strClarity=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"];
    NSString *CaratWeight=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];

    if ((strClarity ==(id)[NSNull null] || [strClarity isEqualToString:@""] || strClarity==nil || [strClarity length]==0 ) && (CaratWeight ==(id)[NSNull null] || [CaratWeight isEqualToString:@""] || CaratWeight==nil || [CaratWeight length]==0)) {
        cell.colorClarityLbl.text=@"";
    }
    else
    {
       cell.colorClarityLbl.text=[NSString stringWithFormat:@"%@%@%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"],@"ct",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
        
    }
    
    NSString *strLab=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Lab"];
    if (strLab ==(id)[NSNull null] || [strLab isEqualToString:@""] || strLab==nil || [strLab length]==0) {
        cell.labLbl.text=@"";
    }
    else
    {
        cell.labLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Lab"];
    }
    NSString *strCut=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Cut"];
    if (strCut ==(id)[NSNull null] || [strCut isEqualToString:@""] || strCut==nil || [strCut length]==0) {
        cell.cutLbl.text=@"";
    }
    else
    {
        cell.cutLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Cut"];
    }
    
    NSString *strPolish=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
    if (strPolish ==(id)[NSNull null] || [strPolish isEqualToString:@""] || strPolish==nil || [strPolish length]==0) {
        cell.polLbl.text=@"";
    }
    else
    {
        cell.polLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
    }

    NSString *strSymmetry=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
    if (strSymmetry ==(id)[NSNull null] || [strSymmetry isEqualToString:@""] || strSymmetry==nil || [strSymmetry length]==0) {
        cell.symLbl.text=@"";
    }
    else
    {
        cell.symLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
    }
    
    NSString *strFlour=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Flour"];
    if (strFlour ==(id)[NSNull null] || [strFlour isEqualToString:@""] || strFlour==nil || [strFlour length]==0) {
        cell.florLbl.text=@"";
    }
    else
    {
        cell.florLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Flour"];
    }
    
    NSString *strTable=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
    if (strTable ==(id)[NSNull null] || [strTable isEqualToString:@""] || strTable==nil || [strTable length]==0) {
        cell.tabLbl.text=@"";
    }
    else
    {
        cell.tabLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
    }
    
    NSString *strDepth=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];
    if (strDepth ==(id)[NSNull null] || [strDepth isEqualToString:@""] || strDepth==nil || [strDepth length]==0) {
        cell.depLbl.text=@"";
    }
    else
    {
        cell.depLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];;
    }
    
    NSString *strMeasurW=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
    if (strMeasurW ==(id)[NSNull null] || [strMeasurW isEqualToString:@""] || strMeasurW==nil || [strMeasurW length]==0) {
        cell.mesLbl.text=@"";
    }
    else
    {
        cell.mesLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
    }
    
    NSString *strCountry=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
    NSString *strState=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"];
    if ((strCountry ==(id)[NSNull null] || [strCountry isEqualToString:@""] || strCountry==nil || [strCountry length]==0) || (strState ==(id)[NSNull null] || [strState isEqualToString:@""] || strState==nil || [strState length]==0)) {
        cell.locLbl.text=@"";
    }
    else
    {
        cell.locLbl.text=[NSString stringWithFormat:@"%@%@", [[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"], [[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"]];
    
    }
    
    NSString *AskingPrice=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"AskingPrice"]];
    if (AskingPrice ==(id)[NSNull null] || [AskingPrice isEqualToString:@""] || AskingPrice==nil || [AskingPrice length]==0) {
        cell.priceLbl.text=@"";
    }
    else
    {
        cell.priceLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"AskingPrice"]];
    }

    NSString *Discount=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
    if (Discount ==(id)[NSNull null] || [Discount isEqualToString:@""] || Discount==nil || [Discount length]==0) {
        cell.discountLbl.text=@"";
    }
    else
    {
        cell.discountLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
    }

    NSString *Total=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Total"]];
    if (Total ==(id)[NSNull null] || [Total isEqualToString:@""] || Total==nil || [Total length]==0) {
        cell.totalLbl.text=@"";
    }
    else
    {
        cell.totalLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Total"]];
    }

    NSString *Seller=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Seller"]];
    if (Seller ==(id)[NSNull null] || [Seller isEqualToString:@""] || Seller==nil || [Seller length]==0) {
        cell.sellerLbl.text=@"";
    }
    else
    {
        cell.sellerLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Seller"]];
    }
    
    cell.btnNewMail.hidden=YES;
    cell.btnCalling.hidden=YES;
    
    
   // [cell.btnNewMail addTarget:self action:@selector(newMail) forControlEvents:UIControlEventTouchUpInside];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // user tap selected row
    NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    if ([selectedIndexArray containsObject:str]) {
        
        
        [selectedIndexArray removeObject:str];
        selectedIndex = -1;
        
        
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        
        return;
    }
      //if user taps new row with none expanded
    selectedIndex = (int)indexPath.row;
    [selectedIndexArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
    
    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
            //        cell.lblSubjectHeight.constant=60;
            //        cell.lblSubjectIDHeight.constant=60;
            NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
            if ([selectedIndexArray containsObject:str]) {
                
                return 133;
            }
            else
            {
                return 40;
            }
            
        }
        else
        {
            NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
            if ([selectedIndexArray containsObject:str]) {
                
                return 310;
            }
            else
            {
                return 38;
            }
            
            
        }
        
}

-(void)newMail
{
  
    NewMail *NewMailVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"NewMail"];
    
    [self.navigationController pushViewController:NewMailVC animated:YES];
    
}

#pragma mark - IBActions

- (IBAction)btnMenuClicked:(UIButton*)sender {
    sender.selected=!sender.selected;
    [UIView animateWithDuration:0.3 animations:^{
        if (sender.selected)
        {
            _menuView.hidden=NO;
            //_menuView.alpha=1;
            //_transView.alpha=1;
            _transView.hidden=NO;
            
        }
        else
        {
            _menuView.hidden=YES;
            //_menuView.alpha=0;
            //_transView.alpha=0;
            _transView.hidden=YES;
            
        }
    }];
}
- (IBAction)btnAccountSettingsClicked:(id)sender {

    AccountSetting *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"AccountSetting"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnCalculatorClicked:(id)sender {
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnLogoutClicked:(id)sender {
    LoginViewController *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnMyListingsClicked:(id)sender {
    
}

- (IBAction)btnFindDiamondsClicked:(id)sender {
}

- (IBAction)btnFindPeopleClicked:(id)sender {
    FindPeople *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindPeople"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnMessageClicked:(id)sender {
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];
}


- (IBAction)btnSIdeMenuClicked:(id)sender {
    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];
}

- (IBAction)btnHomeClicked:(id)sender {
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];
}

- (IBAction)btnSmileClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];

    
}

- (IBAction)btnMyProfileClicked:(id)sender {
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}


-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];

        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
              //  [self showMessage];
            }
            else
            {
                
                NSDictionary *subDict= [json objectForKey:@"Result"];
                
                _jsonArray = [subDict objectForKey:@"Table"];

                
            }
            
        }
    
    [self.tableView reloadData];

}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}

- (IBAction)btnFooterHomeClicked:(id)sender {
    
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];

}

- (IBAction)btnFooterMessageClicked:(id)sender {
    
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];

    
}

- (IBAction)btnFooterFindDiamondClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnFooterMemberProfileClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}
@end
