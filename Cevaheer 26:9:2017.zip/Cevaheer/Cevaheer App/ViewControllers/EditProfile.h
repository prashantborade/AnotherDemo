//
//  EditProfile.h
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebserviceClass.h"
@interface EditProfile : UIViewController<UITextFieldDelegate>
{
        
        WebserviceClass *webserviceClass;
        NSDictionary *json;
        NSString *Statuscode;
        NSString *Message;
        NSString *strEmail;
        NSString *oldPasswordCheck;
        int flag,flag1;
    
    
}

#pragma mark - Outlets

@property (strong, nonatomic) IBOutlet UITextField *txtFirstName;
@property (strong, nonatomic) IBOutlet UITextField *txtLastName;
@property (strong, nonatomic) IBOutlet UITextField *txtCompanyName;
@property (strong, nonatomic) IBOutlet UITextField *txtPhone;
@property (strong, nonatomic) IBOutlet UITextField *txtOldPassword;
@property (strong, nonatomic) IBOutlet UITextField *txtNewPassword;


@property (strong, nonatomic) IBOutlet UIButton *btnSave;
@property(nonatomic,strong) NSMutableArray *jsonArray;
@property (strong, nonatomic) IBOutlet UIButton *changePassword;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *changePasswordConstraint;


#pragma Mark - IBAction 

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSaveClicked:(id)sender;
- (IBAction)btnChangePwdClicked:(id)sender;

@end
