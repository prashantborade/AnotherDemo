//
//  AccountSetting.h
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditProfile.h"
#import "WebserviceClass.h"
@interface AccountSetting : UIViewController<WebserviceProtocol>
{
    
        WebserviceClass *webserviceClass;
        NSDictionary *json;
        NSString *Statuscode;
        NSString *Message;
        NSString *strEmail;
    
    
}
@property(nonatomic,strong) NSMutableArray *jsonArray;

#pragma mark - Outlets

@property (strong, nonatomic) IBOutlet UITextView *textViewUserName;
@property (strong, nonatomic) IBOutlet UITextView *textViewCompName;
@property (strong, nonatomic) IBOutlet UITextView *textViewPhone;
@property (strong, nonatomic) IBOutlet UITextView *textViewPassword;
@property(nonatomic,strong) NSString *strFirstName;
@property(nonatomic,strong) NSString *strLastName;


#pragma mark - IBAction

- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnEditClicked:(id)sender;

@end
















