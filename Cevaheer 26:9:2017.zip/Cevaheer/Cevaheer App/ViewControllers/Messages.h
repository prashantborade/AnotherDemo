//
//  Messages.h
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MessageCell.h"
#import "NewMail.h"
#import "WebserviceClass.h"
#import "MessageResult.h"
#import "MemberProfile.h"
#import "MyListings.h"
#import "FindDiamond.h"
#import "WelcomeViewController.h"
#import "Calculator.h"

#import <Google/Analytics.h>
#import "GAITrackedViewController.h"




@interface Messages : GAITrackedViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,WebserviceProtocol,MBProgressHUDDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *MessageID;

    BOOL isFiltered;
    NSMutableArray *filteredReciveArray;
    NSMutableArray *filteredSentArray;
    
    
    int flag;
    int flagg;
    
}


#pragma mark - Outlets

@property (weak, nonatomic) IBOutlet UITableView *tblvwMessages;
@property (strong, nonatomic) IBOutlet UIButton *btnInbox;
@property (strong, nonatomic) IBOutlet UIButton *btnSentItem;
@property(nonatomic,strong) NSMutableArray *jsonArrayRecived;
@property(nonatomic,strong) NSMutableArray *jsonArraySentMessage;
@property(nonatomic,strong) NSString *strFromEmail;
@property(nonatomic,strong) NSString *strToEmail;

@property (strong, nonatomic) IBOutlet UISearchBar *searBar;

#pragma mark- Passing Parameter
@property(nonatomic,strong) NSString *struserName;
@property(nonatomic,strong) NSString *strsubjects;
@property(nonatomic,strong) NSString *strmessageContent;




#pragma mark - Footer Navigation 
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnFindDiamondClicked:(id)sender;
- (IBAction)btnCalculatorClicked:(id)sender;
- (IBAction)btnMemberProfileClicked:(id)sender;


#pragma marrk - Actions

- (IBAction)btnInboxClicked:(id)sender;
- (IBAction)btnSentItemClicked:(id)sender;
- (IBAction)btnCloseClicked:(id)sender;
- (IBAction)btnNewEmailClicked:(id)sender;

#pragma mark - WebParameter
@property(nonatomic,strong) NSString *emailAddress;


@end
