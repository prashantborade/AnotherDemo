//
//  MoreCell2.m
//  Cevaheer App
//
//  Created by SMS on 10/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "MoreCell2.h"

@implementation MoreCell2

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
