//
//  CalculationsCell.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CalculationsCell : UITableViewCell

@end
