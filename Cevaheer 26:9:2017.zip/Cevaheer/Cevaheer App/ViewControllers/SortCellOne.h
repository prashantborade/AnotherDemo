//
//  SortCellOne.h
//  Cevaheer App
//
//  Created by SMS on 11/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SortCellOne : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
@property (strong, nonatomic) IBOutlet UILabel *lblSortOneName;
- (IBAction)btnCancelClicked:(id)sender;

@end
