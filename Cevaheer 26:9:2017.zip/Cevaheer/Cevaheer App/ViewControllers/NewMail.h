//
//  NewMail.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebserviceClass.h"



@interface NewMail : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,WebserviceProtocol,MBProgressHUDDelegate,UITextViewDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *strReciverID;
    
    NSMutableArray *arrOfEmails;
    NSMutableArray *searchArray;
    NSString *searchTextString;
    BOOL isFilter;

    
}


#pragma  mark - Outelets
@property (strong, nonatomic) IBOutlet UITextField *txtTo;
@property (strong, nonatomic) IBOutlet UITextField *txtSubject;
@property (strong, nonatomic) IBOutlet UITextView *textViewBody;
@property (strong, nonatomic) IBOutlet UITableView *searchTable;

#pragma mark -Passing Parameter
@property(nonatomic,strong)NSString *sellerEmailID;
@property(nonatomic,strong)NSString *strStockNumber;
@property(nonatomic,strong)NSString *strShape;
@property(nonatomic,strong)NSString *TotalCount;
@property(nonatomic,strong)NSString *strCarat;
@property(nonatomic,strong)NSString *strColor;
@property(nonatomic,strong)NSString *strClarity;


#pragma mark - IBAction
- (IBAction)btnBackClicked:(id)sender;
- (IBAction)btnSendClicked:(id)sender;

@end
