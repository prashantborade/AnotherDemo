//
//  ParcelDiamondSearch.m
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "ParcelDiamondSearch.h"

@interface ParcelDiamondSearch ()

@end

@implementation ParcelDiamondSearch
#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     Marquise_Black
     Marquise
     Heart_Black
     Heart
     Oval_Black
     Oval
     Pear_Black
     Pear
     Round_Black
     Round
     EmeraId_Black
     EmeraId
     Princess_Black
     Princess
     */
    
    
    
    [_btnMarquise setImage:[UIImage imageNamed:@"Marquise_Black"] forState:UIControlStateNormal];
    [_btnMarquise setImage:[UIImage imageNamed:@"Marquise"] forState:UIControlStateSelected];
    
    [_btnHeart setImage:[UIImage imageNamed:@"Heart_Black"] forState:UIControlStateNormal];
    [_btnHeart setImage:[UIImage imageNamed:@"Heart"] forState:UIControlStateSelected];
    
    [_btnOval setImage:[UIImage imageNamed:@"Oval_Black"] forState:UIControlStateNormal];
    [_btnOval setImage:[UIImage imageNamed:@"Oval"] forState:UIControlStateSelected];
    
    [_btnPear setImage:[UIImage imageNamed:@"Pear_Black"] forState:UIControlStateNormal];
    [_btnPear setImage:[UIImage imageNamed:@"Pear"] forState:UIControlStateSelected];
    
    [_btnRound setImage:[UIImage imageNamed:@"Round_Black"] forState:UIControlStateNormal];
    [_btnRound setImage:[UIImage imageNamed:@"Round"] forState:UIControlStateSelected];
    
    [_btnEmeraId setImage:[UIImage imageNamed:@"EmeraId_Black"] forState:UIControlStateNormal];
    [_btnEmeraId setImage:[UIImage imageNamed:@"EmeraId"] forState:UIControlStateSelected];
    
    [_btnPrincess setImage:[UIImage imageNamed:@"Princess_Black"] forState:UIControlStateNormal];
    [_btnPrincess setImage:[UIImage imageNamed:@"Princess"] forState:UIControlStateSelected];
    
    _tblVwMore.tableFooterView=[UIView new];
    
    // Do any additional setup after loading the view.
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"MoreCell";
    
    MoreCell *cell = (MoreCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[MoreCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[KGModal sharedInstance]hideAnimated:YES];
    //    MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
    //    [self.navigationController pushViewController:MemberInfoVC animated:YES];
    
}

#pragma mark - IBActions
- (IBAction)btnResetClicked:(id)sender {
}

- (IBAction)btnSearchClicked:(id)sender {
    
    SearchDiamondResult *SearchDiamondResultVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"SearchDiamondResult"];
    [self.navigationController pushViewController:SearchDiamondResultVC animated:YES];
}
- (IBAction)btnRoundClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
    
}
- (IBAction)btnEmeraIdClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnPearClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnPrincessClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnOvalClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnCushionClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnCusModClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnHeartClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnMarquiseClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}
- (IBAction)btnRadiantClicked:(UIButton*)sender
{
    sender.selected=!sender.selected;
}

- (IBAction)btnShapeMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

- (IBAction)btnColorMoreClicked:(id)sender {
    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
