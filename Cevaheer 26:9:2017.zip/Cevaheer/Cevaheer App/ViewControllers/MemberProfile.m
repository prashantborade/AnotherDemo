//
//  MemberProfile.m
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MemberProfile.h"

@interface MemberProfile ()

@end

@implementation MemberProfile

- (void)viewDidLoad {
    
     [super viewDidLoad];
    _pickerViewCompanyType.delegate=nil;
    _pickerViewCompanyType.dataSource=nil;
    
    Lid=@"";
    language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    NSLog(@"Current language =%@",language);
    
    [_companyTypeArray removeAllObjects];
    [_CountryArry removeAllObjects];

    
    _pickerViewCountry.delegate=nil;
    _pickerViewCountry.dataSource=nil;
   
    
    _btnCompanyType.layer.borderWidth = 1;
    _btnCompanyType.layer.borderColor = [[UIColor blackColor] CGColor];
    _btnCompanyType.layer.cornerRadius = 5;
    
    
    
    _btnCountry.layer.borderWidth = 1;
    _btnCountry.layer.borderColor = [[UIColor blackColor] CGColor];
    _btnCountry.layer.cornerRadius = 5;
     
    
    
    [_btnCompanyType setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateSelected];
    [_btnCountry setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateSelected];

   
    self.navigationController.navigationBar.backgroundColor=[UIColor redColor];
    self.navigationController.navigationBar.hidden=YES;
 
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strUserID= [defaults valueForKey:@"UserId"];
    strEmail= [defaults valueForKey:@"EmailAddress"];

    [defaults synchronize];

    flag=0;
    flag1=0;
    flag2=0;
    flagCompanyType=0;
    flagCity=0;
    flagCountry=0;
    flagState=0;
    
    _txtDiamondListed.userInteractionEnabled=NO;
    
    [_btnCompanyType setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnCountry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _btnCompanyType.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    _btnCountry.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [_btnCompanyType.titleLabel setFont:[UIFont fontWithName:@"Helvetica" size:14]];
    [_btnCountry.titleLabel setFont:[UIFont fontWithName:@"Helvetica" size:14]];
    
    _btnCompanyType.titleLabel.text=@"";
    _btnCountry.titleLabel.text=@"";
    
    
//    _btnCompanyType.titleLabel.textColor=[UIColor blackColor];
//    _btnCountry.titleLabel.textColor=[UIColor blackColor];
    
    //For ComboBox table
    _pickerViewCompanyType.hidden=YES;
    _pickerViewCountry.hidden=YES;
    _pickerViewCompanyType.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
    _pickerViewCountry.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
    
    
    _companyTypeArray=[[NSMutableArray alloc]init];
    _CountryArry=[[NSMutableArray alloc] init];
    _jsonArray=[[NSMutableArray alloc] init];
    _jsonArrayCompanyType=[[NSMutableArray alloc] init];
    _jsonArrayCountry=[[NSMutableArray alloc] init];
    
    
     [self initializeView];
   

    _txtOldPassword.delegate=self;
    _txtNewPassword.delegate=self;
    _txtConfirmPassword.delegate=self;

    

    _txtTelephone.delegate=self;
//    _txtCompanyType.delegate=self;
//    _txtCountry.delegate=self;
    _txtState.delegate=self;
    _txtDiamondListed.delegate=self;
    _txtCity.delegate=self;
    
    
    
//    _txtCompanyType.rightViewMode = UITextFieldViewModeAlways;
//    _txtCompanyType.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dropdown"]];
//    
   
    
//    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didRecognizeTapGestureForCompanyType:)];
//    [self.txtCompanyType.superview addGestureRecognizer:tapGesture];
    
//    _txtCountry.rightViewMode = UITextFieldViewModeAlways;
//    _txtCountry.rightView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dropdown"]];
    
    
//    UITapGestureRecognizer *tapGesture1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didRecognizeTapGestureForCountryType:)];
//    [self.txtCountry.superview addGestureRecognizer:tapGesture1];
//    
    
    //_txtCountry.keyboardType=
    
    self.scrollVIewOutlet.delaysContentTouches = YES;
    self.scrollVIewOutlet.canCancelContentTouches = NO;
    
    // Do any additional setup after loading the view.
    
   // _btnCountry.titleLabel.text=@"Turkey";
    self.screenName=@"Account Setting";
    
}

#pragma mark - Picker View Data source
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    
    if(pickerView == _pickerViewCompanyType)
    {
         return 1;
    }
    else
    {
         return 1;
    }

}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    
    if(pickerView == _pickerViewCompanyType)
    {
        return _companyTypeArray.count;
    }
    else
    {
        return _CountryArry.count;
    }
    
}

#pragma mark- Picker View Delegate
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    // [myTextField setText:[pickerArray objectAtIndex:row]];
    
    if(pickerView == _pickerViewCompanyType)
    {
        
     [_btnCompanyType setTitle:[_companyTypeArray objectAtIndex:row] forState:UIControlStateNormal];
     _pickerViewCompanyType.hidden=YES;
    }
    else
    {
   
     [_btnCountry setTitle:[_CountryArry objectAtIndex:row] forState:UIControlStateNormal];
     _pickerViewCountry.hidden=YES;
    
    }
    
    
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if(pickerView == _pickerViewCompanyType)
    {
        
        return [_companyTypeArray objectAtIndex:row];
        
    }
    else
    {
        return [_CountryArry objectAtIndex:row];
        
    }
    
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    if(pickerView == _pickerViewCompanyType)
    {
        
        return 20;
        
    }
    else
    {
        return 20;
        
    }
    return 20;
}
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    
    if(pickerView ==_pickerViewCompanyType)
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:14]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            //[tView setTextAlignment:UITextAlignmentLeft];
            
        }
        // Fill the label text here
        tView.text=[_companyTypeArray objectAtIndex:row];
        return tView;
        
    }
    else
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:14]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            
        }
        // Fill the label text here
        tView.text=[_CountryArry objectAtIndex:row];
        return tView;
        
    }
    
}

#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - IBActions
- (IBAction)brnBackClicked:(id)sender {
    

    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];
    
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];

    
//    WelcomeViewController *welcomeViewController=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
//    [self.navigationController pushViewController:welcomeViewController animated:NO];
    
    //[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnEditClicked:(id)sender {
//    //UpdateProfile
//    UpdateProfile *UpdateProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"UpdateProfile"];
//    [self.navigationController pushViewController:UpdateProfileVC animated:YES];
}
-(void)viewWillAppear:(BOOL)animated
{
    webserviceClass=[[WebserviceClass alloc] init];
    [self memberProfile];
}
-(void)initializeView
{
    [_btnPopupSave setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_btnCancelPopup setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    
    
      _btnPopupSave.layer.borderWidth=1.0F;
      _btnCancelPopup.layer.borderWidth=1.0F;
      _txtOldPassword.layer.borderWidth=1.0F;
      _txtNewPassword.layer.borderWidth=1.0F;
      _txtConfirmPassword.layer.borderWidth=1.0F;
    
    _btnPopupSave.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _btnCancelPopup.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtOldPassword.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtNewPassword.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtConfirmPassword.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;

}

#pragma mark Webservice Methods
-(void)getComapanyType
{
    
    NSString* parameterString=[NSString stringWithFormat:@"%@Lid=%@",GET_BUSSINESSTYPE,Lid];
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"%@",parameterString);
}
-(void)getCountry
{
       NSString* parameterString=[NSString stringWithFormat:@"%@LID=%@",GET_COUNTRYLIST,Lid];
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"%@",parameterString);
}

-(void)changePassword
{
    if ([_txtOldPassword.text isEqualToString:@""]) {
        
        [self showMessage:NSLocalizedString(@"OLD_PWD",@"Please enter Old Password!")];
        
    }else if ([_txtNewPassword.text isEqualToString:@""])
    {
        [self showMessage:NSLocalizedString(@"NEW_PWD",@"Please enter New Password!")];
        
    }else if ([_txtConfirmPassword.text isEqualToString:@""])
    {
        [self showMessage:NSLocalizedString(@"CONfIRM_PWD",@"Please enter Confirm Password!")];
    }
    else
    {
        
        if ([_txtNewPassword.text isEqualToString:_txtConfirmPassword.text]) {
            
            NSString *strRequest=CHANGE_PASSWORD;
            NSString *parameterString=[NSString stringWithFormat:@"UserId=%@&Password=%@&Newpassword=%@",strUserID,_txtOldPassword.text,_txtNewPassword.text];
            
            strRequest=[strRequest stringByAppendingString:parameterString];
            
            [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
        }
        else
        {
            [self showMessage:NSLocalizedString(@"CONfIRMNOT_PWD",@"ConfirmPassword not matched with Password!")];
        }

}
    
}
-(void)editUserProfile
{
    
    
    NSString *strTruncateCountry=[_btnCountry.titleLabel.text stringByTrimmingCharactersInSet:
                           [NSCharacterSet whitespaceCharacterSet]];
    
    NSString *strTruncateCompanyType=[_btnCompanyType.titleLabel.text stringByTrimmingCharactersInSet:
                           [NSCharacterSet whitespaceCharacterSet]];

       NSString *strRequest=EDIT_USER_PROFILE;
    NSString *parameterString=[NSString stringWithFormat:@"UserId=%@&FirstName=%@&LastName=%@&Companyname=%@&CompanyType=%@&CompanyId=%@&Location=%@&Country=%@&State=%@&City=%@&Telephone=%@&Website=%@",strUserID,_firstNameLbl.text,_lastNameLbl.text,_compNameLbl.text,strTruncateCompanyType,@"",@"",strTruncateCountry,_txtState.text,_txtCity.text,_txtTelephone.text,@""];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];
    
    strRequest=[strRequest stringByAppendingString:encodedUrl];
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"URL=%@",strRequest);
    
}

-(void)memberProfile
{
    
    if ( [language isEqualToString:@"en-US"] ||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
    {
        
        Lid=@"1";
    }
    else
    {
        Lid=@"2";
    }
    NSString *strRequest=ACCOUNT_SETTING;
    NSString *parameterString=[NSString stringWithFormat:@"EmailId=%@&Lid=%@",strEmail,Lid];
    
    strRequest=[strRequest stringByAppendingString:parameterString];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"URL=%@",parameterString);

}
- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    
    if (flag ==1) {
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
                [self showMessage:Message];
            
            }
        }
    }
    else if(flag1 == 1)
    {
        flag1=0;
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage:Message];
                
            }
            else
            {
                [self showMessage:Message];
               
                
            }
        }

    }
    else if(flagCompanyType == 1)
    {
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                    [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArrayCompanyType =[subDict objectForKey:@"Table"];
                    
                    
                     for (NSDictionary *result in _jsonArrayCompanyType) {
                         
                       
                         if (![[result objectForKey:@"Type"] isEqualToString:@"null"]) {
                             
                               [_companyTypeArray addObject:[result objectForKey:@"Type"]];
                         }

                         
                     }
                   
                    NSMutableArray *secondArray = [[NSMutableArray alloc]init];
                    secondArray = [[NSMutableArray alloc]initWithArray:_companyTypeArray];
                    //    NSArray * arr1 = [[NSArray alloc] init];
                    //    arr1 = [NSArray arrayWithObjects:@"Hello 0", @"Hello 1", @"Hello 2", @"Hello 3", @"Hello 4", @"Hello 5", @"Hello 6", @"Hello 7", @"Hello 8", @"Hello 9",nil];
                    NSArray * arrImage = [[NSArray alloc] init];
                    arrImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], nil];
                    if(dropDown == nil) {
                        CGFloat f = 200;
                        dropDown = [[NIDropDown alloc]showDropDown:_companyTypeSenderId :&f :secondArray :arrImage :@"down"];
                        dropDown.delegate = self;
                    }
                    else {
                        [dropDown hideDropDown:_companyTypeSenderId];
                        //[self rel];
                        dropDown=nil;
                    }

                    //[_pickerViewCompanyType reloadAllComponents];
                }
            }
            
        }
    
    }
    else if(flagCountry == 1)
    {
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                    [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArrayCountry = [subDict objectForKey:@"Table"];
        
                    for (NSDictionary *result in _jsonArrayCountry) {
                        
                        if (![[result objectForKey:@"CountryName"] isEqualToString:@"nil"]) {
                            
                            [_CountryArry addObject:[result objectForKey:@"CountryName"]];
                        }
                        
                        
                    }
                    
                    NSMutableArray *firstArray = [[NSMutableArray alloc]init];
                    firstArray = [[NSMutableArray alloc]initWithArray:_CountryArry];
                    //    NSArray * arr1 = [[NSArray alloc] init];
                    //    arr1 = [NSArray arrayWithObjects:@"Hello 0", @"Hello 1", @"Hello 2", @"Hello 3", @"Hello 4", @"Hello 5", @"Hello 6", @"Hello 7", @"Hello 8", @"Hello 9",nil];
                    NSArray * arrImage = [[NSArray alloc] init];
                    arrImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], nil];
                    if(dropDown == nil) {
                        CGFloat f = 200;
                        dropDown = [[NIDropDown alloc]showDropDown:_countryId :&f :firstArray :arrImage :@"down"];
                        dropDown.delegate = self;
                    }
                    else {
                        [dropDown hideDropDown:_countryId];
                        //[self rel];
                        dropDown=nil;
                    }

                   // [_pickerViewCountry reloadAllComponents];
                    
                }
            }
            
        }
        
    }

    else
    {
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                    [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArray = [subDict objectForKey:@"Table"];
                    
                    for (NSDictionary *result in _jsonArray) {
                        
                        NSString *FirstName=[result objectForKey:@"FirstName"];
                        NSString *LastName=[result objectForKey:@"LastName"];
                        
                        if ((FirstName ==(id)[NSNull null] || [FirstName isEqualToString:@""] || FirstName==nil || [FirstName length]==0 || [FirstName  isEqualToString:@"<null>"]) || (LastName ==(id)[NSNull null] || [LastName isEqualToString:@""] || LastName==nil || [LastName length]==0 || [LastName  isEqualToString:@"<null>"]))
                        {
                            
                            _firstNameLbl.text=@"";
                            _lastNameLbl.text=@"";
                            
                            
                        }
                        else
                        {
                            
                            _firstNameLbl.text=[[result objectForKey:@"FirstName"] stringByTrimmingCharactersInSet:
                             [NSCharacterSet whitespaceCharacterSet]];
                            //_firstNameLbl.text=[result objectForKey:@"FirstName"];
                            _lastNameLbl.text=[[result objectForKey:@"LastName"] stringByTrimmingCharactersInSet:
                                                [NSCharacterSet whitespaceCharacterSet]];
                         //   _lastNameLbl.text=[result objectForKey:@"LastName"];

                        }
                        
                        
                        
                        
                        NSString *ValidFrom=[NSString stringWithFormat:@"%@",[result objectForKey:@"ValidFrom"]];
                        
                        if (ValidFrom == (id)[NSNull null] ||[ValidFrom isEqualToString:@""] || ValidFrom == nil || [ValidFrom length] ==0 || [ValidFrom  isEqualToString:@"<null>"])
                        {
                            _membershipExpireDateLbl.text=@"";
                        }
                        else
                        {
                            NSString *newString = [NSString stringWithFormat:@"%@",[result objectForKey:@"ValidFrom"]];
                            _membershipExpireDateLbl.text=[newString substringFromIndex:10];
                            
                        }
                        
                        
                        NSString *CompanyName=[NSString stringWithFormat:@"%@",[result objectForKey:@"CompanyName"]];
                        
                        if (CompanyName == (id)[NSNull null] ||[CompanyName isEqualToString:@""] || CompanyName == nil || [CompanyName length] ==0 || [CompanyName  isEqualToString:@"<null>"])
                        {
                            _compNameLbl.text=@"";
                        }
                        else
                        {
                             _compNameLbl.text=[result objectForKey:@"CompanyName"];
                        }
                        
                        NSString *TypeOfBusiness=[NSString stringWithFormat:@"%@",[result objectForKey:@"TypeOfBusiness1"]];
                        
                        if (TypeOfBusiness == (id)[NSNull null] ||[TypeOfBusiness isEqualToString:@""] || TypeOfBusiness == nil || [TypeOfBusiness length] ==0 || [TypeOfBusiness  isEqualToString:@"<null>"])
                        {
                           _btnCompanyType.titleLabel.text=@"";
                        }
                        else
                        {
                         //   _btnCompanyType.titleLabel.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"TypeOfBusiness1"]];
                            
                            [_btnCompanyType setTitle:[result objectForKey:@"TypeOfBusiness1"] forState:UIControlStateNormal];
                        }
                        
                        NSString *UserID=[NSString stringWithFormat:@"%@",[result objectForKey:@"UserID"]];
                        
                        if (UserID == (id)[NSNull null] ||[UserID isEqualToString:@""] || UserID == nil || [UserID length] ==0 || [UserID  isEqualToString:@"<null>"])
                        {
                            _txtCevaheerID.text=@"";
                        }
                        else
                        {
                            _txtCevaheerID.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"UserID"]];
                        }
                        
                        NSString *CityID=[NSString stringWithFormat:@"%@",[result objectForKey:@"CityName"]];
                        
                        if (CityID == (id)[NSNull null] ||[CityID isEqualToString:@""] || CityID == nil || [CityID length] ==0 || [CityID  isEqualToString:@"<null>"])
                        {
                            _txtCity.text=@"";
                        }
                        else
                        {
                            _txtCity.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"CityName"]];
                        }
                        
                        NSString *CountryName=[result objectForKey:@"CountryName"];
                        
                        if (CountryName == (id)[NSNull null] ||[CountryName isEqualToString:@""] || CountryName == nil || [CountryName length] ==0 || [CountryName  isEqualToString:@"<null>"])
                        {
                            _btnCountry.titleLabel.text=@"";
                        }
                        else
                        {
                           //_btnCountry.titleLabel.text=[result objectForKey:@"CountryName"];
                            
                            [_btnCountry setTitle:[result objectForKey:@"CountryName"] forState:UIControlStateNormal];
                        }
                        
                        NSString *StateID=[NSString stringWithFormat:@"%@",[result objectForKey:@"StateName"]];
                        
                        if (StateID == (id)[NSNull null] ||[StateID isEqualToString:@""] || StateID == nil || [StateID length] ==0 || [StateID  isEqualToString:@"<null>"])
                        {
                            _txtState.text=@"";
                        }
                        else
                        {
                            _txtState.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"StateName"]];
                        }
                        
                        
                        NSString *Dimondlistingcount=[NSString stringWithFormat:@"%@",[result objectForKey:@"Dimondlistingcount"]];
                        
                        if (Dimondlistingcount == (id)[NSNull null] ||[Dimondlistingcount isEqualToString:@""] || Dimondlistingcount == nil || [Dimondlistingcount length] ==0 || [Dimondlistingcount  isEqualToString:@"<null>"])
                        {
                            _txtDiamondListed.text=@"";
                        }
                        else
                        {
                            _txtDiamondListed.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"Dimondlistingcount"]];
                        }
                        
                        
                        NSString *BusinessPhone=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        
                        if (BusinessPhone == (id)[NSNull null] ||[BusinessPhone isEqualToString:@""] || BusinessPhone == nil || [BusinessPhone length] ==0 || [BusinessPhone  isEqualToString:@"<null>"])
                        {
                            _txtTelephone.text=@"";
                        }
                        else
                        {
                            _txtTelephone.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        }
                        
                    }
                    
                }
                
                
            }
            
        }

    }
    
    
}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:2.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}



- (IBAction)btnChangePasswordClicked:(UIButton *)sender {
    
    [[KGModal sharedInstance] showWithContentView:_popUpViewchangePwd andAnimated:YES];
     [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];
    
}


- (IBAction)btnCompanyTypeClicked:(id)sender {
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        // The device is an iPad running iOS 3.2 or later.
        [_companyTypeArray removeAllObjects];
        if ( [language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
        {
            
            Lid=@"1";
        }
        else
        {
            Lid=@"2";
        }
        
        _companyTypeSenderId=sender;
        
        flagCompanyType=1;
        flag2=1;
        flagCountry=0;
        
        // _pickerViewCompanyType.hidden=NO;
        [self getComapanyType];

    }
    else
    {
        // The device is an iPhone or iPod touch.
       
        [_companyTypeArray removeAllObjects];
        if ([language isEqualToString:@"en-US"] ||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
        {
            
            Lid=@"1";
        }
        else
        {
            Lid=@"2";
        }
        
        _companyTypeSenderId=sender;
        
        flagCompanyType=1;
        flag2=1;
        flagCountry=0;
        
        // _pickerViewCompanyType.hidden=NO;
        [self getComapanyType];

        
    }
    
    
    
   
}


- (IBAction)btnCountryClicked:(id)sender {
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        // The device is an iPad running iOS 3.2 or later.
        [_CountryArry removeAllObjects];
        if ( [language isEqualToString:@"en-US"] ||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"]) {
            
            Lid=@"1";
        }
        else
        {
            Lid=@"2";
        }
        
        _countryId = sender;
        flagCompanyType=0;
        flagCountry=1;
        flag2=1;
        
        //  _pickerViewCountry.hidden=NO;
        [self getCountry];

    }
    else
    {
        // The device is an iPhone or iPod touch.
        [_CountryArry removeAllObjects];
        if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"]) {
            
            Lid=@"1";
        }
        else
        {
            Lid=@"2";
        }
        
        _countryId = sender;
        flagCompanyType=0;
        flagCountry=1;
        flag2=1;
        
        //  _pickerViewCountry.hidden=NO;
        [self getCountry];

    
    }
    
    
    
    
}
- (void)viewDidUnload
{
    //    [btnSelect release];
    _btnCompanyType = nil;
    _btnCountry = nil;
    [self setBtnCompanyType:nil];
    [self setBtnCountry:nil];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void) niDropDownDelegateMethod: (NIDropDown *) sender
{
    // [self rel];
    NSLog(@"%@", _btnCompanyType.titleLabel.text);
    
    NSLog(@"Company is selected  %x",_btnCompanyType.selected);
    
    [_btnCompanyType setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateNormal];
    [_btnCountry setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateNormal];
    dropDown=nil;
}

- (IBAction)btnSaveClicked:(UIButton *)sender {
    
    
    if (flag2 == 1) {
        flag1=1;
        [self editUserProfile];
    }
   
  
}

- (IBAction)btnCancelPopUpClicked:(id)sender {
    

    [[KGModal sharedInstance] hide];
    
}
- (IBAction)btnPopupSaveClicked:(UIButton *)sender {
      flag=1;
    [self changePassword];
    [[KGModal sharedInstance] hide];
    
}




@end
