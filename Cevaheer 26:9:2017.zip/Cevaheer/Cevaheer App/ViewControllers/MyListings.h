//
//  MyListings.h
//  Cevaheer App
//
//  Created by  on 9/27/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AccountSetting.h"
#import "FindPeople.h"
#import "Messages.h"
#import "LoginViewController.h"
#import "MemberProfile.h"
#import "MyListingCell.h"
#import "FindDiamond.h"

@class WebserviceClass;

@interface MyListings : UIViewController<UITabBarDelegate>
{
    
    NSMutableArray *filteredArray;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *UserID;
    NSString *strColorValue;
    NSString *strClarityValue;
    NSMutableArray *selectedIndexArray;
    int selectedIndex;


    
}

- (IBAction)btnMenuClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *transView;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong) NSMutableArray *jsonArray;
@property (weak, nonatomic) IBOutlet UIView *menuView;

//Array
@property(nonatomic,strong) NSMutableArray *cut;
@property(nonatomic,strong) NSMutableArray*pol;
@property(nonatomic,strong) NSMutableArray *sym;
@property(nonatomic,strong) NSMutableArray *flor;
@property(nonatomic,strong) NSMutableArray *tab;
@property(nonatomic,strong) NSMutableArray*dep;
@property(nonatomic,strong) NSMutableArray *mes;
@property(nonatomic,strong) NSMutableArray *loc;




- (IBAction)btnAccountSettingsClicked:(id)sender;
- (IBAction)btnCalculatorClicked:(id)sender;
- (IBAction)btnLogoutClicked:(id)sender;
- (IBAction)btnMyListingsClicked:(id)sender;
- (IBAction)btnFindDiamondsClicked:(id)sender;
- (IBAction)btnFindPeopleClicked:(id)sender;
- (IBAction)btnMessageClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UITabBar *bottomBar;
- (IBAction)btnSIdeMenuClicked:(id)sender;
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnSmileClicked:(id)sender;
- (IBAction)btnMyProfileClicked:(id)sender;

#pragma mark - Footer Menu
- (IBAction)btnFooterHomeClicked:(id)sender;
- (IBAction)btnFooterMessageClicked:(id)sender;
- (IBAction)btnFooterFindDiamondClicked:(id)sender;
- (IBAction)btnFooterMemberProfileClicked:(id)sender;

@end
