
//  SearchDiamondResult.m
//  Cevaheer App
//
//  Created by  on 10/3/16.
//  Copyright © 2016 Mobility Team. All rights reserved.


#import "SearchDiamondResult.h"
#import "WhiteDiamondSearch.h"
#import "NewMail.h"
#define flag 0

@interface SearchDiamondResult ()
{
    NSString *urlString;
}

@end

@implementation SearchDiamondResult

#pragma mark - Lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    Lid=@"";
    language = [[NSLocale preferredLanguages] objectAtIndex:0];

    NSLog(@"language Code = %@",language);
    
    _btnLoadMore.hidden=YES;
    _UIViewFirst.hidden=YES;
    
    [_dynamicArray removeAllObjects];
    
    language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
   _strSearchKeyword =  [[NSUserDefaults standardUserDefaults] valueForKey:@"SerchKeyName"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self callServiceForBanerAd];

    // For Sorting Array
    _SortOneArray=[[NSMutableArray alloc] init];
    _SortTwoArray =[[NSMutableArray alloc] initWithObjects:NSLocalizedString(@"DISCOUNT",@"Discount"),NSLocalizedString(@"PRICE_CARA",@"Price"),NSLocalizedString(@"TOTAL",@"Total"),NSLocalizedString(@"SHAPE",@"Shape"),NSLocalizedString(@"SIZE_CARAT",@"Size"),NSLocalizedString(@"COLOR",@"Color"),NSLocalizedString(@"CLARITY",@"Clarity"),NSLocalizedString(@"CUT",@"Cut"),NSLocalizedString(@"LAB",@"Lab"),NSLocalizedString(@"SUPPLIER",@"Seller"), nil];
    
     strOrder=@"Asc";
    
   // [_btnAscending setTitle:[UIColor blueColor] forState:UIControlStateSelected];
   
    Pageindex=1;
    Pageindex1=1;
    flagg=0;

    flagg1=0;
    
    //set index to -1 saying no cell is expanded should expand
    selectedIndex=-1;
   //to check expanded or not
    selectedIndexArray = [[NSMutableArray alloc]init];
    _comaSeparatArray=[[NSMutableArray alloc] init];
    
    _jsonArray=[[NSMutableArray alloc] init];
    _dynamicArray=[[NSMutableArray alloc] init];
    _dynamicSortArray=[[NSMutableArray alloc] init];
    
    
    // for inital hide UI
    _UIViewHeader.hidden=YES;
    
    [self initialize];
  

    arrayOFEnglish=[[NSMutableArray alloc] init];
    arrayOFEnglish1=[[NSMutableArray alloc]initWithObjects:@"Discount",@"Price",@"Total",@"Shape",@"Size", @"Color",@"Clarity",@"Cut",@"Lab",@"Seller",nil];

    
    [_dynamicArray removeAllObjects];
    [self searchDiamondResult1];
    
    if (UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPhone)
    {
        NSBundle *frameworkBundle = [NSBundle bundleForClass:[self class]];
        UINib *nib = [UINib nibWithNibName:@"SearchDiamondCell" bundle:frameworkBundle];
        [[self tableView] registerNib:nib forCellReuseIdentifier:@"SearchDiamondCell"];
        
    }

  //  [_SortTwoArray objectAtIndex:0]
    
    // .keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
}
-(void)initialize
{
    [_btnAscending setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_btnSortCancel setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_btnSortSave setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    
    
    _btnAscending.layer.borderWidth=1.0F;
    _btnSortCancel.layer.borderWidth=1.0F;
    _btnSortSave.layer.borderWidth=1.0F;

    
    _btnAscending.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _btnSortCancel.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _btnSortSave.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
}



#pragma mark - UITableViewDataSource,UITableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    if (flagg1 == 1 && _tableView == tableView)
    {
        
        return _dynamicSortArray.count;
    }

    if (_tableView == tableView)
    {
        return _dynamicArray.count;
        
    }else if (_tblViewSortOne == tableView){
        
        return _SortOneArray.count;
    }
    else{
        
        return _SortTwoArray.count;
    }
    
   
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (flagg1 == 1 && _tableView == tableView) {
    
  
        @try {

        static NSString *cellIdentifier = @"SearchDiamondCell";
        
        SearchDiamondCell *cell = (SearchDiamondCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[SearchDiamondCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        // Alternate color for Cell
        
        if (indexPath.row%2 == 0) {
            
            cell.contentView.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
        }
        else{
            
            cell.contentView.backgroundColor=[UIColor colorWithRed:170/255.0 green:170/255.0 blue:170/255.0 alpha:1];
        }
        //243 243 255
        //211 211 211
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
            
        NSString *TotalCount=[NSString stringWithFormat:@"%@",[[_dynamicSortArray  objectAtIndex:indexPath.row] valueForKey:@"TotalCount"]];
            
        if (TotalCount == (id)[NSNull null] || [TotalCount isEqualToString:@""] || TotalCount == nil || [TotalCount length] == 0) {
                
                _TotalCount=@"";
        }
        else
        {
            TotalCount=[NSString stringWithFormat:@"%@",[[_dynamicSortArray  objectAtIndex:indexPath.row] valueForKey:@"TotalCount"]];
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                [_btnLoadMore setTitle:[NSString stringWithFormat:@"Load More  (%@)",_TotalCount] forState:UIControlStateNormal];
            }
            else
            {
                [_btnLoadMore setTitle:[NSString stringWithFormat:@"DAHA FAZLA YÜKLE  (%@)",_TotalCount] forState:UIControlStateNormal];
            }
        }
          
        NSString *strShape=[[_dynamicSortArray  objectAtIndex:indexPath.row] valueForKey:@"Shape"];
        
        if (strShape == (id)[NSNull null] || [strShape isEqualToString:@""] || strShape == nil || [strShape length] == 0) {
            
            cell.lblShapeValue.text=@"";
        }
        else
        {
            
            cell.lblShapeValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
            _Shape=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
            
        }
        
        
        NSString *strCaratRange=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
        
        if (strCaratRange == (id)[NSNull null] || [strCaratRange isEqualToString:@""] || strCaratRange == nil || [strCaratRange length] == 0) {
            
            cell.lblCaratValue.text=@"";
        }
        else
        {
            cell.lblCaratValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
            _Carat=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
        }
        
        NSString *strColorRange=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
        
        if (strColorRange == (id)[NSNull null] || [strColorRange isEqualToString:@""] || strColorRange == nil || [strColorRange length] == 0) {
            
            cell.lblColorValue.text=@"";
        }
        else
        {
            cell.lblColorValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
            _Color=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
        }
        
        NSString *strClarityRange=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
        
        if (strClarityRange == (id)[NSNull null] || [strClarityRange isEqualToString:@""] || strClarityRange == nil|| [strClarityRange length] == 0) {
            
            cell.lblClarityValue.text=@"";
        }
        else
        {
            cell.lblClarityValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
            _Clarity=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
        }
        
        NSString *strLab=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
        
        if (strLab == (id)[NSNull null] || [strLab isEqualToString:@""] ||strLab == nil || [strLab length] == 0) {
            
            cell.lblLabValue.text=@"";
            
        }
        else
        {
            cell.lblLabValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
            
         _strLabValue=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
            
        }
        
        
        NSString *strDiscount=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
        
        if (strDiscount == (id)[NSNull null] ||[strDiscount isEqualToString:@""] || strDiscount == nil || [strDiscount length] ==  0) {
            
            cell.lblDiscountValue.text=@"";
        }
        else
        {
            cell.lblDiscountValue.text=[NSString stringWithFormat:@"%@%%",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
            cell.lblDiscountValue.textColor=[UIColor redColor];
        }
        
            
        NSString *strCut=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Cut"]];
        
        if (strCut == (id)[NSNull null] ||[strCut isEqualToString:@""] || strCut == nil || [strCut length] ==  0) {
            
            cell.lblCutValue.text=@"";
        }
        else
        {
            cell.lblCutValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Cut"]];
            
            
        }
        
        
        NSString *strPolish=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
        
        if (strPolish == (id)[NSNull null] || [strPolish isEqualToString:@""] || strPolish == nil || [strPolish length] == 0) {
            
            cell.lblPolValue.text=@"";
        }
        else
        {
            cell.lblPolValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
            
        }
        
        NSString *strSymmetry=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
        
        if (strSymmetry == (id)[NSNull null] || [strSymmetry isEqualToString:@""] || strSymmetry == nil || [strSymmetry length] == 0) {
            
            cell.lblSymValue.text=@"";
        }
        else
        {
            cell.lblSymValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
            
        }
        
        NSString *strFluoIntensity=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"FluoIntensity"]];
        
        if (strFluoIntensity == (id)[NSNull null] || [strFluoIntensity isEqualToString:@""] || strFluoIntensity == nil || [strFluoIntensity length] == 0) {
            
            cell.lblFlorValue.text=@"";
        }
        else
        {
            cell.lblFlorValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"FluoIntensity"]];
            
        }
        
        NSString *strTABLE=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
        
        if (strTABLE == (id)[NSNull null] || [strTABLE isEqualToString:@""] || strTABLE == nil || [strTABLE length] == 0) {
            
            cell.lblTabValue.text=@"";
        }
        else
        {
            cell.lblTabValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
            
        }
        
        NSString *strDepth=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];
        
        if (strDepth == (id)[NSNull null] || [strDepth isEqualToString:@""] || strDepth == nil || [strDepth length] == 0) {
            
            cell.lblDepValue.text=@"";
        }
        else
        {
            cell.lblDepValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];
            
        }
        
            NSString *strMeasurL=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurL"]];
            
            if (strMeasurL == (id)[NSNull null] || [strMeasurL isEqualToString:@""] || strMeasurL == nil || [strMeasurL length] == 0) {
                
                MeasurL=@"";
            }
            else
            {
                MeasurL=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurL"]];
                
            }
            
            NSString *strMeasurW=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
            
            if (strMeasurW == (id)[NSNull null] || [strMeasurW isEqualToString:@""] || strMeasurW == nil || [strMeasurW length] == 0) {
                
                MeasurW=@"";
            }
            else
            {
                MeasurW=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
            }
            
            NSString *strMeasurD=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurD"]];
            
            if (strMeasurD == (id)[NSNull null] || [strMeasurD isEqualToString:@""] || strMeasurD == nil || [strMeasurD length] == 0) {
                
                MeasurD=@"";
            }
            else
            {
                MeasurD=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MeasurD"]];
                
            }
            
            if ((MeasurL == (id)[NSNull null] || [MeasurL isEqualToString:@""] || MeasurL == nil || [MeasurL length] == 0) || (MeasurW == (id)[NSNull null] || [MeasurW isEqualToString:@""] || MeasurW == nil || [MeasurW length] == 0) || (MeasurD == (id)[NSNull null] || [MeasurD isEqualToString:@""] || MeasurD == nil || [MeasurD length] == 0) ) {
                
                
                cell.lblMesValue.text=@"";
            }
            else
            {
                cell.lblMesValue.text=[NSString stringWithFormat:@"%@*%@*%@",MeasurL,MeasurW,MeasurD];
                
                
            }

        
        NSString *strSellerLocation=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"SellerLocation"];
        
        if (strSellerLocation == (id)[NSNull null] || [strSellerLocation isEqualToString:@""] || strSellerLocation == nil || [strSellerLocation length] == 0) {
            
            cell.lblLocValue.text=@"";
        }
        else
        {
            cell.lblLocValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"SellerLocation"];
            
        }
        
        
        NSString *strTotal=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Total"]];
        
        if (strTotal == (id)[NSNull null] || [strTotal isEqualToString:@""] || strTotal == nil || [strTotal length] == 0) {
            
            cell.lblTtlValue.text=@"";
        }
        else
        {
            cell.lblTtlValue.text=[NSString stringWithFormat:@"$%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Total"] ];
        }
        
        NSString *strSeller=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller"];
        
        if (strSeller == (id)[NSNull null] || [strSeller isEqualToString:@""] || strSeller == nil || [strSeller length] == 0)
        {
            cell.lblSlrValue.text=@"";
        }
        else
        {
            cell.lblSlrValue.text=[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller"];
        }
        
        NSString *strSellerEmail=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller Email"]];
        
        if (strSellerEmail == (id)[NSNull null] || [strSellerEmail isEqualToString:@""] || strSellerEmail == nil || [strSellerEmail length] == 0) {
            
            _sellerEmail=@"";
        }
        else
        {
            _sellerEmail=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"SellerEmail"]];
            
        }
        
        NSString *strSellerNumber=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]];
            
        if (strSellerNumber == (id)[NSNull null] || [strSellerNumber isEqualToString:@""] || strSellerNumber == nil || [strSellerNumber length] == 0) {
                
            SellerNumber=@"";
        }
        else
        {
         SellerNumber=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]];
                
         }
            
        NSString *strStockNumber=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
        
        if (strStockNumber == (id)[NSNull null] || [strStockNumber isEqualToString:@""] || strStockNumber == nil || [strStockNumber length] == 0) {
            
            cell.lblStkValue.text=@"";
            _StockNumber=@"";
            
        }
        else
        {
            cell.lblStkValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
            _StockNumber=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
        }
        
        NSString *MC=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"M/C"]];
            
        if (MC == (id)[NSNull null] || [MC isEqualToString:@""] || MC == nil || [MC length] == 0) {
                
                cell.lblMCValue.text=@"";
         }
        else
        {
            
             NSString *strMC = [NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"M/C"]];
            
            if ([strMC isEqualToString:@"M"]) {
                cell.lblMCValue.text=NSLocalizedString(@"MEMO", @"Memo");
            }
            else
            {
                 cell.lblMCValue.text=NSLocalizedString(@"CASH", @"Cash");
            }
                
        }
     
        NSString *PDF=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"checkse"]];
            
        if (PDF == (id)[NSNull null] || [PDF isEqualToString:@""] || PDF == nil || [PDF length] == 0) {
                
                _strPDF=@"";
          }
        else
        {
                _strPDF=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"checkse"]];
                
        }

        NSString *listprice=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"listprice"]];
            
        if (listprice == (id)[NSNull null] || [listprice isEqualToString:@""] || listprice == nil || [listprice length] == 0)
        {
                
               cell.lblListValue.text=@"";
        }
        else
        {
         cell.lblListValue.text=[NSString stringWithFormat:@"$%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"listprice"]];
                
        }

        NSString *pricepercarat=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"pricepercarat"]];
            
        if (pricepercarat == (id)[NSNull null] || [pricepercarat isEqualToString:@""] || pricepercarat == nil || [pricepercarat length] == 0)
        {
                
            cell.lblPcValue.text=@"";
        }
        else
        {
            cell.lblPcValue.text=[NSString stringWithFormat:@"$%.0f",
                                  ceil([[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"pricepercarat"] floatValue])];
                
        }
   
    
        NSString *MemberComment=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MemberComment"]];
            
        if (MemberComment == (id)[NSNull null] || [MemberComment isEqualToString:@""] || MemberComment == nil || [MemberComment length] == 0)
        {
                
            cell.lblLocValue.text=@"";
        }
        else
        {
            cell.lblLocValue.text=[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"MemberComment"]];
                
        }
            
       UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelTapped:)];
       tapGestureRecognizer.numberOfTapsRequired = 1;
            
       cell.lblLabValue.accessibilityIdentifier=_strPDF;
       [cell.lblLabValue addGestureRecognizer:tapGestureRecognizer];
           
            
            cell.btnCall.accessibilityIdentifier=[NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@",[[_dynamicSortArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]]];
        [cell.btnMessage addTarget:self action:@selector(newMailForMessage) forControlEvents:UIControlEventTouchUpInside];
            [cell.btnCall addTarget:self action:@selector(callNumber:) forControlEvents:UIControlEventTouchUpInside];
        
        if ([_strPDF isEqualToString:@""]) {
                
            cell.lblLabValue.textColor=[UIColor blackColor];
        }
        else
        {
            cell.lblLabValue.textColor=[UIColor blueColor];
        }
            return cell;
        }@catch(NSException *exception)
        {
            NSLog(@"Exception =%@",exception);
        }
    }
    
    if (_tableView == tableView)
    {
        NSString *CellIdentifier = @"SearchDiamondCell";
        SearchDiamondCell *cell = [_tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        
        if(cell == nil)
        {
        cell = [[SearchDiamondCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            
        }
        
        NSLog(@"_dynamicArray = %@",_dynamicArray);
        
        // Alternate color for Cell
        
        if (indexPath.row%2 == 0)
        {
            
            cell.contentView.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1];
        }
        else
        {
            
            cell.contentView.backgroundColor=[UIColor colorWithRed:170/255.0 green:170/255.0 blue:170/255.0 alpha:1];
        }
        
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        NSString *TotalCount=[NSString stringWithFormat:@"%@",[[_dynamicArray  objectAtIndex:indexPath.row] valueForKey:@"TotalCount"]];
        
        if (TotalCount == (id)[NSNull null] || [TotalCount isEqualToString:@""] || TotalCount == nil || [TotalCount length] == 0) {
            
            _TotalCount=@"";
        }
        else
        {
            _TotalCount=[NSString stringWithFormat:@"%@",[[_dynamicArray  objectAtIndex:indexPath.row] valueForKey:@"TotalCount"]];

            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                [_btnLoadMore setTitle:[NSString stringWithFormat:@"Load More  (%@)",_TotalCount] forState:UIControlStateNormal];
            }
            
            else
            {
                [_btnLoadMore setTitle:[NSString stringWithFormat:@"DAHA FAZLA YÜKLE  (%@)",_TotalCount] forState:UIControlStateNormal];
            }


        }
        
        NSString *strShape=[[_dynamicArray  objectAtIndex:indexPath.row] valueForKey:@"Shape"];
        
        if (strShape == (id)[NSNull null] || [strShape isEqualToString:@""] || strShape == nil || [strShape length] == 0) {
            cell.lblShapeValue.text=@"";
        }
        else
        {
            cell.lblShapeValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
            _Shape=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Shape"];
        }
        
        
        NSString *strCaratRange=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
        
        if (strCaratRange == (id)[NSNull null] || [strCaratRange isEqualToString:@""] || strCaratRange == nil || [strCaratRange length] == 0) {
            
            cell.lblCaratValue.text=@"";
        }
        else
        {
            cell.lblCaratValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
            _Carat=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"CaratWeight"]];
        }
        
        NSString *strColorRange=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
        
        if (strColorRange == (id)[NSNull null] || [strColorRange isEqualToString:@""] || strColorRange == nil || [strColorRange length] == 0) {
            
            cell.lblColorValue.text=@"";
        }
        else
        {
            cell.lblColorValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
            _Color=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Color"];
        }
        
        NSString *strClarityRange=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
        
        if (strClarityRange == (id)[NSNull null] || [strClarityRange isEqualToString:@""] || strClarityRange == nil|| [strClarityRange length] == 0) {
            
            cell.lblClarityValue.text=@"";
        }
        else
        {
            cell.lblClarityValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
            _Clarity=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Clarity"]];
        }
        
        NSString *strLab=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
        
        if (strLab == (id)[NSNull null] || [strLab isEqualToString:@""] ||strLab == nil || [strLab length] == 0) {
            
            cell.lblLabValue.text=@"";
            
        }
        else
        {
           
        
           cell.lblLabValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
            _strLabValue=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Lab"]];
        
            
        }
        
        
        NSString *strDiscount=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
        
        if (strDiscount == (id)[NSNull null] ||[strDiscount isEqualToString:@""] || strDiscount == nil || [strDiscount length] ==  0) {
            
            cell.lblDiscountValue.text=@"";
        }
        else
        {
            cell.lblDiscountValue.text=[NSString stringWithFormat:@"%@%%",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Discount"]];
             cell.lblDiscountValue.textColor=[UIColor redColor];
        }
        
        NSString *strCut=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Cut"]];
        
        if (strCut == (id)[NSNull null] ||[strCut isEqualToString:@""] || strCut == nil || [strCut length] ==  0) {
            
            cell.lblCutValue.text=@"";
        }
        else
        {
            cell.lblCutValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Cut"]];
            
        }
        
        
        NSString *strPolish=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
        
        if (strPolish == (id)[NSNull null] || [strPolish isEqualToString:@""] || strPolish == nil || [strPolish length] == 0) {
            
            cell.lblPolValue.text=@"";
        }
        else
        {
            cell.lblPolValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Polish"];
            
        }
        
        NSString *strSymmetry=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
        
        if (strSymmetry == (id)[NSNull null] || [strSymmetry isEqualToString:@""] || strSymmetry == nil || [strSymmetry length] == 0) {
            
            cell.lblSymValue.text=@"";
        }
        else
        {
            cell.lblSymValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Symmetry"];
            
        }
        
        NSString *strFluoIntensity=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"FluoIntensity"]];
        
        if (strFluoIntensity == (id)[NSNull null] || [strFluoIntensity isEqualToString:@""] || strFluoIntensity == nil || [strFluoIntensity length] == 0) {
            
            cell.lblFlorValue.text=@"";
        }
        else
        {
            cell.lblFlorValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"FluoIntensity"]];
            
        }
        
        
        NSString *strTABLE=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
        
        if (strTABLE == (id)[NSNull null] || [strTABLE isEqualToString:@""] || strTABLE == nil || [strTABLE length] == 0) {
            
            cell.lblTabValue.text=@"";
        }
        else
        {
            cell.lblTabValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Table"]];
            
        }
        
        NSString *strDepth=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];
        
        if (strDepth == (id)[NSNull null] || [strDepth isEqualToString:@""] || strDepth == nil || [strDepth length] == 0) {
            
            cell.lblDepValue.text=@"";
        }
        else
        {
            cell.lblDepValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Depth"]];
            
        }
        
        NSString *strMeasurL=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurL"]];
        
        if (strMeasurL == (id)[NSNull null] || [strMeasurL isEqualToString:@""] || strMeasurL == nil || [strMeasurL length] == 0) {
            
            MeasurL=@"";
        }
        else
        {
            MeasurL=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurL"]];
            
        }
        
        NSString *strMeasurW=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
        
        if (strMeasurW == (id)[NSNull null] || [strMeasurW isEqualToString:@""] || strMeasurW == nil || [strMeasurW length] == 0) {
            
            MeasurW=@"";
        }
        else
        {
            MeasurW=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurW"]];
        }
        
        NSString *strMeasurD=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurD"]];
        
        if (strMeasurD == (id)[NSNull null] || [strMeasurD isEqualToString:@""] || strMeasurD == nil || [strMeasurD length] == 0) {
            
            MeasurD=@"";
        }
        else
        {
            MeasurD=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MeasurD"]];
            
        }
        
        if ((MeasurL == (id)[NSNull null] || [MeasurL isEqualToString:@""] || MeasurL == nil || [MeasurL length] == 0) || (MeasurW == (id)[NSNull null] || [MeasurW isEqualToString:@""] || MeasurW == nil || [MeasurW length] == 0) || (MeasurD == (id)[NSNull null] || [MeasurD isEqualToString:@""] || MeasurD == nil || [MeasurD length] == 0) ) {
            
            
            cell.lblMesValue.text=@"";
        }
        else
        {
            cell.lblMesValue.text=[NSString stringWithFormat:@"%@*%@*%@",MeasurL,MeasurW,MeasurD];
            
            
        }
        
        NSString *strSellerLocation=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"SellerLocation"];
        
        if (strSellerLocation == (id)[NSNull null] || [strSellerLocation isEqualToString:@""] || strSellerLocation == nil || [strSellerLocation length] == 0) {
            
            cell.lblLocValue.text=@"";
        }
        else
        {
            cell.lblLocValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"SellerLocation"];
            
        }
        
        
        NSString *strTotal=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Total"]];
        
        if (strTotal == (id)[NSNull null] || [strTotal isEqualToString:@""] || strTotal == nil || [strTotal length] == 0) {
            
            cell.lblTtlValue.text=@"";
        }
        else
        {
            cell.lblTtlValue.text=[NSString stringWithFormat:@"$%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Total"] ];
            
        }
        
        NSString *strSeller=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller"];
        
        if (strSeller == (id)[NSNull null] || [strSeller isEqualToString:@""] || strSeller == nil || [strSeller length] == 0) {
            
            cell.lblSlrValue.text=@"";
        }
        else
        {
            cell.lblSlrValue.text=[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller"];
            
        }
        
        NSString *strSellerEmail=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller Email"]];
        
        if (strSellerEmail == (id)[NSNull null] || [strSellerEmail isEqualToString:@""] || strSellerEmail == nil || [strSellerEmail length] == 0) {
            
            _sellerEmail=@"";
        }
        else
        {
            _sellerEmail=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller Email"]];
            
            
        }
        
        NSString *strSellerNumber=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]];
        
        if (strSellerNumber == (id)[NSNull null] || [strSellerNumber isEqualToString:@""] || strSellerNumber == nil || [strSellerNumber length] == 0) {
            
            SellerNumber=@"";
        }
        else
        {
            SellerNumber=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]];
      
        
        }
        
        NSString *strStockNumber=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
        
        if (strStockNumber == (id)[NSNull null] || [strStockNumber isEqualToString:@""] || strStockNumber == nil || [strStockNumber length] == 0) {
            
            cell.lblStkValue.text=@"";
            _StockNumber=@"";
        }
        else
        {
            cell.lblStkValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
            _StockNumber=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"StockNumber"]];
        }
        
        NSString *MC=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"M/C"]];
        
        if (MC == (id)[NSNull null] || [MC isEqualToString:@""] || MC == nil || [MC length] == 0) {
            
            cell.lblMCValue.text=@"";
        }
        else
        {
            
            NSString *strMC = [NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"M/C"]];
            
            if ([strMC isEqualToString:@"M"]) {
                cell.lblMCValue.text=NSLocalizedString(@"MEMO", @"Memo");
            }
            else
            {
                cell.lblMCValue.text=NSLocalizedString(@"CASH", @"Cash");

            }
            
        }
        NSString *PDF=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"checkse"]];
        
        if (PDF == (id)[NSNull null] || [PDF isEqualToString:@""] || PDF == nil || [PDF length] == 0) {
            
           _strPDF=@"";
        }
        else
        {
            _strPDF=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"checkse"]];
            
        }
        
        NSString *listprice=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"listprice"]];
        
        if (listprice == (id)[NSNull null] || [listprice isEqualToString:@""] || listprice == nil || [listprice length] == 0)
        {
            
            cell.lblListValue.text=@"";
        }
        else
        {
            cell.lblListValue.text=[NSString stringWithFormat:@"$%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"listprice"]];
            
        }
        NSString *pricepercarat=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"pricepercarat"]];
        
        if (pricepercarat == (id)[NSNull null] || [pricepercarat isEqualToString:@""] || pricepercarat == nil || [pricepercarat length] == 0)
        {
            
            cell.lblPcValue.text=@"";
        }
        else
        {
            cell.lblPcValue.text=[NSString stringWithFormat:@"$%.0f",
                                 ceil([[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"pricepercarat"] floatValue])];
            
        }
  
        NSString *MemberComment=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MemberComment"]];
        
        if (MemberComment == (id)[NSNull null] || [MemberComment isEqualToString:@""] || MemberComment == nil || [MemberComment length] == 0)
        {
            
            cell.lblLocValue.text=@"";
        }
        else
        {
            cell.lblLocValue.text=[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"MemberComment"]];
            
        }
       
        UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelTapped:)];
        tapGestureRecognizer.numberOfTapsRequired = 1;
        cell.lblLabValue.accessibilityIdentifier=_strPDF;
        [cell.lblLabValue addGestureRecognizer:tapGestureRecognizer];
      
        
        cell.btnCall.accessibilityIdentifier=[NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"%@",[[_dynamicArray objectAtIndex:indexPath.row] valueForKey:@"Seller Number"]]];
        [cell.btnMessage addTarget:self action:@selector(newMailForMessage) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnCall addTarget:self action:@selector(callNumber:) forControlEvents:UIControlEventTouchUpInside];
        
        
        if ([_strPDF isEqualToString:@""]) {
            
            cell.lblLabValue.textColor=[UIColor blackColor];
        }
        else
        {
            cell.lblLabValue.textColor=[UIColor blueColor];
        }
        
           return cell;
        
    }else if (_tblViewSortOne == tableView){
        
        static NSString *cellIdentifier = @"SortCellOne";
        
        SortCellOne *cell = (SortCellOne *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[SortCellOne alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        cell.lblSortOneName.text=[_SortOneArray objectAtIndex:indexPath.row];
        
        
         cell.btnCancel.tag=indexPath.row;
        [cell.btnCancel addTarget:self action:@selector(sortOneCancel:) forControlEvents:UIControlEventTouchUpInside];
           return cell;
    }
    else{
        
        static NSString *cellIdentifier = @"SortCellTwo";
        
        SortCellTwo *cell = (SortCellTwo *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[SortCellTwo alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }

        cell.lblSortTwoName.text=[_SortTwoArray objectAtIndex:indexPath.row];
        cell.btnAdd.tag=indexPath.row;
        
        
        [cell.btnAdd addTarget:self action:@selector(sortOneAdd:) forControlEvents:UIControlEventTouchUpInside];
        
          return cell;
    }

    
    
    
    
    
    if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
        //        cell.lblSubjectHeight.constant=60;
        //        cell.lblSubjectIDHeight.constant=60;
    }
    
    if (selectedIndex ==  indexPath.row) {
        // do expandeble cell stuff
        
//         cell.contentView.backgroundColor=[UIColor blueColor];
    }
    else
    {
            
//        cell.contentView.backgroundColor=[UIColor whiteColor];
        
    }
    
    

}

-(void)labelTapped:(UITapGestureRecognizer *)text
{
   // [[KGModal sharedInstance]showWithContentView:_UIViewForPDF];
    
    UILabel *currentLabel = (UILabel *) text.view;
    NSString *labelText= currentLabel.accessibilityIdentifier;
    NSString *str=[NSString stringWithFormat:@"%@",labelText];

    //|GIA|GLT|IDL|AGS
    NSURL *url=[NSURL URLWithString:labelText];
    [[UIApplication sharedApplication]openURL:url];
    
  
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // user tap selected row
    NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    if ([selectedIndexArray containsObject:str]) {
        
        
        [selectedIndexArray removeObject:str];
        selectedIndex = -1;

        
        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
       
        
        return;
    }
        //user tap diff row
//    if (selectedIndex!=-1) {
//        
//        
//        NSIndexPath *prevPath=[NSIndexPath indexPathForRow:selectedIndex inSection:0];
//        selectedIndex = (int)indexPath.row;
//        
//        [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:prevPath] withRowAnimation:UITableViewRowAnimationFade];
//        
//        return;
//    }
    
    //if user taps new row with none expanded
    selectedIndex = (int)indexPath.row;
    [selectedIndexArray addObject:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];

    [tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    

    
}


-(void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if([indexPath row] == ((NSIndexPath*)[[tableView indexPathsForVisibleRows] lastObject]).row){
//      
////        NSLog(@"index path row=%ld",(long)[indexPath row]);
////         NSLog(@"Page Index=%d",Pageindex);
//        if ([indexPath row] == Pageindex*9) {
//        
//            Pageindex++;
//            [self searchDiamondResult];
//        }
//        else
//        {
//            NSLog(@"Page Index=%d",Pageindex);
//        }
//       
//    }
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (_tableView == tableView)
    {
        if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
        {
            //        cell.lblSubjectHeight.constant=60;
            //        cell.lblSubjectIDHeight.constant=60;
            NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
            if ([selectedIndexArray containsObject:str])
            {
                return 230;
            }
            else
            {
                return 47;
            }
            
        }
        else
        {
            NSString *str = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
            if ([selectedIndexArray containsObject:str])
            {
                return 360;
            }
            else
            {
                return 58;
            }
        }
    }
    else if (_tblViewSortOne == tableView)
    {
        return 25;
    }
    else{
        return 25;
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    
//    [_dynamicArray removeAllObjects];
//    [self searchDiamondResult1];
//    
//    if (UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPhone)
//    {
//        NSBundle *frameworkBundle = [NSBundle bundleForClass:[self class]];
//        UINib *nib = [UINib nibWithNibName:@"SearchDiamondCell" bundle:frameworkBundle];
//        [[self tableView] registerNib:nib forCellReuseIdentifier:@"SearchDiamondCell"];
//        
//    }
    
}

-(void)newMailForMessage
{
    
    
    NSLog(@"New Mail");
    NewMail *NewMailVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"NewMail"];
    NewMailVC.sellerEmailID=_sellerEmail;
    NewMailVC.strStockNumber=_StockNumber;
    NewMailVC.strShape=_Shape;
    NewMailVC.strCarat=_Carat;
    NewMailVC.strColor=_Color;
    NewMailVC.strClarity=_Clarity;
    
    NSLog(@"sellerEmail=%@",_sellerEmail);
    NSLog(@"StockNumber=%@",_StockNumber);
    NSLog(@"Shape=%@",_Shape);
    NSLog(@"Carat=%@",_Carat);
    NSLog(@"Color=%@",_Color);
    NSLog(@"Clarity=%@",_Clarity);
    

    [self.navigationController pushViewController:NewMailVC animated:YES];

    
}
-(void)callNumber:(UIButton *)btn
{

    NSString *phoneNumber = [@"tel://" stringByAppendingString:btn.accessibilityIdentifier];

    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:phoneNumber]];
}
-(void)sortOneAdd:(UIButton *)btn
{
   

    [_SortOneArray addObject:[_SortTwoArray objectAtIndex:btn.tag]];
    [_SortTwoArray removeObjectAtIndex:btn.tag];

    
    [arrayOFEnglish addObject:[arrayOFEnglish1 objectAtIndex:btn.tag]];
    [arrayOFEnglish1 removeObjectAtIndex:btn.tag];
    
    
    [_tblViewSortOne reloadData];
    [_tblViewSortTwo reloadData];
}

-(void)sortOneCancel:(UIButton *)btn
{
    

    [_SortTwoArray addObject:[_SortOneArray objectAtIndex:btn.tag]];
    [_SortOneArray removeObjectAtIndex:btn.tag];
    
    
    [arrayOFEnglish1 addObject:[arrayOFEnglish objectAtIndex:btn.tag]];
    [arrayOFEnglish removeObjectAtIndex:btn.tag];
    
    [_tblViewSortOne reloadData];
    [_tblViewSortTwo reloadData];

}

#pragma mark - IBActions

- (IBAction)btnMenuClicked:(UIButton*)sender {
  //  sender.selected=!sender.selected;
    
    [[KGModal sharedInstance]showWithContentView:_popUpViewSortBy andAnimated:YES];

}
- (IBAction)btnAccountSettingsClicked:(id)sender {
    
    AccountSetting *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"AccountSetting"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnCalculatorClicked:(id)sender {
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnLogoutClicked:(id)sender {
    LoginViewController *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnMyListingsClicked:(id)sender {
    
}

- (IBAction)btnFindDiamondsClicked:(id)sender {
}

- (IBAction)btnFindPeopleClicked:(id)sender {
    FindPeople *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindPeople"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnMessageClicked:(id)sender {
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnSideMenuClicked:(id)sender {
//    SWRevealViewController *revealController = [self revealViewController];
//    [revealController revealToggle:sender];
//    WhiteDiamondSearch *childvc=[[self storyboard]instantiateViewControllerWithIdentifier:@"WhiteDiamondSearch1"];
//    [self.navigationController pushViewController:childvc animated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnHomeClicked:(id)sender {
    //WelcomeViewController
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];
}

- (IBAction)btnSmileClicked:(id)sender {
}

- (IBAction)btnMyProfileClicked:(id)sender {
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];
}
#pragma mark Webservice Methods
-(void)searchDiamondResult1
{
    
    if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
    {
        
        Lid=@"1";
    }
    else
    {
        Lid=@"2";
    }

    
    if (_strLab==nil)
    {
        _strLab=@"";
    }
    

    lastCalledRequest=[NSDate date];
   // timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerTick:) userInfo:nil repeats:YES];
    
    
    webserviceClass=[[WebserviceClass alloc]init];

//    NSString *parameterString=[NSString stringWithFormat:@"Diamondshape=%@&Sizefrom=%@&Sizeto=%@&Colourfrom=%@&Colourto=%@&Clarityfrom=%@&Clarityto=%@&Polishfrom=%@&Polishto=%@&Caretfrom=%@&CaretTo=%@&Discountfrom=%@&Discountto=%@&Location=%@&Diamonds=%@&Suppliers=%@&Both=%@&AddLocation=%@&Symmertyfrom=%@&Symmertyto=%@&Labs=%@&Fluorescentfrom=%@&Fluorescentto=%@&Totalfrom=%@&Totalto=%@&sellername=%@&PageIndex=%d&PageSize=%@&CutFrom=%@&CutTo=%@",_strShape,@"",@"",_strColourfrom,_strColourto,_strClarityfrom,_strClarityto,_strPolishfrom,_strPolishto,_strSizefrom,_strSizeto,_strDiscountfrom,_strDiscountto,@"",@"",@"",@"",@"",_strSymmertyfrom,_strSymmertyto,_strLab,_strFluorescentfrom,_strFluorescentto,_strTotalfrom,_strTotalto,@"",Pageindex,@"10",_strCutFrom,_strCutTo];
    
    
    if ([_strSizefrom isEqualToString:@""])
    {
        _strSizefrom=@"0.0";
    }
    
    
    if ([_strSizeto isEqualToString:@""])
    {
        _strSizeto=@"99.99";
    }
    
    if (_strFinishTypeFeature==nil) {
        
        _strFinishTypeFeature=@"";
        
    }
    if (_strSearchKeyword==nil) {
        
        _strSearchKeyword=@"";
        
    }
    
    NSString *trimmedString = [_strFinishTypeFeature stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];

    
     NSString *parameterString=[NSString stringWithFormat:@"Diamondshape=%@&Sizefrom=%@&Sizeto=%@&Colours=%@&Clarities=%@& Polishs=%@&Caretfrom=%@&CaretTo=%@&Discountfrom=%@&Discountto=%@&Location=%@&Diamonds=%@&Suppliers=%@&Both=%@&AddLocation=%@&Symmerties=%@&Labs=%@&Fluorescents=%@&Totalfrom=%@&Totalto=%@&sellername=%@&PageIndex=%d&PageSize=%@&Cuts=%@&FinishType=%@&SearchKeyword=%@&Lid=%@",_strShape,@"",@"",_strColour,_strClarity,_strPolish,_strSizefrom,_strSizeto,_strDiscountfrom,_strDiscountto,@"",@"",@"",@"",@"",_strSymmerty,_strLab,_strFluorescent,_strTotalfrom,_strTotalto,@"",Pageindex,@"10",_strCut,trimmedString,_strSearchKeyword,Lid];
    
    
   
    [webserviceClass callServcieUsingRequestAndPOST:SEARCH_DIAMOND_RESULT :parameterString andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    
 //   [self callASynceMethodCall:SEARCH_DIAMOND_RESULT ANdParameters:parameterString];
    NSLog(@"ParameterString =%@",parameterString);
    

}
-(void)Sorting
{
    
    if ([language isEqualToString:@"en-US"] ||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
    {
        
        Lid=@"1";
    }
    else
    {
        Lid=@"2";
    }

    
    sortingComaSeparated =[arrayOFEnglish componentsJoinedByString:@","];

    webserviceClass=[[WebserviceClass alloc]init];
    
//    NSString *parameterString1=[NSString stringWithFormat:@"Diamondshape=%@&Sizefrom=%@&Sizeto=%@&Colourfrom=%@&Colourto=%@&Clarityfrom=%@&Clarityto=%@&Polishfrom=%@&Polishto=%@&Caretfrom=%@&CaretTo=%@&Discountfrom=%@&Discountto=%@&Location=%@&Diamonds=%@&Suppliers=%@&Both=%@&AddLocation=%@&Symmertyfrom=%@&Symmertyto=%@&Labs=%@&Fluorescentfrom=%@&Fluorescentto=%@&Totalfrom=%@&Totalto=%@&sellername=%@&PageIndex=%d&PageSize=%@&CommaseperatedSortingFields=%@&Order=%@&CutFrom=%@&CutTo=%@",_strShape,@"",@"",_strColourfrom,_strColourto,_strClarityfrom,_strClarityto,_strPolishfrom,_strPolishto,_strSizefrom,_strSizeto,_strDiscountfrom,_strDiscountto,@"",@"",@"",@"",@"",_strSymmertyfrom,_strSymmertyto,_strLab,_strFluorescentfrom,_strFluorescentto,_strTotalfrom,_strTotalto,@"",Pageindex1,@"10",sortingComaSeparated,strOrder,_strCutFrom,_strCutTo];
    
    NSString *trimmedString = [_strFinishTypeFeature stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    
    
    NSString *parameterString1=[NSString stringWithFormat:@"Diamondshape=%@&Sizefrom=%@&Sizeto=%@&Colours=%@&Clarities=%@& Polishs=%@&Caretfrom=%@&CaretTo=%@&Discountfrom=%@&Discountto=%@&Location=%@&Diamonds=%@&Suppliers=%@&Both=%@&AddLocation=%@&Symmerties=%@&Labs=%@&Fluorescents=%@&Totalfrom=%@&Totalto=%@&sellername=%@&PageIndex=%d&PageSize=%@&CommaseperatedSortingFields=%@&Order=%@&Cuts=%@&FinishType=%@&SearchKeyword=%@&Lid=%@",_strShape,@"",@"",_strColour,_strClarity,_strPolish,_strSizefrom,_strSizeto,_strDiscountfrom,_strDiscountto,@"",@"",@"",@"",@"",_strSymmerty,_strLab,_strFluorescent,_strTotalfrom,_strTotalto,@"",Pageindex1,@"10",sortingComaSeparated,strOrder,_strCut,trimmedString,_strSearchKeyword,Lid];
    
    [webserviceClass callServcieUsingRequestAndPOST:SEARCH_DIAMOND_RESULT_SORTING:parameterString1 andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"Sorting =%@",parameterString1);
    

}
- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods

-(void)sendResponse:(NSMutableData *)dataResponseArray
{

    responseDidReceive=[NSDate date];
    if (flagg1 == 1) {
        
        NSError* error;
        json = [NSJSONSerialization
                JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
        
        NSString *strMessage=[json objectForKey:@"Message"];
        
        
        
        if (![strMessage isEqualToString:@"Success"]) {
            
            _UIViewHeader.hidden=NO;
            [self showMessage];
        }
        else
        {
        
                NSDictionary *subDict= [json objectForKey:@"Result"];
                _jsonArray = [subDict objectForKey:@"Diamond"];
            
            
                 if (_jsonArray.count==0)
                  {
                    _btnLoadMore.hidden=YES;
                  }else
                  {
                    _btnLoadMore.hidden=NO;
                  }
            
                
                for (int i=0; i < _jsonArray.count; i++)
                {
                    
                    [_dynamicSortArray addObject:[_jsonArray objectAtIndex:i]];
                    
                    
                   // [_tableView reloadData];
                    
                    _UIViewHeader.hidden=NO;
                    
                    
                }
    //    [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            }
      [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
      //  self performSelectorOnMainThread:@selector(updateTable) withObject:nil waitUntilDone:NO];
    }
    else{
    
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    NSString *strMessage=[json objectForKey:@"Message"];

    if (![strMessage isEqualToString:@"Success"]) {
        
        _UIViewHeader.hidden=NO;
        [self showMessage];
    }
    else
    {
        
         NSDictionary *subDict= [json objectForKey:@"Result"];
            _jsonArray = [subDict objectForKey:@"Diamond"];
            
            if (_jsonArray.count==0)
            {
                _btnLoadMore.hidden=YES;
            }else
            {
                _btnLoadMore.hidden=NO;
            }
        
            for (int i=0; i < _jsonArray.count; i++)
            {
                [_dynamicArray addObject:[_jsonArray objectAtIndex:i]];
                _UIViewHeader.hidden=NO;
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [_tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
        });
        

    }
}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
- (void)showMessage
{
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Message"
                                                message:NSLocalizedString(@"RECORD_NOT",@"Record not Found!!!")
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}


- (IBAction)btnLoadMoreClicked:(id)sender {
    

    if (flagg1 == 1) {
        
         Pageindex1++;
        
         [self Sorting];
    }
    else
    {
         Pageindex++;
       [self searchDiamondResult1];
     
        
    }
    

}
- (IBAction)btnAscendingClicked:(UIButton *)sender {
    
    sender.selected=!sender.selected;
    
    if (sender.selected) {
        
       sender.tintColor=[UIColor clearColor];
    
        if ([sender.titleLabel.text isEqualToString:
             _btnAscending.titleLabel.text]) {
        [_btnAscending setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateSelected];
        [_btnAscending setTitle:NSLocalizedString(@"DESCENDING",@"Descending")forState:UIControlStateNormal];
            strOrder=@"Desc";
        }
    }
    else{
        
        sender.tintColor=[UIColor clearColor];
        if ([sender.titleLabel.text isEqualToString:
             _btnAscending.titleLabel.text]) {
            
            [_btnAscending setTitle:NSLocalizedString(@"ASCENDING",@"Ascending" )forState:UIControlStateNormal];
             strOrder=@"Asc";
        }
    }
    
    
}

- (IBAction)btnSortSaveClicked:(id)sender {
    

    [_dynamicSortArray removeAllObjects];
    
    flagg1=1;
    Pageindex1=1;

    [self Sorting];
[self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    [[KGModal sharedInstance] hide];
    
}

- (IBAction)btnSortCancelClicked:(id)sender {
    
    [[KGModal sharedInstance] hide];
}
- (IBAction)btnSortClicked:(id)sender {
    
  
    [[KGModal sharedInstance] showWithContentView:_UIViewSortBy];
    [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];
}
- (IBAction)btnFooterHomeClicked:(id)sender {
    
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];

}

- (IBAction)btnFooterMessageClicked:(id)sender {
    
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnFooterCalculatorClicked:(id)sender {
    
    Calculator *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Calculator"];
    [self.navigationController pushViewController:objVC animated:YES];
}

- (IBAction)btnFooterMemberProfileClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];

}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark- This method is basically is designed for update the counter label
- (void)timerTick:(NSTimer *)timer
{
    NSDate *now = [NSDate date];
    static NSDateFormatter *dateFormatter;
    if (!dateFormatter)
    {
        dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"h:mm:ss a";  // very simple format  "8:47:22 AM"
    }
    
   // NSDate *date1 = _selectedStartTimeForOngoingHeadache;
    //NSDate *date2 = now;
    
    NSTimeInterval secondsBetween = [responseDidReceive timeIntervalSinceDate:lastCalledRequest];
    
   // self.lblRecorderTimer.text = [self stringFromTimeInterval:secondsBetween];
}


-(void)callASynceMethodCall:(NSString *)url1 ANdParameters:(NSString *)parameters
{
    
    
    NSURL *url = [NSURL URLWithString:url1];
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
     [urlRequest setHTTPMethod:@"POST"];
    [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
    [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
    {
        
        
        if (error)
        {
            NSLog(@"Error,%@", [error localizedDescription]);
        }
        else
        {
    
            
            NSError* error;
            json = [NSJSONSerialization
                    JSONObjectWithData:data options:kNilOptions error:&error];
    
        }
    }];
    
}

-(void)callServiceForBanerAd
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
        
        //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:@"http://webservice.cevaheer.com/api/Banner?PageName=Search%20Result"];
        
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
        
        [urlRequest setHTTPMethod:@"GET"];
        [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
        [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
        //[urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
        
        //Create task
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
            NSError* error1;
            NSDictionary *json1 = [NSJSONSerialization
                                   JSONObjectWithData:data options:kNilOptions error:&error1];
            
            NSNumber *strStatus=[json1 valueForKey:@"Statuscode"];
            
            if (strStatus.integerValue==0 )
            {
                
                _BanerAdImageView.hidden=YES;
                _footerViewContraintHeight.constant=0.01f;
                
            }
            else
            {
                _BanerAdImageView.hidden=NO;

                
            NSDictionary *resultDict=[json1  valueForKey:@"Result"];
            
            NSArray *tableArray=[resultDict valueForKey:@"Table"];
            
            for (NSDictionary *result in tableArray) {
                
                urlString=[result valueForKey:@"Bannerimage"];
                
                //   _BanerAdImageView = [UIImage animatedImageWithAnimatedGIFURL:[NSURL URLWithString:urlString]];
               
                
                dispatch_queue_t imageQueue = dispatch_queue_create("Image Queue",NULL);
                dispatch_async(imageQueue, ^{
                    
                    NSURL *url = [NSURL URLWithString:urlString];
                    //                    NSData *imageData = [NSData dataWithContentsOfURL:url];
                    //                    UIImage *image = [UIImage imageWithData:imageData];
                    
                    UIImage *loadingImage = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:url]];
                    
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // Update the UI
                        //   [_BanerAdImageView setImage:image];
                        
                        _BanerAdImageView.animationImages = loadingImage.images;
                        _BanerAdImageView.animationDuration = loadingImage.duration;
                        
                        // [NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector:@selector(runMethod) userInfo:nil repeats:YES];
                        
                        
                        _BanerAdImageView.animationRepeatCount = 0;
                        
                        
                        _BanerAdImageView.image = loadingImage.images.lastObject;
                        [_BanerAdImageView startAnimating];
                    });
                    
                });
                
                }
              }
   
            // [Constant setDateFromService:truncated];
        }];
        [dataTask resume];
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
}


@end
