//
//  SearchDiamondResult.h
//  Cevaheer App
//
//  Created by  on 10/3/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchDiamondCell.h"
#import "AccountSetting.h"
#import "FindPeople.h"
#import "Messages.h"
#import "LoginViewController.h"
#import "WelcomeViewController.h"
#import "MemberProfile.h"
#import "Calculator.h"
#import "WhiteSearchClass.h"
#import "SortCellOne.h"
#import "SortCellTwo.h"

@class WebserviceClass;

@interface SearchDiamondResult : UIViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    BOOL isFiltered;
    NSMutableArray *filteredArray;
    NSMutableArray *selectedIndexArray;
    NSString *parameterString;
    NSString *sortingComaSeparated;
    NSString *strOrder;
    
    int Pageindex,Pageindex1;
    int selectedIndex;
    int flagg;
    int flagg1;
    NSString *sellerEmail;
    NSString *StockNumber;
    NSString *Shape;
    NSString *Carat;
    NSString *Color;
    NSString *Clarity;
    NSString *MeasurL;
    NSString *MeasurW;
    NSString *MeasurD;
    NSString *SellerNumber;
     NSString *language;
     NSString *Lid;
    
    NSTimer *timer;
    NSDate *lastCalledRequest,*responseDidReceive;
    
    NSMutableArray *arrayOFEnglish,*arrayOFEnglish1;
    
}
@property(nonatomic,strong) NSString *sellerEmail;
@property(nonatomic,strong) NSString *StockNumber;
@property(nonatomic,strong) NSString *Shape;
@property(nonatomic,strong) NSString *Carat;
@property(nonatomic,strong) NSString *Color;
@property(nonatomic,strong) NSString *Clarity;


@property(strong,nonatomic) NSString *TotalCount;
@property (strong, nonatomic) IBOutlet UIImageView *BanerAdImageView;
@property (strong, nonatomic) IBOutlet UIView *footerView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *footerViewContraintHeight;

@property(nonatomic,strong) NSMutableArray *dynamicArray;
@property(nonatomic,strong) NSMutableArray *dynamicSortArray;

@property(nonatomic,strong) NSMutableArray *jsonArray;
@property (weak) IBOutlet UIView *UIViewHeader;
@property (weak) IBOutlet UIView *UIViewFirst;

@property (weak) IBOutlet UIView *UIViewForPDF;
@property (weak) IBOutlet UIWebView *UIWebViewForPDF;

@property(nonatomic,strong) NSString *strPDF;
@property(nonatomic,strong) NSString *strLabValue;


#pragma mark - Sort By

@property (weak) IBOutlet UIView *UIViewSortBy;
@property (weak) IBOutlet UITableView *tblViewSortOne;
@property (weak) IBOutlet UITableView *tblViewSortTwo;
@property (weak) IBOutlet UIButton *btnSortCancel;
@property (weak) IBOutlet UIButton *btnSortSave;
@property(nonatomic,strong) NSMutableArray *SortOneArray;
@property(nonatomic,strong) NSMutableArray *SortTwoArray;
@property (weak) IBOutlet UIButton *btnAscending;
@property(nonatomic,strong) NSMutableArray *comaSeparatArray;

- (IBAction)btnAscendingClicked:(id)sender;

- (IBAction)btnSortSaveClicked:(id)sender;

- (IBAction)btnSortCancelClicked:(id)sender;

@property (weak) IBOutlet UIButton *btnSort;
- (IBAction)btnSortClicked:(id)sender;

#pragma mark - Outlets

@property (weak) IBOutlet UIView *transView;
@property (weak) IBOutlet UIView *menuView;
@property (weak) IBOutlet UITableView *tableView;
@property (weak) IBOutlet UIView *popUpViewSortBy;

#pragma mark - IBOutlets 

@property (weak, nonatomic) IBOutlet UIButton *btnLoadMore;
- (IBAction)btnLoadMoreClicked:(id)sender;

#pragma mark - Actions

- (IBAction)btnMenuClicked:(id)sender;
- (IBAction)btnAccountSettingsClicked:(id)sender;
- (IBAction)btnCalculatorClicked:(id)sender;
- (IBAction)btnLogoutClicked:(id)sender;
- (IBAction)btnMyListingsClicked:(id)sender;
- (IBAction)btnFindDiamondsClicked:(id)sender;
- (IBAction)btnFindPeopleClicked:(id)sender;
- (IBAction)btnMessageClicked:(id)sender;
- (IBAction)btnSideMenuClicked:(id)sender;
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnSmileClicked:(id)sender;
- (IBAction)btnMyProfileClicked:(id)sender;

#pragma mark - Footer Menu

- (IBAction)btnFooterHomeClicked:(id)sender;
- (IBAction)btnFooterMessageClicked:(id)sender;
- (IBAction)btnFooterCalculatorClicked:(id)sender;
- (IBAction)btnFooterMemberProfileClicked:(id)sender;


#pragma mark - Web Parameter
@property(nonatomic,strong) NSString *strShape;
@property(nonatomic,strong) NSString *strSizefrom;
@property(nonatomic,strong) NSString *strSizeto;
@property(nonatomic,strong) NSString *strColour;


@property(nonatomic,strong) NSString *strClarity;
@property(nonatomic,strong) NSString *strPolish;
@property(nonatomic,strong) NSString *strSymmerty;
@property(nonatomic,strong) NSString *strCaretfrom;
@property(nonatomic,strong) NSString *strCaretTo;
@property(nonatomic,strong) NSString *strFinishTypeFeature;
@property(nonatomic,strong) NSString *strSearchKeyword;



@property(nonatomic,strong) NSString *strDiscountfrom;
@property(nonatomic,strong) NSString *strDiscountto;

@property(nonatomic,strong) NSString *strCut;
@property(nonatomic,strong) NSString *strFluorescent;



@property(nonatomic) BOOL flagColor;
@property(nonatomic) BOOL flagClarity;
@property(nonatomic) BOOL flagCut;
@property(nonatomic) BOOL flagPolish;
@property(nonatomic) BOOL flagSymmetry;
@property(nonatomic) BOOL flagFluorescent;



@property(nonatomic,strong) NSString *strSerchkeyParameter;






@property(nonatomic,strong) NSString *strTotalfrom;
@property(nonatomic,strong) NSString *strTotalto;
@property(nonatomic,strong) NSString *strSellerName;
@property(nonatomic,strong) NSString *strLocation;
@property(nonatomic,strong) NSString *strLab;


@end
