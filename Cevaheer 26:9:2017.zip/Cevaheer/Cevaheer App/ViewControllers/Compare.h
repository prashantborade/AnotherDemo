//
//  Compare.h
//  Cevaheer App
//
//  Created by SMS on 24/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "WebserviceClass.h"

@interface Compare : UIViewController
{
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *strEmail;
    int flag;
}

@property(nonatomic,strong) NSString *result;
@property(nonatomic,strong) NSString *mainResult;
@property(nonatomic,strong) NSMutableArray *jsonArray;

#pragma mark - Database
@property(nonatomic,strong) NSString *strcaratValue;
@property(nonatomic,strong) NSString *strYourPrice;
@property(nonatomic,strong) NSString *strYourPriceTotal;
@property(nonatomic,strong) NSString *Shape;
@property(nonatomic,strong) NSString *Color;
@property(nonatomic,strong) NSString *Clarity;
@property(nonatomic,strong) NSString *Discount;

#pragma mark -PickerView Outelets
@property (strong, nonatomic) IBOutlet UIPickerView *shapePickerView;
@property (strong, nonatomic) IBOutlet UIPickerView *colorPickerView;
@property (strong, nonatomic) IBOutlet UIPickerView *clarityPickerView;
@property (strong, nonatomic) IBOutlet UIPickerView *discountPickerView;




@property(nonatomic,strong) NSString *databasePath;
@property(nonatomic) sqlite3 *DB;

@property(nonatomic,strong) NSString *strShape;
@property(nonatomic,strong) NSString *strColor;
@property(nonatomic,strong) NSString *strClarity;
@property(nonatomic,strong) NSString *strdiscount;

#pragma mark - For PickerView
@property(nonatomic,strong) NSMutableArray *shapePickerArray;
@property(nonatomic,strong) NSMutableArray *colorPickerArray;
@property(nonatomic,strong) NSMutableArray *clarityPickerArray;
@property(nonatomic,strong) NSMutableArray *DiscountPickerArray;

#pragma mark - Outlets
@property (strong, nonatomic) IBOutlet UILabel *lblDiamond1Value;
@property (strong, nonatomic) IBOutlet UILabel *lblDiamond2Value;
@property (strong, nonatomic) IBOutlet UILabel *lblResultDiamond1;
@property (strong, nonatomic) IBOutlet UILabel *lblResultDiamond2;
@property (strong, nonatomic) IBOutlet UILabel *lblDifference;
@property (strong, nonatomic) IBOutlet UILabel *lblResultDiamond1Total;
@property (strong, nonatomic) IBOutlet UILabel *lblResultDiamond2Total;
@property (strong, nonatomic) IBOutlet UILabel *lblResultDifferenceTotal;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewShape;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewColor;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewClarity;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewDiscount;
@property (strong, nonatomic) IBOutlet UIButton *btnBack;
- (IBAction)btnBackClicked:(id)sender;


@end
