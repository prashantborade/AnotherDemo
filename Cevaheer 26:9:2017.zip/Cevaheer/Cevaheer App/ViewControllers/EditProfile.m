

//
//  EditProfile.m
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "EditProfile.h"

@interface EditProfile ()

@end
#pragma mark - Lifecycle
@implementation EditProfile

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeView];
    
    flag=0;
    _jsonArray = [[NSMutableArray alloc] init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strEmail= [defaults valueForKey:@"EmailAddress"];
    [defaults synchronize];
    
    webserviceClass=[[WebserviceClass alloc] init];
    [self accountSetting];
    
    _txtOldPassword.hidden=YES;
    _txtNewPassword.hidden=YES;
    
    // Do any additional setup after loading the view.
}
-(void)initializeView
{
    
    [_btnSave setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    
    _txtFirstName.layer.borderWidth=1.0F;
    _txtLastName.layer.borderWidth=1.0F;
    _txtCompanyName.layer.borderWidth=1.0F;
    _txtPhone.layer.borderWidth=1.0F;
    _txtOldPassword.layer.borderWidth=1.0F;
    _txtNewPassword.layer.borderWidth=1.0F;
    
    _btnSave.layer.borderWidth=1.5F;
    
    
    _txtFirstName.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtLastName.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtCompanyName.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtPhone.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
  _txtOldPassword.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _txtNewPassword.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
    _btnSave.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
}


#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark - IBActions
- (IBAction)btnBackClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnSaveClicked:(id)sender {
    webserviceClass =[[WebserviceClass alloc] init];
    NSLog(@"Save Clicked");
    flag=1;
    [self editAccount];
}

- (IBAction)btnChangePwdClicked:(id)sender {
    _txtOldPassword.hidden=NO;
    _txtNewPassword.hidden=NO;
    
    
}

#pragma mark Webservice Methods
-(void)editAccount
{

    NSString *strRequest=ACCOUNT_SETTING_EDIT;
    NSString *parameterString=[NSString stringWithFormat:@"FirstName=%@&LastName=%@&Companyname=%@&Phone=%@&password=%@&email=%@",_txtFirstName.text,_txtLastName.text,_txtCompanyName.text,_txtPhone.text,_txtOldPassword.text,strEmail];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                                 NSUTF8StringEncoding];
    strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
        NSLog(@"URL=%@",parameterString);
    
}

-(void)accountSetting
{
    NSString *strRequest=ACCOUNT_SETTING;
    NSString *parameterString=[NSString stringWithFormat:@"EmailId=%@",strEmail];
    
    strRequest=[strRequest stringByAppendingString:parameterString];
        
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"URL=%@",parameterString);
        
}

- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods/Users//Desktop/P/Cevaheer Git/Cevaheer App/ViewControllers/EditProfile.m:128:18: Unused variable 'objJSONUtility'
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    if (flag == 1) {
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
            }
            else
            {
                [self showMessage];
                [self.navigationController popViewControllerAnimated:YES];
                
            }
            
        }
        
    }
    else{
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                    [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArray = [subDict objectForKey:@"Table"];
                    
                    for (NSDictionary *result in _jsonArray) {
                        
                        NSString *FirstName=[result objectForKey:@"FirstName"];
                       
                        
                        if ((FirstName ==(id)[NSNull null] || [FirstName isEqualToString:@""] || FirstName==nil || [FirstName length]==0 || [FirstName  isEqualToString:@"<null>"]))
                        {
                            _txtFirstName.text=@"";
                            
                            
                        }
                        else
                        {
                            _txtFirstName.text=[result objectForKey:@"FirstName"];
                        
                        }
                        
                         NSString *LastName=[result objectForKey:@"LastName"];
                        
                        if ((LastName ==(id)[NSNull null] || [LastName isEqualToString:@""] || LastName==nil || [LastName length]==0 || [LastName  isEqualToString:@"<null>"])) {
                            
                            _txtLastName.text=@"";
                        }
                        else
                        {
                            _txtLastName.text=[result objectForKey:@"LastName"];
                        }
                        
                        NSString *CompanyName=[NSString stringWithFormat:@"%@",[result objectForKey:@"CompanyName"]];
                        
                        if (CompanyName == (id)[NSNull null] ||[CompanyName isEqualToString:@""] || CompanyName == nil || [CompanyName length] ==0 || [CompanyName  isEqualToString:@"<null>"])
                        {
                            _txtCompanyName.text=@"";
                        }
                        else
                        {
                            _txtCompanyName.text=[result objectForKey:@"CompanyName"];
                        }
                        
                        NSString *MobileNumber=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        
                        if (MobileNumber == (id)[NSNull null] ||[MobileNumber isEqualToString:@""] || MobileNumber == nil || [MobileNumber length] ==0 || [MobileNumber  isEqualToString:@"<null>"])
                        {
                           _txtPhone.text=@"";
                        }
                        else
                        {
                            _txtPhone.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        }
                        
                        NSString *Password=[NSString stringWithFormat:@"%@",[result objectForKey:@"Password"]];
                        
                        if (Password == (id)[NSNull null] ||[Password isEqualToString:@""] || Password == nil || [Password length] ==0 || [Password  isEqualToString:@"<null>"])
                        {
                          _txtOldPassword.text=@"";
                        }
                        else
                        {
                         _txtOldPassword.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"Password"]];
                            
                        }
                        
                        
                    }
                    
                }
                
                
            }
            
        }
    }
    
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:2.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}
#pragma mark - UITextFieldDelegate



@end
