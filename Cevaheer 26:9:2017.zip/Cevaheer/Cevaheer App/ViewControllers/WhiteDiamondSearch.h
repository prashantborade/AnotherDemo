//
//  WhiteDiamondSearch.h
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchDiamondResult.h"
#import "MoreCell.h"
#import "MoreCell2.h"
#import "MoreCells3.h"
#import "WhiteSearchClass.h"
#import "FindDiamond.h"
#import <Google/Analytics.h>
#import "GAITrackedViewController.h"
#import "SCNumberKeyBoard.h"


@class FindDiamond;

@interface WhiteDiamondSearch : GAITrackedViewController<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>
{
    int btnCountColor,btnCountClarity,btnCountCut;
    int btnCountPolish;
    int btnCountSymmetry;
    int btnCountLab;
    int btnCountFluorescent,flag,flag2;
    int count;
    int countFinish;
    
    int flag3,flag4,flag5,flag6;
    
    NSMutableArray *colorTempArray;
    NSMutableArray *labTempArray;
    NSMutableArray *labtextTempArray;
    NSString *language,*Lid;
    
    FindDiamond *findDiamond;
    
}

//Calculator Search
@property(nonatomic,strong) NSString *strcaratValue;
@property(nonatomic,strong) NSString *strYourPrice;
@property(nonatomic,strong) NSString *strYourPriceTotal;
@property(nonatomic,strong) NSString *Shape;
@property(nonatomic,strong) NSString *Color;
@property(nonatomic,strong) NSString *Clarity;
@property(nonatomic,strong) NSString *Discount;

#pragma FinishFeature Oulets and Actions
@property (strong, nonatomic) IBOutlet UIButton *btn3XOutle;
@property (strong, nonatomic) IBOutlet UIButton *btnEXOutlet;
@property (strong, nonatomic) IBOutlet UIButton *btnVGPlusOutlet;

@property (strong, nonatomic) IBOutlet UIButton *btnVGMinusOutlet;
/* ---------------------------------------*/
- (IBAction)btn3XClicked:(id)sender;
- (IBAction)btnEXClicked:(id)sender;
- (IBAction)btnVGPlusClicked:(id)sender;
- (IBAction)btnVGMinusClicked:(id)sender;


@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scroll;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *inerViewHeight;
@property(nonatomic,strong) NSMutableArray *checkColor;
@property(nonatomic,strong) NSMutableArray *checkLab;

@property (strong, nonatomic) IBOutlet UIView *UIViewForTesting;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *UIviewTestingConstraintHeight;

@property(nonatomic,strong) NSMutableArray *moreShapeImgArray;
@property(nonatomic,strong) NSMutableArray *moreShapeImgNameArray;

@property(nonatomic,strong) NSMutableArray *moreLabArray;
@property(nonatomic,strong) NSMutableArray *moreColorArray;

@property (strong, nonatomic) IBOutlet UIView *UIViewMoreShape;
@property (weak, nonatomic) IBOutlet UITableView *tblMoreShape;
@property (weak, nonatomic) IBOutlet UIButton *btnOKShape;
- (IBAction)btnOKShapeClicked:(id)sender;

//moreColor
@property (strong, nonatomic) IBOutlet UIView *UIviewMoreColor;
@property (weak, nonatomic) IBOutlet UITableView *tblMoreColor;

@property (weak, nonatomic) IBOutlet UIButton *btnOKColor;
- (IBAction)btnOKColorClicked:(id)sender;
//moreLab
@property (strong, nonatomic) IBOutlet UIView *UIViewMoreLab;
@property (weak, nonatomic) IBOutlet UITableView *tblMoreLab;

@property (weak, nonatomic) IBOutlet UIButton *btnOKLab;
- (IBAction)btnMoreLabClicked:(id)sender;



#pragma mark - Bottom Button
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSearchClicked:(id)sender;


#pragma mark - UIView Hide and Show


@property (strong, nonatomic) IBOutlet UIButton *btnAdvancedSearch;
- (IBAction)btnAdvancedSearchCicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *TopView;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *ScrollView;
@property (strong, nonatomic) IBOutlet UIView *ViewInsideScroll;


@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnAdvancedSearchConstraint;


#pragma mark - General Properties

@property(nonatomic,strong) NSMutableArray *colorArray;
@property(nonatomic,strong) NSMutableArray *clarityArray;
@property(nonatomic,strong) NSMutableArray *cutArray;
@property(nonatomic,strong) NSMutableArray *polishArray;
@property(nonatomic,strong) NSMutableArray *symmetryArray;
@property(nonatomic,strong) NSMutableArray *caretArray;
@property(nonatomic,strong) NSMutableArray *discountArray;
@property(nonatomic,strong) NSMutableArray *labArray;
@property(nonatomic,strong) NSMutableArray *fluorescentArray;
@property(nonatomic,strong) NSString *strFinish;
//@property(nonatomic,strong) NSRegularExpression *strFinish;






@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnLocationHeight;

#pragma mark - Outleets For Shape

@property (strong, nonatomic) IBOutlet UIButton *btnRound;
@property (strong, nonatomic) IBOutlet UIButton *btnEmerald;
@property (strong, nonatomic) IBOutlet UIButton *btnPear;
@property (strong, nonatomic) IBOutlet UIButton *btnPrincess;
@property (strong, nonatomic) IBOutlet UIButton *btnOval;
@property (strong, nonatomic) IBOutlet UIButton *btnCushion;

@property (strong, nonatomic) IBOutlet UIButton *btnCusMod;

@property (strong, nonatomic) IBOutlet UIButton *btnHeart;
@property (strong, nonatomic) IBOutlet UIButton *btnMarquise;
@property (strong, nonatomic) IBOutlet UIButton *btnRadiant;


#pragma mark -IBAction For Shape
- (IBAction)btnRoundClicked:(id)sender;
- (IBAction)btnEmeraldClicked:(id)sender;
- (IBAction)btnPearClicked:(id)sender;
- (IBAction)btnPrincessClicked:(id)sender;
- (IBAction)btnOvalClicked:(id)sender;
- (IBAction)btnCushionClicked:(id)sender;
- (IBAction)btnCusModClicked:(id)sender;
- (IBAction)btnHeartClicked:(id)sender;
- (IBAction)btnMarquiseClicked:(id)sender;
- (IBAction)btnRadiantClicked:(id)sender;


#pragma mark - Action For More
- (IBAction)btnShapeMoreClicked:(id)sender;
- (IBAction)btnLabMoreClicked:(id)sender;
- (IBAction)btnColorMoreClicked:(id)sender;


@property(nonatomic) BOOL flagColor;
@property(nonatomic) BOOL flagClarity;
@property(nonatomic) BOOL flagCut;
@property(nonatomic) BOOL flagPolish;
@property(nonatomic) BOOL flagSymmetry;
@property(nonatomic) BOOL flagFluorescent;





#pragma mark - Outlets For Carat

@property (strong, nonatomic) IBOutlet UITextField *txtCaratFrom;

@property (strong, nonatomic) IBOutlet UITextField *txtCaratTo;
- (IBAction)txtCaratFromClicked:(id)sender;
- (IBAction)txtCaratToClicked:(id)sender;





#pragma mark - Outlets For Color
@property (strong, nonatomic) IBOutlet UIButton *btnDColor;
@property (strong, nonatomic) IBOutlet UIButton *btnEColor;
@property (strong, nonatomic) IBOutlet UIButton *btnFColor;
@property (strong, nonatomic) IBOutlet UIButton *btnGColor;
@property (strong, nonatomic) IBOutlet UIButton *btnHColor;
@property (strong, nonatomic) IBOutlet UIButton *btnIColor;
@property (strong, nonatomic) IBOutlet UIButton *btnJColor;
@property (strong, nonatomic) IBOutlet UIButton *btnKColor;
@property (strong, nonatomic) IBOutlet UIButton *btnLColor;
@property (strong, nonatomic) IBOutlet UIButton *btnMColor;


#pragma mark - Outlets For Clarity

@property (strong, nonatomic) IBOutlet UIButton *btnFLCLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnILCLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnVVS1CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnVVS2CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnVS1CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnVS2CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnSI1CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnSI2CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnSI3CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnI1CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnI2CLarity;
@property (strong, nonatomic) IBOutlet UIButton *btnI3CLarity;

#pragma mark - Outlets For Cut

@property (strong, nonatomic) IBOutlet UIButton *btnICut;
@property (strong, nonatomic) IBOutlet UIButton *btnEXCut;
@property (strong, nonatomic) IBOutlet UIButton *btnVGCut;
@property (strong, nonatomic) IBOutlet UIButton *btnGCut;
@property (strong, nonatomic) IBOutlet UIButton *btnFCut;
@property (strong, nonatomic) IBOutlet UIButton *btnPCut;


#pragma mark - Outlets For Polish

@property (strong, nonatomic) IBOutlet UIButton *btnIPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnEXPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnVGPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnGPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnFPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnPPolish;



#pragma  mark - Outlets  For Symmetry
@property (strong, nonatomic) IBOutlet UIButton *btnISymmetry;
@property (strong, nonatomic) IBOutlet UIButton *btnEXSymmetry;

@property (strong, nonatomic) IBOutlet UIButton *btnVGSymmetry;
@property (strong, nonatomic) IBOutlet UIButton *btnGSymmetry;
@property (strong, nonatomic) IBOutlet UIButton *btnFSymmetry;

@property (strong, nonatomic) IBOutlet UIButton *btnPSymmetry;



#pragma  mark - Outlets For Lab

@property (strong, nonatomic) IBOutlet UIButton *btnGIALab;
@property (strong, nonatomic) IBOutlet UIButton *btnHRDLab;
@property (strong, nonatomic) IBOutlet UIButton *btnIGLLab;

@property (strong, nonatomic) IBOutlet UIButton *btnEGLLab;
@property (strong, nonatomic) IBOutlet UIButton *btnAGSLab;



#pragma  mark - Outlets For Fluorescent
@property (strong, nonatomic) IBOutlet UIButton *btnNFluorescent;

@property (strong, nonatomic) IBOutlet UIButton *btnVSLFluorescent;

@property (strong, nonatomic) IBOutlet UIButton *btnFFluorescent;
@property (strong, nonatomic) IBOutlet UIButton *btnMFluorescent;
@property (strong, nonatomic) IBOutlet UIButton *btnSBFluorescent;
@property (strong, nonatomic) IBOutlet UIButton *btnVSTBFluorescent;


#pragma mark - Outlets For Price

@property (strong, nonatomic) IBOutlet UIButton *btnCTPrice;
@property (strong, nonatomic) IBOutlet UIButton *btnDiscountPrice;

@property (strong, nonatomic) IBOutlet UIButton *btnTotalPrice;
@property (strong, nonatomic) IBOutlet UITextField *txtPriceFrom;

@property (strong, nonatomic) IBOutlet UITextField *txtPriceTo;


#pragma mark - Outlest For popUpView

@property (strong, nonatomic) IBOutlet UIView *popUpViewCutPolishSymmetry;
@property (strong, nonatomic) IBOutlet UIView *popUpViewFluorescent;
//@property (strong, nonatomic) IBOutlet UITableView *TblVwMore;

#pragma mark - Outlets For WebParameter
@property(nonatomic,retain) NSString *StrShape;
@property(nonatomic,strong) NSString *strColourfrom;
@property(nonatomic,strong) NSString *strColourto;
@property(nonatomic,strong) NSString *strClarityfrom;
@property(nonatomic,strong) NSString *strClarityto;
@property(nonatomic,strong) NSString *strPolishfrom;
@property(nonatomic,strong) NSString *strPolishto;
@property(nonatomic,strong) NSString *strCaretfrom;
@property(nonatomic,strong) NSString *strCaretTo;
@property(nonatomic,strong) NSString *strSymmertyfrom;
@property(nonatomic,strong) NSString *strSymmertyto;


@property(nonatomic,strong) NSString *strCutFrom;
@property(nonatomic,strong) NSString *strCutTo;


@property(nonatomic,strong) NSString *strFluorescentfrom;
@property(nonatomic,strong) NSString *strFluorescentto;
@property(nonatomic,strong) NSString *strDiscountfrom;
@property(nonatomic,strong) NSString *strDiscountto;
@property(nonatomic,strong) NSString *strTotalfrom;
@property(nonatomic,strong) NSString *strTotalto;
@property(nonatomic,strong) NSString *strSellerName;
@property(nonatomic,strong) NSString *strLocation;
@property(nonatomic,strong) NSString *strLab;


#pragma  mark - Action For Shape


//- (IBAction)btnRoundClicked:(id)sender;
//- (IBAction)btnEmeraIdClicked:(id)sender;
//- (IBAction)btnPearClicked:(id)sender;
//- (IBAction)btnPrincessClicked:(id)sender;
//- (IBAction)btnOvalClicked:(id)sender;
//- (IBAction)btnCushionClicked:(id)sender;
//- (IBAction)btnCusModClicked:(id)sender;
//- (IBAction)btnHeartClicked:(id)sender;
//- (IBAction)btnMarquiseClicked:(id)sender;
//- (IBAction)btnRadiantClicked:(id)sender;
//- (IBAction)btnShapeMoreClicked:(id)sender;
//- (IBAction)btnColorMoreClicked:(id)sender;
//- (IBAction)btnLabMoreClicked:(id)sender;
//
#pragma mark - Action For Color

- (IBAction)btnDClicked:(id)sender;

- (IBAction)btnEClicked:(id)sender;
- (IBAction)btnFClicked:(id)sender;

- (IBAction)btnGclicked:(id)sender;


- (IBAction)btnHClicked:(id)sender;

- (IBAction)btnIClicked:(id)sender;
- (IBAction)btnJClicked:(id)sender;

- (IBAction)btnKClicked:(id)sender;

- (IBAction)btnLClicked:(id)sender;
- (IBAction)btnMClicked:(id)sender;


//- (IBAction)btnDClicked:(id)sender;
//- (IBAction)btnEClicked:(id)sender;
//- (IBAction)btnFClicked:(id)sender;
//- (IBAction)btnGclicked:(id)sender;
//- (IBAction)btnHClicked:(id)sender;
//- (IBAction)btnIClicked:(id)sender;
//- (IBAction)btnJClicked:(id)sender;
//- (IBAction)btnKClicked:(id)sender;
//- (IBAction)btnLClicked:(id)sender;
//- (IBAction)btnMClicked:(id)sender;

#pragma mark - Action For Clarity
- (IBAction)btnFLClarityClicked:(id)sender;

- (IBAction)btnILClarityClicked:(id)sender;

- (IBAction)btnVVS1ClarityClicked:(id)sender;


- (IBAction)btnVVS2ClarityClicked:(id)sender;
- (IBAction)btnVS1ClarityClicked:(id)sender;

- (IBAction)btnVS2ClarityClicked:(id)sender;
- (IBAction)btnSI1ClarityClicked:(id)sender;
- (IBAction)btnSI2ClarityClicked:(id)sender;
- (IBAction)btnSI3ClarityClicked:(id)sender;
- (IBAction)btnI2ClarityClicked:(id)sender;


- (IBAction)btnI1ClarityClicked:(id)sender;


- (IBAction)btnI3ClarityClicked:(id)sender;


//- (IBAction)btnFLClarityClicked:(id)sender;
//- (IBAction)btnILClarityClicked:(id)sender;
//- (IBAction)btnVVS1ClarityClicked:(id)sender;
//- (IBAction)btnVVS2ClarityClicked:(id)sender;
//- (IBAction)btnVS1ClarityClicked:(id)sender;
//- (IBAction)btnVS2ClarityClicked:(id)sender;
//- (IBAction)btnSI1ClarityClicked:(id)sender;
//- (IBAction)btnSI2ClarityClicked:(id)sender;
//- (IBAction)btnI1ClarityClicked:(id)sender;
//- (IBAction)btnI2ClarityClicked:(id)sender;
//- (IBAction)btnI3ClarityClicked:(id)sender;

#pragma  mark- IBAction For Advance Button


#pragma mark - Action For Cut
- (IBAction)btnICutClicked:(id)sender;
- (IBAction)btnEXCutClicked:(id)sender;
- (IBAction)btnVGCutClicked:(id)sender;
- (IBAction)btnGCutClicked:(id)sender;
- (IBAction)btnFCutClicked:(id)sender;
- (IBAction)btnPCutClicked:(id)sender;

//- (IBAction)btnICutClicked:(id)sender;
//- (IBAction)btnEXCutClicked:(id)sender;
//- (IBAction)btnVGCutClicked:(id)sender;
//- (IBAction)btnGCutClicked:(id)sender;
//- (IBAction)btnFCutClicked:(id)sender;
//- (IBAction)btnPCutClicked:(id)sender;


#pragma  mark - Action For Polish

- (IBAction)btnIPolishClicked:(id)sender;

- (IBAction)btnEXPolishClicked:(id)sender;
- (IBAction)btnVGPolishClicked:(id)sender;
- (IBAction)btnGPolishClicked:(id)sender;

- (IBAction)btnFPolishClicked:(id)sender;
- (IBAction)btnPPolishClicked:(id)sender;



//- (IBAction)btnIPolishClicked:(id)sender;
//- (IBAction)btnEXPolishClicked:(id)sender;
//- (IBAction)btnVGPolishClicked:(id)sender;
//- (IBAction)btnGPolishClicked:(id)sender;
//- (IBAction)btnFPolishClicked:(id)sender;
//- (IBAction)btnPPolishClicked:(id)sender;
//


#pragma mark - Action For Symmetry

- (IBAction)btnISymmetryClicked:(id)sender;

- (IBAction)btnEXSymmetryClicked:(id)sender;
- (IBAction)btnVGSymmetryClicked:(id)sender;

- (IBAction)btnGSymmetryClicked:(id)sender;
- (IBAction)btnFSymmetryClicked:(id)sender;
- (IBAction)btnPSymmetryClicked:(id)sender;



//- (IBAction)btnISymmetryClicked:(id)sender;
//- (IBAction)btnEXSymmetryClicked:(id)sender;
//- (IBAction)btnVGSymmetryClicked:(id)sender;
//- (IBAction)btnGSymmetryClicked:(id)sender;
//- (IBAction)btnFSymmetryClicked:(id)sender;
//- (IBAction)btnPSymmetryClicked:(id)sender;


#pragma  mark - Action For Lab
- (IBAction)btnGIALabClicked:(id)sender;

- (IBAction)btnHRDLabClicked:(id)sender;
- (IBAction)btnIGLLabClicked:(id)sender;
- (IBAction)btnEGLLabClicked:(id)sender;

- (IBAction)btnAGSLabClicked:(id)sender;


@property (strong, nonatomic) IBOutlet UIButton *btnLabMoreClicked;


#pragma  mark - Action For Fluorescent

- (IBAction)btnNFluorescentClicked:(id)sender;
- (IBAction)btnVSLFluorescentClicked:(id)sender;

- (IBAction)btnFFluorescentClicked:(id)sender;
- (IBAction)btnMFluorescentClicked:(id)sender;
- (IBAction)btnSBFluorescentClicked:(id)sender;
- (IBAction)btnVSTBFluorescentClicked:(id)sender;



//- (IBAction)btnNFluorescentClicked:(id)sender;
//- (IBAction)btnVSLFluorescentClicked:(id)sender;
//- (IBAction)btnFFluorescentClicked:(id)sender;
//- (IBAction)btnMFluorescentClicked:(id)sender;
//- (IBAction)btnSBFluorescentClicked:(id)sender;
//- (IBAction)btnVSTBFluorescentClicked:(id)sender;
//


#pragma mark - Action For Price

- (IBAction)btnCTPriceClicked:(id)sender;

- (IBAction)btnDiscountPriceClicked:(id)sender;
- (IBAction)btnTotalPriceClicked:(id)sender;



//- (IBAction)btnCTPriceClicked:(id)sender;
//- (IBAction)btnDiscountPriceClicked:(id)sender;
//- (IBAction)btnTotalPriceClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForCut;
@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForPolish;
@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForSymmetry;

@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForFluorescent;

#pragma mark - Action For PopupView
//@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForCut;
//@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForPolish;
//@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForSymmetry;
//@property (strong, nonatomic) IBOutlet UIButton *btnPopupViewForFluorescent;


- (IBAction)btnPopupViewCutClicked:(id)sender;
- (IBAction)btnPopupViewPolishClicked:(id)sender;
- (IBAction)btnPopupViewSymmetryClicked:(id)sender;

- (IBAction)btnPopupViewFluorescentClicked:(id)sender;


#pragma mark - Outlets For MoreShape
@property (weak, nonatomic) IBOutlet UIButton *btnMoreShape;

@property (weak, nonatomic) IBOutlet UILabel *LblMoreShapeName;

#pragma mark - Action For MoreShape


@end
