//
//  SearchTableViewCell.m
//  Cevaheer App
//
//  Created by Avion on 8/18/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "SearchTableViewCell.h"

@implementation SearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
