//
//  FancyDiamondSearch.h
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchDiamondResult.h"
#import "MoreCell.h"

@interface FancyDiamondSearch : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *btnAdvancedSearch;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnAdvancedSertchHeightContraint;
- (IBAction)btnAdvancedSearchClicked:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *innerUIView;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *innerViewHeightContraint;




@property (strong, nonatomic) IBOutlet UITableView *tblVwMore;
#pragma  mark - Outlets For Shapes
@property (weak, nonatomic) IBOutlet UIButton *btnRound;
@property (weak, nonatomic) IBOutlet UIButton *btnEmeraId;
@property (weak, nonatomic) IBOutlet UIButton *btnPear;
@property (weak, nonatomic) IBOutlet UIButton *btnPrincess;
@property (weak, nonatomic) IBOutlet UIButton *btnOval;
@property (weak, nonatomic) IBOutlet UIButton *btnCushion;
@property (weak, nonatomic) IBOutlet UIButton *btnCusMod;
@property (weak, nonatomic) IBOutlet UIButton *btnHeart;
@property (weak, nonatomic) IBOutlet UIButton *btnMarquise;
@property (weak, nonatomic) IBOutlet UIButton *btnRadiant;
@property (strong, nonatomic) IBOutlet UIButton *btnShapeMore;

#pragma mark - Actions For Shape
- (IBAction)btnRoundClicked:(id)sender;
- (IBAction)btnEmeraIdClicked:(id)sender;
- (IBAction)btnPearClicked:(id)sender;
- (IBAction)btnPrincessClicked:(id)sender;
- (IBAction)btnOvalClicked:(id)sender;
- (IBAction)btnCushionClicked:(id)sender;
- (IBAction)btnCusModClicked:(id)sender;
- (IBAction)btnHeartClicked:(id)sender;
- (IBAction)btnMarquiseClicked:(id)sender;
- (IBAction)btnRadiantClicked:(id)sender;
- (IBAction)btnShapeMoreClicked:(id)sender;

#pragma  mark - Outlets For Carat
@property (strong, nonatomic) IBOutlet UITextField *txtCaratFrom;
@property (strong, nonatomic) IBOutlet UITextField *txtCaratTo;


#pragma mark - Outlets For Lab
@property (strong, nonatomic) IBOutlet UIButton *btnGIA;
@property (strong, nonatomic) IBOutlet UIButton *btnHRD;
@property (strong, nonatomic) IBOutlet UIButton *btnAGS;
@property (strong, nonatomic) IBOutlet UIButton *btnIGI;
@property (strong, nonatomic) IBOutlet UIButton *btnEGL;
@property (strong, nonatomic) IBOutlet UIButton *btnLabMore;

#pragma mark - Actions For Lab
- (IBAction)btnGIAClicked:(id)sender;
- (IBAction)btnHRDClicked:(id)sender;
- (IBAction)btnAGSClicked:(id)sender;
- (IBAction)btnIGIClicked:(id)sender;
- (IBAction)btnEGLClicked:(id)sender;
- (IBAction)btnLabMoreClicked:(id)sender;

#pragma mark - Outlets For Intensity
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityANY;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFT;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityVL;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityL;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFL;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityF;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFDK;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFI;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFV;
@property (strong, nonatomic) IBOutlet UIButton *btnIntensityFDP;

#pragma mark - Actions For Intensity
- (IBAction)btnIntensityANYClicked:(id)sender;
- (IBAction)btnIntensityFTClicked:(id)sender;
- (IBAction)btnIntensityVLClicked:(id)sender;
- (IBAction)btnIntensityLClicked:(id)sender;
- (IBAction)btnIntensityFLClicked:(id)sender;
- (IBAction)btnIntensityFClicked:(id)sender;
- (IBAction)btnIntensityFDKClicked:(id)sender;
- (IBAction)btnIntensityFIClicked:(id)sender;
- (IBAction)btnIntensityFVClicked:(id)sender;
- (IBAction)btnIntensityFDPClicked:(id)sender;

#pragma mark - Outlets For Overtone
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneA;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneB;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneC;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneD;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneE;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneF;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneG;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneH;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneI;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneJ;
@property (strong, nonatomic) IBOutlet UIButton *btnOvertoneMore;

#pragma mark - Action For Overtone
- (IBAction)btnOvertoneAClicked:(id)sender;
- (IBAction)btnOvertoneBClicked:(id)sender;
- (IBAction)btnOvertoneCClicked:(id)sender;
- (IBAction)btnOvertoneDClicked:(id)sender;
- (IBAction)btnOvertoneEClicked:(id)sender;
- (IBAction)btnOvertoneFClicked:(id)sender;
- (IBAction)btnOvertoneGClicked:(id)sender;
- (IBAction)btnOvertoneHClicked:(id)sender;
- (IBAction)btnOvertoneIClicked:(id)sender;
- (IBAction)btnOvertoneJClicked:(id)sender;
- (IBAction)btnOvertoneMoreClicked:(id)sender;

#pragma mark - Outlets For Clarity
@property (strong, nonatomic) IBOutlet UIButton *btnClarityFL;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityIL;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityVVS1;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityVVS2;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityVS1;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityVS2;
@property (strong, nonatomic) IBOutlet UIButton *btnClaritySI1;
@property (strong, nonatomic) IBOutlet UIButton *btnClaritySI2;
@property (strong, nonatomic) IBOutlet UIButton *btnClaritySI3;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityI1;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityI2;
@property (strong, nonatomic) IBOutlet UIButton *btnClarityI3;

#pragma mark - Actions For Clarity
- (IBAction)btnClarityFLClicked:(id)sender;
- (IBAction)btnClarityILClicked:(id)sender;
- (IBAction)btnClarityVVS1Clicked:(id)sender;
- (IBAction)btnClarityVVS2Clicked:(id)sender;
- (IBAction)btnClarityVS1Clicked:(id)sender;
- (IBAction)btnClarityVS2Clicked:(id)sender;
- (IBAction)btnClaritySI1Clicked:(id)sender;
- (IBAction)btnClaritySI2Clicked:(id)sender;
- (IBAction)btnClaritySI3Clicked:(id)sender;
- (IBAction)btnClarityI1Clicked:(id)sender;
- (IBAction)btnClarityI2Clicked:(id)sender;
- (IBAction)btnClarityI3Clicked:(id)sender;

#pragma mark - Outlets For Cut
@property (strong, nonatomic) IBOutlet UIButton *btnCutI;
@property (strong, nonatomic) IBOutlet UIButton *btnCutEX;
@property (strong, nonatomic) IBOutlet UIButton *btnCutVG;
@property (strong, nonatomic) IBOutlet UIButton *btnCutG;
@property (strong, nonatomic) IBOutlet UIButton *btnCutF;
@property (strong, nonatomic) IBOutlet UIButton *btnCutP;

#pragma mark - Actions For Cut
- (IBAction)btnCutIClicked:(id)sender;
- (IBAction)btnCutEXClicked:(id)sender;
- (IBAction)btnCutVGClicked:(id)sender;
- (IBAction)btnCutGClicked:(id)sender;
- (IBAction)btnCutFClicked:(id)sender;
- (IBAction)btnCutPClicked:(id)sender;

#pragma  mark - Outlets For Polish
@property (strong, nonatomic) IBOutlet UIButton *btnPolishI;
@property (strong, nonatomic) IBOutlet UIButton *btnPolishEX;
@property (strong, nonatomic) IBOutlet UIButton *btnPolishVG;
@property (strong, nonatomic) IBOutlet UIButton *btnPolishG;
@property (strong, nonatomic) IBOutlet UIButton *btnPolishF;
@property (strong, nonatomic) IBOutlet UIButton *btnPolishP;

#pragma  mark - Actions For Polish
- (IBAction)btnPolishIClicked:(id)sender;
- (IBAction)btnPolishEXClicked:(id)sender;
- (IBAction)btnPolishVGClicked:(id)sender;
- (IBAction)btnPolishGClicked:(id)sender;
- (IBAction)btnPolishFClicked:(id)sender;
- (IBAction)btnPolishPClicked:(id)sender;

#pragma mark - Outlets For Symmetry
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryI;
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryEX;
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryVG;
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryG;
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryF;
@property (strong, nonatomic) IBOutlet UIButton *btnSymmetryP;

#pragma mark - Actions For Symmetry
- (IBAction)btnSymmetryIClicked:(id)sender;
- (IBAction)btnSymmetryEXClicked:(id)sender;
- (IBAction)btnSymmetryVGClicked:(id)sender;
- (IBAction)btnSymmetryGClicked:(id)sender;
- (IBAction)btnSymmetryFClicked:(id)sender;
- (IBAction)btnSymmetryPClicked:(id)sender;

#pragma mark - Outlets For Fluorescent
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentN;
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentVSL;
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentF;
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentM;
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentSB;
@property (strong, nonatomic) IBOutlet UIButton *btnFluorescentVSTB;


#pragma mark - Actions For Fluorescent
- (IBAction)btnFluorescentNClicked:(id)sender;
- (IBAction)btnFluorescentVSLClicked:(id)sender;
- (IBAction)btnFluorescentFClicked:(id)sender;
- (IBAction)btnFluorescentMClicked:(id)sender;
- (IBAction)btnFluorescentSBClicked:(id)sender;
- (IBAction)btnFluorescentVSTBClicked:(id)sender;

#pragma mark - Outlets For Price
@property (strong, nonatomic) IBOutlet UIButton *btnPriceCT;
@property (strong, nonatomic) IBOutlet UIButton *btnPriceTotal;


#pragma mark - Actions For Price
- (IBAction)btnPriceCTClicked:(id)sender;
- (IBAction)btnPriceTotalClicked:(id)sender;

#pragma mark - Actions For Controllere
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSearchClicked:(id)sender;




@end
