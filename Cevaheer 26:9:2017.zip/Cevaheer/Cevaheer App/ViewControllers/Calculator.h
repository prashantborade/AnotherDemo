//
//  Calculator.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SavedCalculations.h"
#import "WebserviceClass.h"
#import <sqlite3.h>
#import "Compare.h"
#import "WhiteDiamondSearch.h"
#import <Google/Analytics.h>
#import "GAITrackedViewController.h"



@interface Calculator : GAITrackedViewController
{
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;
    NSString *strEmail;
    int flag;
}
@property (strong, nonatomic) IBOutlet UILabel *lblDiscount;

@property (strong, nonatomic) IBOutlet UIView *UIViewAvg;
@property (strong, nonatomic) IBOutlet UIScrollView *UIScrollViewOutlets;

@property (weak, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UIPickerView *shapePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *colorPicker;
@property (weak, nonatomic) IBOutlet UIPickerView *discountPicker;
@property (weak, nonatomic) IBOutlet UIPickerView *clarityPicker;

@property(nonatomic,strong) NSString *result;
@property(nonatomic,strong) NSString *mainResult;
@property(nonatomic,strong) NSMutableArray *jsonArray;

@property (strong, nonatomic) IBOutlet UIView *UIViewAllButtons;

@property (strong, nonatomic) IBOutlet UINavigationBar *navigationBar;
- (IBAction)btnMenuClicked:(id)sender;

- (IBAction)btnSavedCalculationsClicked:(id)sender;

#pragma mark - Footer Menu
- (IBAction)btnMessageClicked:(id)sender;
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnMemberProfileClicked:(id)sender;
- (IBAction)btnFindDiamondClicked:(id)sender;

#pragma mark - For PickerView
@property(nonatomic,strong) NSMutableArray *shapePickerArray;
@property(nonatomic,strong) NSMutableArray *colorPickerArray;
@property(nonatomic,strong) NSMutableArray *clarityPickerArray;
@property(nonatomic,strong) NSMutableArray *DiscountPickerArray;


#pragma mark - Database
@property(nonatomic,strong) NSString *databasePath;
@property(nonatomic) sqlite3 *DB;
@property(nonatomic,strong) NSString *strShape;
@property(nonatomic,strong) NSString *strColor;
@property(nonatomic,strong) NSString *strClarity;
@property(nonatomic,strong) NSString *strdiscount;


#pragma mark - Outlets For Calculator Button
@property (strong, nonatomic) IBOutlet UIButton *btn9;
@property (strong, nonatomic) IBOutlet UIButton *btn8;
@property (strong, nonatomic) IBOutlet UIButton *btn7;
@property (strong, nonatomic) IBOutlet UIButton *btn6;
@property (strong, nonatomic) IBOutlet UIButton *btn5;
@property (strong, nonatomic) IBOutlet UIButton *btn4;
@property (strong, nonatomic) IBOutlet UIButton *btn3;
@property (strong, nonatomic) IBOutlet UIButton *btn2;
@property (strong, nonatomic) IBOutlet UIButton *btn1;
@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnZero;
@property (strong, nonatomic) IBOutlet UIButton *btnDot;
@property (strong, nonatomic) IBOutlet UIButton *btnReset;
@property (strong, nonatomic) IBOutlet UIButton *btnCompare;
@property (strong, nonatomic) IBOutlet UIButton *btnSearch;
@property (strong, nonatomic) IBOutlet UIButton *btnAvg;

@property (strong, nonatomic) IBOutlet UILabel *LblYourPrice;
@property (strong, nonatomic) IBOutlet UILabel *LblYourPriceTotal;
@property (strong, nonatomic) IBOutlet UILabel *lblListPrice;

@property (strong, nonatomic) IBOutlet UILabel *LblDisplayValue;
@property (strong, nonatomic) IBOutlet UILabel *lblListPriceTotal;

#pragma mark - IBAction For Calculator Button
- (IBAction)btn9Clicked:(id)sender;

- (IBAction)btn8Clicked:(id)sender;

- (IBAction)btn7Clicked:(id)sender;
- (IBAction)btn6Clicked:(id)sender;

- (IBAction)btn5Clicked:(id)sender;

- (IBAction)btn4Clicked:(id)sender;

- (IBAction)btn3Clicked:(id)sender;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btn2Clicked:(id)sender;
- (IBAction)btn1Clicked:(id)sender;
- (IBAction)btnZeroClicked:(id)sender;
- (IBAction)btnDotClicked:(id)sender;

- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnCompareClicked:(id)sender;
- (IBAction)btnAvgClicked:(id)sender;

- (IBAction)btnSearchClicked:(id)sender;

#pragma mark -

@end
