//
//  MessageDetails.h
//  Cevaheer App
//
//  Created by SMS on 04/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageDetails : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *userNameLbl;
@property (weak, nonatomic) IBOutlet UILabel *subjectLbl;
@property (weak, nonatomic) IBOutlet UITextView *MessageContentView;
- (IBAction)btnback:(id)sender;

@property(nonatomic,strong) NSString *userName;
@property(nonatomic,strong) NSString *subjects;
@property(nonatomic,strong) NSString *messageContent;
@property(nonatomic,strong) NSString *FromEmail;


@property (strong, nonatomic) IBOutlet UIButton *btnReply;
@property (strong, nonatomic) IBOutlet UIButton *btnForward;



- (IBAction)btnReplyClicked:(id)sender;
- (IBAction)btnForwardClicked:(id)sender;


@end
