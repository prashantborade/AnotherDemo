//
//  WhiteSearchClass.m
//  Cevaheer App
//
//  Created by SMS Systems on 11/14/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "WhiteSearchClass.h"

@implementation WhiteSearchClass

@end
