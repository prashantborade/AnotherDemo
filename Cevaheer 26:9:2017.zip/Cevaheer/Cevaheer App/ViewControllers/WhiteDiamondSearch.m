//
//  WhiteDiamondSearch.m
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "WhiteDiamondSearch.h"


@interface WhiteDiamondSearch ()
{
    UIAlertView  *statusAlert;
    NSIndexPath *selectedIndexPath;
}

@property(nonatomic,strong) NSMutableArray *ShapeArray;
@property(nonatomic,strong) NSMutableArray *LabArray;


@end
int count=0;
int value=0;


@implementation WhiteDiamondSearch
#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    Lid=@"";
    
    language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    _checkColor=[[NSMutableArray alloc] init];
    _checkLab=[[NSMutableArray alloc] init];
    
    countFinish=0;
    [_btnMoreShape setTitle:@"" forState:UIControlStateNormal];
    _btnMoreShape.userInteractionEnabled=false;
    
    //_ScrollView.hidden=YES;
   // _TopView.hidden=YES;
    
    _inerViewHeight.constant=_inerViewHeight.constant-520.0f;
    
    _txtCaratFrom.text=@"0.00";
    _txtCaratTo.text=@"99.99";
    
    _UIViewForTesting.hidden=YES;
    _UIviewTestingConstraintHeight.constant=0.1f;
    _btnAdvancedSearch.userInteractionEnabled=true;
    
  
       
    _txtCaratFrom.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    _txtCaratTo.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    
   // [self kepadDoneCancel];
    
//    [SCNumberKeyBoard showWithTextField: _txtCaratFrom enter:^(UITextField *textField, NSString *number) {
//        NSLog(@"textField:%@ - number:%@",  _txtCaratFrom, number);
//    } close:^(UITextField *textField, NSString *number) {
//        NSLog(@"textField:%@ - number:%@",  _txtCaratFrom, number);
//    }];
//
//    
//    [SCNumberKeyBoard showWithTextField: _txtCaratTo enter:^(UITextField *textField, NSString *number)
//    {
//        NSLog(@"textField:%@ - number:%@",  _txtCaratTo, number);
//    } close:^(UITextField *textField, NSString *number)
//     {
//        NSLog(@"textField:%@ - number:%@",  _txtCaratTo, number);
//    }];
    
    btnCountColor=0;
    btnCountClarity=0;
    btnCountCut=0;
    btnCountPolish=0;
    btnCountSymmetry=0;
    btnCountLab=0;
    btnCountFluorescent=0;
    count=0;
    
    /*Flag values
     1-Caret
     2-Discount
     3-Total
     */
    
    flag=1;
    
    //Flag for morePopup
    flag2=1;
    
    
    flag3=0;
    flag5=0;
    flag4=0;
    
    
    _moreShapeImgArray= [[NSMutableArray alloc] initWithObjects:[UIImage imageNamed:@"Round_Black"],[UIImage imageNamed:@"Pear_Black"],nil];
    
    _moreShapeImgNameArray=[[NSMutableArray alloc] initWithObjects:@"Round",@"Pear", nil];
    _moreLabArray= [[NSMutableArray alloc] initWithObjects:@"IDL",@"DGA",@"CGL",@"DCLA",@"GCAL",@"GHI",@"IIDGR",@"GSI",@"NGTC",@"PGS",@"VGR",@"GLT",@"OTHER",@"NONE",nil];
    
    _moreColorArray= [[NSMutableArray alloc] initWithObjects:@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z", nil];
    
    
    
    colorTempArray=[[NSMutableArray alloc] init];
    labTempArray=[[NSMutableArray alloc] init];
    
    
//    
//    NSMutableDictionary *Dict = [NSMutableDictionary dictionary];
//    UIImage *Round_Black=[UIImage imageNamed:@"Round_Black"];
//    
//    [Dict setObject:Round_Black forKey:@"imgShape"];
//    [Dict setObject:@"Round"forKey:@"ShapeName"];
//   
//    [_moreShapeArray addObject:Dict];
//    
//    UIImage *Marquise_Black=[UIImage imageNamed:@"Marquise_Black"];
//    
//    [Dict setObject:Marquise_Black forKey:@"imgShape"];
//    [Dict setObject:@"Marquise"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgHeart_Black=[UIImage imageNamed:@"Heart_Black"];
//    
//    [Dict setObject:imgHeart_Black forKey:@"imgShape"];
//    [Dict setObject:@"Heart"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgOval_Black=[UIImage imageNamed:@"Oval_Black"];
//    
//    [Dict setObject:imgOval_Black forKey:@"imgShape"];
//    [Dict setObject:@"Round"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgPear_Black=[UIImage imageNamed:@"Pear_Black"];
//    
//    [Dict setObject:imgPear_Black forKey:@"imgShape"];
//    [Dict setObject:@"Pear"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgEmeraId_Black=[UIImage imageNamed:@"EmeraId_Black"];
//    
//    [Dict setObject:imgEmeraId_Black forKey:@"imgShape"];
//    [Dict setObject:@"EmeraId"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgPrincess_Black=[UIImage imageNamed:@"Princess_Black"];
//    
//    [Dict setObject:imgPrincess_Black forKey:@"imgShape"];
//    [Dict setObject:@"Princess"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgsquare_six_black=[UIImage imageNamed:@"square_six_black"];
//    
//    [Dict setObject:imgsquare_six_black forKey:@"imgShape"];
//    [Dict setObject:@"Square_six"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgsquare_five_black=[UIImage imageNamed:@"square_five_black"];
//    
//    [Dict setObject:imgsquare_five_black forKey:@"imgShape"];
//    [Dict setObject:@"Square_five"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
//
//    UIImage *imgsquare_three_black=[UIImage imageNamed:@"square_three_black"];
//    
//    [Dict setObject:imgsquare_three_black forKey:@"imgShape"];
//    [Dict setObject:@"Square_three"forKey:@"ShapeName"];
//    
//    [_moreShapeArray addObject:Dict];
    
  
  
//    _txtPriceFrom.text=@"";
//    _txtPriceto.text=@"";
    
    _ShapeArray=[[NSMutableArray alloc] init];
    _LabArray =[[NSMutableArray alloc] init];
    
    _colorArray=[[NSMutableArray alloc] init];
    _clarityArray=[[NSMutableArray alloc] init];
    _cutArray=[[NSMutableArray alloc] init];
    _polishArray=[[NSMutableArray alloc] init];
    _caretArray=[[NSMutableArray alloc] init];
    _discountArray=[[NSMutableArray alloc] init];
    _symmetryArray=[[NSMutableArray alloc] init];
    _labArray=[[NSMutableArray alloc] init];
    _fluorescentArray=[[NSMutableArray alloc] init];
   
    
    
    //For PriceButtons
    //Selected
    _btnCTPrice.backgroundColor=[UIColor darkGrayColor];
    [_btnCTPrice setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnDiscountPrice.backgroundColor=[UIColor whiteColor];
    [_btnDiscountPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    _btnTotalPrice.backgroundColor=[UIColor whiteColor];
    [_btnTotalPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    
    
    [_btnMarquise setImage:[UIImage imageNamed:@"Marquise_Black"] forState:UIControlStateNormal];
    [_btnMarquise setImage:[UIImage imageNamed:@"marquise_blue"] forState:UIControlStateSelected];
    
    [_btnHeart setImage:[UIImage imageNamed:@"Heart_Black"] forState:UIControlStateNormal];
    [_btnHeart setImage:[UIImage imageNamed:@"heart_blue"] forState:UIControlStateSelected];
    
    [_btnOval setImage:[UIImage imageNamed:@"Oval_Black"] forState:UIControlStateNormal];
    [_btnOval setImage:[UIImage imageNamed:@"oval_blue"] forState:UIControlStateSelected];
    
    [_btnPear setImage:[UIImage imageNamed:@"Pear_Black"] forState:UIControlStateNormal];
    [_btnPear setImage:[UIImage imageNamed:@"pear_blue"] forState:UIControlStateSelected];
    
    [_btnRound setImage:[UIImage imageNamed:@"Round_Black"] forState:UIControlStateNormal];
    [_btnRound setImage:[UIImage imageNamed:@"round_blue"] forState:UIControlStateSelected];
    
    [_btnEmerald setImage:[UIImage imageNamed:@"square_six_black"] forState:UIControlStateNormal];
    [_btnEmerald setImage:[UIImage imageNamed:@"square_six_blue"] forState:UIControlStateSelected];
    
    [_btnPrincess setImage:[UIImage imageNamed:@"square_two_black"] forState:UIControlStateNormal];
    [_btnPrincess setImage:[UIImage imageNamed:@"square_two_blue"] forState:UIControlStateSelected];
   // _tblVwMore.tableFooterView=[UIView new];
    
    [_btnCushion setImage:[UIImage imageNamed:@"EmeraId_Black"] forState:UIControlStateNormal];
    [_btnCushion setImage:[UIImage imageNamed:@"Emerald_blue"] forState:UIControlStateSelected];
    
    [_btnCusMod setImage:[UIImage imageNamed:@"square_three_black"] forState:UIControlStateNormal];
    [_btnCusMod setImage:[UIImage imageNamed:@"square_three_blue"] forState:UIControlStateSelected];
    
    [_btnRadiant setImage:[UIImage imageNamed:@"Princess_Black"] forState:UIControlStateNormal];
    [_btnRadiant setImage:[UIImage imageNamed:@"Princess_blue"] forState:UIControlStateSelected];
    
    
    //For Color
    
    _btnDColor.tintColor=[UIColor clearColor];
    [_btnDColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnDColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_white"] forState:UIControlStateNormal];
    
    [_btnDColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnDColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
     _btnEColor.tintColor=[UIColor clearColor];
    [_btnEColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
   
    
    [_btnEColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnFColor.tintColor=[UIColor clearColor];
    [_btnFColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnFColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnGColor.tintColor=[UIColor clearColor];
    [_btnGColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnGColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnGColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnHColor.tintColor=[UIColor clearColor];
    [_btnHColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnHColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnHColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnIColor.tintColor=[UIColor clearColor];
    [_btnIColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnIColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnIColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnJColor.tintColor=[UIColor clearColor];
    [_btnJColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnJColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnJColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnKColor.tintColor=[UIColor clearColor];
    [_btnKColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnKColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnKColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
     _btnLColor.tintColor=[UIColor clearColor];
    [_btnLColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnLColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnLColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnMColor.tintColor=[UIColor clearColor];
    [_btnMColor setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnMColor setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnMColor setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    //Finish Feature
    _btn3XOutle.tintColor=[UIColor clearColor];
    [_btn3XOutle setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btn3XOutle setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btn3XOutle setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    _btnEXOutlet.tintColor=[UIColor clearColor];
    [_btnEXOutlet setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnEXOutlet setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEXOutlet setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVGPlusOutlet.tintColor=[UIColor clearColor];
    [_btnVGPlusOutlet setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVGPlusOutlet setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVGPlusOutlet setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    _btnVGMinusOutlet.tintColor=[UIColor clearColor];
    [_btnVGMinusOutlet setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVGMinusOutlet setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVGMinusOutlet setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    //for clatiy
    
    _btnFLCLarity.tintColor=[UIColor clearColor];
    [_btnFLCLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnFLCLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFLCLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    _btnILCLarity.tintColor=[UIColor clearColor];
    [_btnILCLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnILCLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnILCLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    
    
    _btnVVS1CLarity.tintColor=[UIColor clearColor];
    [_btnVVS1CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVVS1CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVVS1CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    _btnVVS2CLarity.tintColor=[UIColor clearColor];
    [_btnVVS2CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVVS2CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVVS2CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnVS1CLarity.tintColor=[UIColor clearColor];
    [_btnVS1CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVS1CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVS1CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnVS2CLarity.tintColor=[UIColor clearColor];
    [_btnVS2CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnVS2CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVS2CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    
    _btnSI1CLarity.tintColor=[UIColor clearColor];
    [_btnSI1CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnSI1CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSI1CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnSI2CLarity.tintColor=[UIColor clearColor];
    [_btnSI2CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnSI2CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSI2CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnSI3CLarity.tintColor=[UIColor clearColor];
    [_btnSI3CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnSI3CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSI3CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnI1CLarity.tintColor=[UIColor clearColor];
    [_btnI1CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnI1CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnI1CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnI2CLarity.tintColor=[UIColor clearColor];
    [_btnI2CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnI2CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnI2CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnI3CLarity.tintColor=[UIColor clearColor];
    [_btnI3CLarity setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    
    [_btnI3CLarity setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnI3CLarity setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    // For Cut
    
    _btnICut.tintColor=[UIColor clearColor];
    [_btnICut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnICut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnICut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnEXCut.tintColor=[UIColor clearColor];
    [_btnEXCut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnEXCut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEXCut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVGCut.tintColor=[UIColor clearColor];
    [_btnVGCut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnVGCut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVGCut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    
    
    _btnGCut.tintColor=[UIColor clearColor];
    [_btnGCut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnGCut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnGCut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnFCut.tintColor=[UIColor clearColor];
    [_btnFCut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnFCut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFCut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnPCut.tintColor=[UIColor clearColor];
    [_btnPCut setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnPCut setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPCut setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    // For Polish
    
    
    _btnIPolish.tintColor=[UIColor clearColor];
    [_btnIPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];

    [_btnIPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnIPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnEXPolish.tintColor=[UIColor clearColor];
    [_btnEXPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnEXPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEXPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVGPolish.tintColor=[UIColor clearColor];
    [_btnVGPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnVGPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVGPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnGPolish.tintColor=[UIColor clearColor];
    [_btnGPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnGPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnGPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnFPolish.tintColor=[UIColor clearColor];
    [_btnFPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnFPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnPPolish.tintColor=[UIColor clearColor];
    [_btnPPolish setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnPPolish setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPPolish setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    //For Symmetry
    
    _btnISymmetry.tintColor=[UIColor clearColor];
    [_btnISymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnISymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnISymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnEXSymmetry.tintColor=[UIColor clearColor];
    [_btnEXSymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnEXSymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEXSymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVGSymmetry.tintColor=[UIColor clearColor];
    [_btnVGSymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnVGSymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVGSymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnGSymmetry.tintColor=[UIColor clearColor];
    [_btnGSymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnGSymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnGSymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnFSymmetry.tintColor=[UIColor clearColor];
    [_btnFSymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnFSymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFSymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnPSymmetry.tintColor=[UIColor clearColor];
    [_btnPSymmetry setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnPSymmetry setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnPSymmetry setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    
    //for Lab
    
    _btnGIALab.tintColor=[UIColor clearColor];
    [_btnGIALab setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnGIALab setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnGIALab setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnHRDLab.tintColor=[UIColor clearColor];
    [_btnHRDLab setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnHRDLab setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnHRDLab setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnIGLLab.tintColor=[UIColor clearColor];
    [_btnIGLLab setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnIGLLab setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnIGLLab setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnEGLLab.tintColor=[UIColor clearColor];
    [_btnEGLLab setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnEGLLab setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnEGLLab setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    _btnAGSLab.tintColor=[UIColor clearColor];
    [_btnAGSLab setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnAGSLab setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnAGSLab setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    
    //for Fluorescent
    
    _btnNFluorescent.tintColor=[UIColor clearColor];
    [_btnNFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnNFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnNFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVSLFluorescent.tintColor=[UIColor clearColor];
    [_btnVSLFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnVSLFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVSLFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnFFluorescent.tintColor=[UIColor clearColor];
    [_btnFFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnFFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnFFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnMFluorescent.tintColor=[UIColor clearColor];
    [_btnMFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnMFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnMFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnSBFluorescent.tintColor=[UIColor clearColor];
    [_btnSBFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnSBFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnSBFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    
    _btnVSTBFluorescent.tintColor=[UIColor clearColor];
    [_btnVSTBFluorescent setBackgroundImage:[UIImage imageNamed:@"btn_btn_blue"] forState:UIControlStateSelected];
    [_btnVSTBFluorescent setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_btnVSTBFluorescent setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    

    _btnLocationHeight.constant=0.1f;
    
    //[self btnShapeClicked:self];
    
    
    
    _txtPriceFrom.delegate=self;
    _txtPriceTo.delegate=self;
    

     self.screenName=@"Find diamond";
    
    
    
    
}
-(void)viewWillAppear:(BOOL)animated{
    
    
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_tblMoreShape == tableView) {
        
        return 2;
    }
    else if (_tblMoreColor == tableView)
    {
        return _moreColorArray.count;
    }
    else{
        
        return _moreLabArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (_tblMoreShape == tableView) {
        
        static NSString *cellIdentifier = @"MoreCell";
        
        MoreCell *cell = (MoreCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[MoreCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        
        UIImage *img=[_moreShapeImgArray objectAtIndex:indexPath.row];
        [cell.btnMoreShape setImage:img forState:UIControlStateNormal];
        
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        cell.moreShapeName.text=[_moreShapeImgNameArray objectAtIndex:indexPath.row];
        [cell setMyCellIndex : indexPath.row];
         
        NSInteger *indexRow=(long)cell.myCellIndex;
        
        NSLog(@"indexRow = %ld",indexRow);
        
        
        [cell.btnMoreShape addTarget:self action:@selector(btnShapeClicked:) forControlEvents:UIControlEventTouchUpInside];
        
         return cell;
    }
    else if (_tblMoreColor == tableView)
    {
        static NSString *cellIdentifier = @"MoreCell2";
        
        MoreCell2 *cell = (MoreCell2 *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[MoreCell2 alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        
        if ([colorTempArray containsObject:[_moreColorArray objectAtIndex:indexPath.row]])
        {
            cell.backgroundColor=[UIColor colorWithRed:0/255.0f green:135/255.0f blue:190/255.0f alpha:1.0f];
            cell.ColorName.text=[_moreColorArray objectAtIndex:indexPath.row];
            
        }else
        {
              cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
              cell.ColorName.text=[_moreColorArray objectAtIndex:indexPath.row];
            
        }

        
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
     
        
         return cell;
    }
    else 
    {
        
        static NSString *cellIdentifier = @"MoreCells3";
        
        MoreCells3 *cell = (MoreCells3 *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[MoreCells3 alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        
        if ([labTempArray containsObject:[_moreLabArray objectAtIndex:indexPath.row]])
        {
            cell.backgroundColor=[UIColor colorWithRed:0/255.0f green:135/255.0f blue:190/255.0f alpha:1.0f];
            cell.LabName.text=[_moreLabArray objectAtIndex:indexPath.row];
            
        }else
        {
            cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
            cell.LabName.text=[_moreLabArray objectAtIndex:indexPath.row];
            
        }

        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        return cell;
    }

    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
       
    
    if (_tblMoreShape == tableView) {
   
    }
    else if (_tblMoreColor == tableView)
    {
        
//      NSString *colorName=[_moreColorArray objectAtIndex:indexPath.row];
//      NSLog(@"Selected Name=%@",colorName);
        
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
       
        if ([colorTempArray containsObject:[_moreColorArray objectAtIndex:indexPath.row]])
        {
            
            cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
            [colorTempArray removeObject:[_moreColorArray objectAtIndex:indexPath.row]];
            [_colorArray removeObject:[_moreColorArray objectAtIndex:indexPath.row]];
            
            NSLog(@" _colorArray =%@",_colorArray);
            
        }else
        {
            cell.backgroundColor=[UIColor colorWithRed:0/255.0f green:135/255.0f blue:190/255.0f alpha:1.0f];
            [colorTempArray addObject:[_moreColorArray objectAtIndex:indexPath.row]];
            [_colorArray addObject:[_moreColorArray objectAtIndex:indexPath.row]];
            
            NSLog(@"_colorArray =%@",_colorArray);
            
        }
        
    }
    else
    {
        
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        
        if ([labTempArray containsObject:[_moreLabArray objectAtIndex:indexPath.row]])
        {
            
            cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
            [labTempArray removeObject:[_moreLabArray objectAtIndex:indexPath.row]];
            [_LabArray removeObject:[_moreLabArray objectAtIndex:indexPath.row]];
            
            NSLog(@"_LabArray=%@",_LabArray);
            
        }else
        {
            cell.backgroundColor=[UIColor colorWithRed:0/255.0f green:135/255.0f blue:190/255.0f alpha:1.0f];
            [labTempArray addObject:[_moreLabArray objectAtIndex:indexPath.row]];
            [_LabArray addObject:[_moreLabArray objectAtIndex:indexPath.row]];
            
            NSLog(@"_LabArray=%@",_LabArray);
            
        }
        
//        NSString *LabName=[_moreLabArray objectAtIndex:indexPath.row];
//        NSLog(@"Selected Name=%@",LabName);
//        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
//        cell.backgroundColor=[UIColor colorWithRed:0/255.0f green:135/255.0f blue:190/255.0f alpha:1.0f];
    }

    
   // [[KGModal sharedInstance]hideAnimated:YES];
    
    //    MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
    //    [self.navigationController pushViewController:MemberInfoVC animated:YES];
    
}
//-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    
//    if (_tblMoreShape == tableView) {
//        
//        
//    }
//    else if (_tblMoreColor == tableView)
//    {
//        
////        NSString *colorName=[_moreColorArray objectAtIndex:indexPath.row];
////        NSLog(@"Selected Name=%@",colorName);
////        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
////        cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
//    }
//    else{
////        NSString *LabName=[_moreLabArray objectAtIndex:indexPath.row];
////        NSLog(@"Selected Name=%@",LabName);
////        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
////        cell.backgroundColor=[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0f];
//    }
//
//}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
#pragma mark - IBActions For TabBar
- (IBAction)btnResetClicked:(id)sender {
   
//reset for Shape
    [_btnRound setSelected:NO];
    [_btnMarquise setSelected:NO];
    [_btnOval setSelected:NO];
    [_btnPear setSelected:NO];
    [_btnPrincess setSelected:NO];
    [_btnRadiant setSelected:NO];
    [_btnHeart setSelected:NO];
    [_btnEmerald setSelected:NO];
    [_btnCushion setSelected:NO];
    [_btnCusMod setSelected:NO];

//reset for Lab
    [_btnGIALab setSelected:NO];
    [_btnHRDLab setSelected:NO];
    [_btnIGLLab setSelected:NO];
    [_btnEGLLab setSelected:NO];
    [_btnAGSLab setSelected:NO];
//reset for color
    [_btnDColor setSelected:NO];
    [_btnEColor setSelected:NO];
    [_btnFColor setSelected:NO];
    [_btnGColor setSelected:NO];
    [_btnHColor setSelected:NO];
    [_btnIColor setSelected:NO];
    [_btnJColor setSelected:NO];
    [_btnKColor setSelected:NO];
    [_btnLColor setSelected:NO];
    [_btnMColor setSelected:NO];
    
  
     _btnDColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnEColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnFColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnGColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnHColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnIColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnJColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnKColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnLColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnMColor.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
    btnCountColor=0;
    
//reset for Clarity
    
    [_btnFLCLarity setSelected:NO];
    [_btnILCLarity setSelected:NO];
    [_btnVVS1CLarity setSelected:NO];
    
    [_btnVVS2CLarity setSelected:NO];
    [_btnVS1CLarity setSelected:NO];
    [_btnVS2CLarity setSelected:NO];
    [_btnSI1CLarity setSelected:NO];
    [_btnSI2CLarity setSelected:NO];
    [_btnSI3CLarity setSelected:NO];
    [_btnI1CLarity setSelected:NO];
    [_btnI2CLarity setSelected:NO];
    [_btnI3CLarity setSelected:NO];
    
    _btnFLCLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnILCLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVVS1CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVVS2CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVS1CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVS2CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnSI1CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnSI2CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnSI3CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnI1CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnI2CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnI3CLarity.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
     btnCountClarity=0;
    
    //reset for Cut
    
    [_btnICut setSelected:NO];
    [_btnEXCut setSelected:NO];
    [_btnVGCut setSelected:NO];
    [_btnGCut setSelected:NO];
    [_btnFCut setSelected:NO];
    [_btnPCut setSelected:NO];
    
    _btnICut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnEXCut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVGCut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnGCut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnFCut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnPCut.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
    btnCountCut=0;
    
//reset for Polish
    [_btnIPolish setSelected:NO];
    [_btnEXPolish setSelected:NO];
    [_btnVGPolish setSelected:NO];
    [_btnGPolish setSelected:NO];
    [_btnFPolish setSelected:NO];
    [_btnPPolish setSelected:NO];
    
    _btnIPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnEXPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVGPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnGPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnFPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnPPolish.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
    btnCountPolish=0;
 
//reset for Symmetry
    [_btnISymmetry setSelected:NO];
    [_btnEXSymmetry setSelected:NO];
    [_btnVGSymmetry setSelected:NO];
    [_btnGSymmetry setSelected:NO];
    [_btnFSymmetry setSelected:NO];
    [_btnPSymmetry setSelected:NO];
    
    _btnISymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnEXSymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVGSymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnGSymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnFSymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnPSymmetry.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
    btnCountSymmetry=0;
    
//reset for fluorescent
    [_btnNFluorescent setSelected:NO];
    [_btnVSLFluorescent setSelected:NO];
    [_btnFFluorescent setSelected:NO];
    [_btnMFluorescent setSelected:NO];
    [_btnSBFluorescent setSelected:NO];
    [_btnVSTBFluorescent setSelected:NO];
    
    _btnNFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVSLFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnFFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnMFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnSBFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVSTBFluorescent.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    
    btnCountFluorescent=0;

 // reset for Finish
     [_btn3XOutle setSelected:NO];
     [_btnEXOutlet setSelected:NO];
     [_btnVGPlusOutlet setSelected:NO];
     [_btnVGMinusOutlet setSelected:NO];
    _btn3XOutle.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnEXOutlet.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVGPlusOutlet.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];
    _btnVGMinusOutlet.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"btn_btn_white"]];

    
    
// reset for all Array
    
    [_ShapeArray removeAllObjects];
    [_colorArray removeAllObjects];
    [_clarityArray removeAllObjects];
    [_cutArray removeAllObjects];
    [_polishArray removeAllObjects];
    [_symmetryArray removeAllObjects];
    [_LabArray removeAllObjects];
    [_fluorescentArray removeAllObjects];
    [colorTempArray removeAllObjects];
    [labTempArray removeAllObjects];
    
    [_tblMoreColor reloadData];
    [_tblMoreLab reloadData];
    
   _txtCaratFrom.text=@"";
   _txtCaratTo.text=@"";
    
    _strCaretfrom=@"";
    _strCaretTo=@"";
    _strDiscountfrom=@"";
    _strDiscountto=@"";
    _strTotalfrom=@"";
    _strTotalto=@"";
    _txtPriceFrom.text=@"";
    _txtPriceTo.text=@"";
    _strFinish=@"";
    
   
    
}

- (IBAction)btnSearchClicked:(id)sender {
    
//    Colours
//    Clarities
//    Cuts
//    Polishs
//    Symmerties
//    Fluorescents
//    NSString *strColorfrom;
//    NSString *strColorto;
//    
//    NSString *strClarityfrom;
//    NSString *strClarityto;
//    
//    NSString *strPolishfrom;
//    NSString *strPolishto;
//    
//    NSString *strSymmertyfrom;
//    NSString *strSymmertyto;
//    
//    
//    NSString *strFluorescentfrom;
//    NSString *strFluorescentto;
    
    
   NSString*pricePerCaratFrom=@"",*pricePerCaratTo=@"",*discountFrom=@"",*discountTo=@"",*totalFrom=@"",*totalTo=@"";
    
    
    if (flag==1)
    {
        pricePerCaratFrom=_txtPriceFrom.text;
        pricePerCaratTo=_txtPriceTo.text;
        
    }else if (flag==2)
    {
        discountFrom=_txtPriceFrom.text;
        discountTo=_txtPriceTo.text;
    }else
    {
        totalFrom=_txtPriceFrom.text;
        totalTo=_txtPriceTo.text;
    }
    
    
    
    NSString *greeting = [_ShapeArray componentsJoinedByString:@","];
    NSString *lab=[_LabArray componentsJoinedByString:@","];
    NSString *color=[_colorArray componentsJoinedByString:@","];
    NSString *clarity=[_clarityArray componentsJoinedByString:@","];
    NSString *polish=[_polishArray componentsJoinedByString:@","];
    NSString *symmetry=[_symmetryArray componentsJoinedByString:@","];
    NSString *fluorescent=[_fluorescentArray componentsJoinedByString:@","];
    NSString *cut=[_cutArray componentsJoinedByString:@","];
 
    
    SearchDiamondResult *destinationController = [[self storyboard]instantiateViewControllerWithIdentifier:@"SearchDiamondResult3"];
    destinationController.strShape=greeting;
    
    destinationController.strSizefrom=[NSString stringWithFormat:@"%@",_txtCaratFrom.text];
    destinationController.strSizeto=[NSString stringWithFormat:@"%@",_txtCaratTo.text];
    destinationController.strLab=lab;
    destinationController.strColour=color;
    destinationController.strClarity=clarity;
    destinationController.strCut=cut;
    destinationController.strPolish=polish;
    destinationController.strSymmerty=symmetry;
    destinationController.strFluorescent=fluorescent;
    destinationController.strFinishTypeFeature=_strFinish;
   
    
    
      
    //    destinationController.strColourfrom=[_colorArray objectAtIndex:0];
    //    destinationController.strColourfrom=[_colorArray objectAtIndex:1];
    
//    if (_colorArray.count>=2) {
//        
//        
//        destinationController.strColourfrom=[_colorArray objectAtIndex:0];
//        destinationController.strColourto=[_colorArray objectAtIndex:1];
//        
//    
//    }
//    else
//    {
//        strColorfrom=@"";
//        strColorto=@"";
//        
//        destinationController.strColourfrom=strColorfrom;
//        destinationController.strColourto=strColorto;
//
//        if (_colorArray.count == 1)
//        {
//            
//            destinationController.strColourfrom=[_colorArray objectAtIndex:0];
//            destinationController.flagColor=YES;
//        }
//        else
//        {
//            destinationController.flagColor=NO;
//        }
//        
//    }
    
//    if (_clarityArray.count>=2) {
//        
//        
//        destinationController.strClarityfrom=[_clarityArray objectAtIndex:0];
//        destinationController.strClarityto=[_clarityArray objectAtIndex:1];
//    }
//    else
//    {
//        
//        strClarityfrom=@"";
//        strClarityto=@"";
//        
//        destinationController.strClarityfrom=strClarityfrom;
//        destinationController.strClarityto=strClarityto;
//
//        if (_clarityArray.count == 1) {
//            
//            destinationController.strClarityfrom=[_clarityArray objectAtIndex:0];
//            destinationController.flagClarity=YES;
//        }
//        else
//        {
//            destinationController.flagClarity=NO;
//        }
//
//        
//    }
    
//    if (_polishArray.count>=2) {
//        
//        
//        destinationController.strPolishfrom=[_polishArray objectAtIndex:0];
//        destinationController.strPolishto=[_polishArray objectAtIndex:1];
//
//    }
//    else
//    {
//        
//        strPolishfrom=@"";
//        strPolishto=@"";
//        
//        destinationController.strPolishfrom=strPolishfrom;
//        destinationController.strPolishto=strPolishto;
//    
//        if (_polishArray.count == 1) {
//            
//            destinationController.strPolishfrom=[_polishArray objectAtIndex:0];
//            destinationController.flagPolish=YES;
//        }
//        else
//        {
//            destinationController.flagPolish=NO;
//        }
//        
//    }
    

        
    
    
    /*
    if (_txtPriceFrom.text.length == 0 || _txtPriceTo.text.length == 0)
    {
        flag=2;
        
        destinationController.strCaretfrom=@"";
        destinationController.strCaretTo=@"";
    }
    else
    {
         destinationController.strCaretfrom=[NSString stringWithFormat:@"%@",pricePerCaratFrom];
        destinationController.strCaretTo=[NSString stringWithFormat:@"%@",pricePerCaratTo];
    }
     
     */
    
    
        if (_txtPriceFrom.text.length == 0 || _txtPriceTo.text.length == 0)
        {
          flag=1;
        
          destinationController.strCaretfrom=@"";
         destinationController.strCaretTo=@"";
        }
        else
        {
         destinationController.strCaretfrom=[NSString stringWithFormat:@"%@",pricePerCaratFrom];
         destinationController.strCaretTo=[NSString stringWithFormat:@"%@",pricePerCaratTo];
        }

        if (_txtPriceFrom.text.length == 0 || _txtPriceTo.text.length == 0)
        {
            flag=2;
            
            destinationController.strDiscountfrom=@"";
            destinationController.strDiscountto=@"";
        }
        else
        {
            destinationController.strDiscountfrom=[NSString stringWithFormat:@"%@",discountFrom];
            destinationController.strDiscountto=[NSString stringWithFormat:@"%@",discountTo];
        }
        
        if (_txtPriceFrom.text.length == 0 || _txtPriceTo.text.length == 0)
        {
        
          destinationController.strTotalfrom=@"";
          destinationController.strTotalto=@"";
            
        }
        else
        {
            destinationController.strTotalfrom=[NSString stringWithFormat:@"%@",totalFrom];
            destinationController.strTotalto=[NSString stringWithFormat:@"%@",totalTo];
        }

 
//    destinationController.strSellerName=_txtSearchBySeller.text;
//    
//    destinationController.strLocation=_txtLocation.text;
//    
    
//    if (_symmetryArray.count>=2) {
//        
//        
//        destinationController.strSymmertyfrom=[_symmetryArray objectAtIndex:0];
//        destinationController.strSymmertyto=[_symmetryArray objectAtIndex:1];
//  
//        
//    }
//    else
//    {
//       
//        strSymmertyfrom=@"";
//        strSymmertyto=@"";
//        
//        destinationController.strSymmertyfrom=strSymmertyfrom;
//        destinationController.strSymmertyto=strSymmertyto;
//  
//        if (_symmetryArray.count == 1) {
//            destinationController.strSymmertyfrom=[_symmetryArray objectAtIndex:0];
//            destinationController.flagSymmetry=YES;
//        }
//        else
//        {
//            destinationController.flagSymmetry=NO;
//        }
//
//    }
    
//    
//    if (_fluorescentArray.count>=2) {
//        
//        
//        
//        destinationController.strFluorescentfrom=[_fluorescentArray objectAtIndex:0];
//        destinationController.strFluorescentto=[_fluorescentArray objectAtIndex:1];
// 
//    }
//    else
//    {
//       
//        strFluorescentfrom=@"";
//        strFluorescentto=@"";
//        
//        destinationController.strFluorescentfrom=strFluorescentfrom;
//        destinationController.strFluorescentto=strFluorescentto;
//        
//        if (_fluorescentArray.count == 1) {
//            
//            destinationController.strFluorescentfrom=[_fluorescentArray objectAtIndex:0];
//            destinationController.flagFluorescent=YES;
//        }
//        else
//        {
//            destinationController.flagFluorescent=NO;
//        }
//        
//    }
//    
//    if (_cutArray.count>=2) {
//        
//        
//        
//        destinationController.strCutFrom=[_cutArray objectAtIndex:0];
//        destinationController.strCutTo=[_cutArray objectAtIndex:1];
//        
//    }
//    else
//    {
//        
//        strFluorescentfrom=@"";
//        strFluorescentto=@"";
//        
//        destinationController.strCutFrom=strFluorescentfrom;
//        destinationController.strCutTo=strFluorescentto;
//        
//        if (_cutArray.count == 1) {
//            
//            destinationController.strCutFrom=[_cutArray objectAtIndex:0];
//            destinationController.flagCut=YES;
//        }
//        else
//        {
//            destinationController.flagCut=NO;
//        }
//        
//    }
    
    [self.navigationController pushViewController:destinationController animated:YES];
    
}

#pragma mark - IBAction For Shapes
- (IBAction)btnRoundClicked:(id)sender {
    
    NSString *shapeName;
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnRound) {
            //[_btnOval setSelected:YES];
            
            if ( [language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Round";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Yuvarlak";
            }
            
           // [self showStatus:@"Deselected" timeout:0.1];
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnRound) {
            
            
          //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Round";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Yuvarlak";
            }

            
            [_ShapeArray addObject:shapeName];
            
           // [self showToastShape:Round];
            
            NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}

- (IBAction)btnEmeraldClicked:(id)sender {
    
    //    sender.selected=!sender.selected;
     NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEmerald) {
          //  [_btnOval setSelected:YES];
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Emerald";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Emerald";
            }
            
           
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEmerald) {
           
            
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Emerald";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Emerald";
            }

            
            //[_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
            
           // [self showToastShape:Emerald];
            NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}
- (IBAction)btnPearClicked:(id)sender {

    //    sender.selected=!sender.selected;
    
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnPear) {
            //[_btnOval setSelected:YES];
            
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                 shapeName=@"Pear";
            }
            else
            {
                Lid=@"2";
                 shapeName=@"Damla";
            }
            
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnPear) {
            
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Pear";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Damla";
            }
            
            [_ShapeArray addObject:shapeName];
            
          /// [self showToastShape:Pear];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}
- (IBAction)btnPrincessClicked:(id)sender {

    //    sender.selected=!sender.selected;
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnPrincess) {
          //  [_btnOval setSelected:YES];
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Princess";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Prenses";
            }
            
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnPrincess) {
            
            if ([language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Princess";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Prenses";
            }
          
            
          //  [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
          //  [self showToastShape:Princess];
        }
        
    }
    
}
- (IBAction)btnOvalClicked:(id)sender {

    //    sender.selected=!sender.selected;
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnOval) {
            
            if ( [language isEqualToString:@"en-US"]||[language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Oval";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Oval";
            }
            //[_btnRound setSelected:YES];
            
            
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnOval) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Oval";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Oval";
            }
         
            
           // [_btnRound setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
          // [self showToastShape:Oval];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}
- (IBAction)btnCushionClicked:(id)sender {
    //    sender.selected=!sender.selected;
    
      NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnCushion) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Cushion";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Cushion";
            }
          //  [_btnOval setSelected:YES];
            
           
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        
        [sender setSelected:YES];
        
        if (sender == _btnCushion) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Cushion";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Cushion";
            }
          
           // [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
           // [self showToastShape:Cushion];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}


- (IBAction)btnCusModClicked:(id)sender {

    //    sender.selected=!sender.selected;
    
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnCusMod) {
            //[_btnOval setSelected:YES];
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Asscher";
                
            }
            else
            {
                Lid=@"2";
                shapeName=@"Asscher";
            }
            
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnCusMod) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Asscher";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Asscher";
            }
            
            
           // [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
          // [self showToastShape:Round];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}

- (IBAction)btnHeartClicked:(id)sender {
    //    sender.selected=!sender.selected;
     NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnHeart) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Heart";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Kalp";
            }
           // [_btnOval setSelected:YES];
            
           
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnHeart) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Heart";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Kalp";
            }
            
            
         //   [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
         //  [self showToastShape:Heart];
            
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}



- (IBAction)btnMarquiseClicked:(id)sender {

//    sender.selected=!sender.selected;
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnMarquise)
        {
           // [_btnOval setSelected:YES];
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Marquise";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Markiz";
            }
          
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnMarquise)
        {
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Marquise";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Markiz";
            }
            
          //  [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
          // [self showToastShape:Round];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}
- (IBAction)btnRadiantClicked:(id)sender
{

    //    sender.selected=!sender.selected;
    NSString *shapeName;
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnRadiant) {
           // [_btnOval setSelected:YES];
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Radiant";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Radyan";
            }
            
            
            [_ShapeArray removeObject:shapeName];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnRadiant) {
            
            if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
            {
                
                Lid=@"1";
                shapeName=@"Radiant";
            }
            else
            {
                Lid=@"2";
                shapeName=@"Radyan";
            }
            
            
          //  [_btnOval setSelected:NO];
            
            [_ShapeArray addObject:shapeName];
            
          //[self showToastShape:Radiant];
              NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }
    
}

//- (IBAction)btnShapeMoreClicked:(id)sender {
//    
//    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
//}
//
//- (IBAction)btnColorMoreClicked:(id)sender {
//    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
//}
//
//- (IBAction)btnLabMoreClicked:(id)sender {
//    [[KGModal sharedInstance]showWithContentView:_tblVwMore andAnimated:YES];
//}



#pragma mark - IBAction For Color


- (IBAction)btnDClicked:(UIButton *)sender
{

    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnDColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"D";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
        
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnDColor) {
            NSString *strColor=@"D";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
         //   [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}


- (IBAction)btnHClicked:(UIButton *)sender {

    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnHColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"H";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnHColor) {
            NSString *strColor=@"H";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
          //  [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}

- (IBAction)btnFClicked:(UIButton *)sender {
  
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"F";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFColor) {
            NSString *strColor=@"F";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
           // [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
}
- (IBAction)btnGclicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnGColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"G";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnGColor) {
            NSString *strColor=@"G";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
         //   [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}


- (IBAction)btnIClicked:(UIButton *)sender {
   
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnIColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"I";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnIColor) {
            NSString *strColor=@"I";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
          //  [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}

- (IBAction)btnJClicked:(UIButton *)sender {

    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnJColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"J";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnJColor) {
            NSString *strColor=@"J";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
         //   [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}

- (IBAction)btnKClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnKColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"K";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnKColor) {
            NSString *strColor=@"K";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
          //  [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
}

- (IBAction)btnLClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnLColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"L";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnLColor) {
            NSString *strColor=@"L";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
         //   [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}
- (IBAction)btnMClicked:(UIButton *)sender {

    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnMColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"M";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnMColor) {
            NSString *strColor=@"M";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
         //   [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}



- (IBAction)btnEClicked:(UIButton *)sender {

    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEColor) {
            //[_btnOval setSelected:YES];
            
            NSString *strColor=@"E";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_colorArray removeObject:strColor];
            NSLog(@"Color Array=%@",_colorArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEColor) {
            NSString *strColor=@"E";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_colorArray addObject:strColor];
            
           // [self showToastShape:strColor];
            
            NSLog(@"Color Array=%@",_colorArray);
        }
        
    }
    
}

#pragma mark - Action For Clartiy
- (IBAction)btnFLClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFLCLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"FL";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFLCLarity) {
            NSString *strClarity=@"FL";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}


- (IBAction)btnILClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnILCLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"IF";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnILCLarity) {
            NSString *strClarity=@"IF";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
         //   [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}
- (IBAction)btnVVS1ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVVS1CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"VVS1";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVVS1CLarity) {
            NSString *strClarity=@"VVS1";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
           // [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}

- (IBAction)btnVVS2ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVVS2CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"VVS2";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVVS2CLarity) {
            NSString *strClarity=@"VVS2";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}
- (IBAction)btnVS1ClarityClicked:(UIButton *)sender {

    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVS1CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"VS1";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVS1CLarity) {
            NSString *strClarity=@"VS1";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Shape Array=%@",_clarityArray);
        }
        
    }
    
}

- (IBAction)btnVS2ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVS2CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"VS2";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVS2CLarity) {
            NSString *strClarity=@"VS2";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}

- (IBAction)btnSI1ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnSI1CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"SI1";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnSI1CLarity) {
            NSString *strClarity=@"SI1";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
           // [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}

- (IBAction)btnSI2ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnSI2CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"SI2";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnSI2CLarity) {
            NSString *strClarity=@"SI2";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
        //    [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }

    
}


- (IBAction)btnSI3ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnSI3CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"SI3";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnSI3CLarity) {
            NSString *strClarity=@"SI3";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }


}

- (IBAction)btnI1ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnI1CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"I1";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnI1CLarity) {
            NSString *strClarity=@"I1";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }

    
}
- (IBAction)btnI2ClarityClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnI2CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"I2";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnI2CLarity) {
            NSString *strClarity=@"I2";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
          //  [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}

- (IBAction)btnI3ClarityClicked:(UIButton *)sender {

    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnI3CLarity) {
            //[_btnOval setSelected:YES];
            
            NSString *strClarity=@"I3";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_clarityArray removeObject:strClarity];
            NSLog(@"Clarity Array=%@",_clarityArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnI3CLarity) {
            NSString *strClarity=@"I3";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_clarityArray addObject:strClarity];
            
           // [self showToastShape:strClarity];
            
            NSLog(@"Clarity Array=%@",_clarityArray);
        }
        
    }
    
}



#pragma mark - IBAction For Cut
- (IBAction)btnICutClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnICut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"I";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnICut) {
            NSString *strCut=@"I";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }


}

- (IBAction)btnEXCutClicked:(UIButton *)sender {

    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEXCut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"Ex";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEXCut) {
            NSString *strCut=@"Ex";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }

}

- (IBAction)btnVGCutClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVGCut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"VG";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVGCut) {
            NSString *strCut=@"VG";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
         //   [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }

}

- (IBAction)btnGCutClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnGCut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"G";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnGCut) {
            NSString *strCut=@"G";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }

    
}

- (IBAction)btnFCutClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFCut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"F";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFCut) {
            NSString *strCut=@"F";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }

    
}
- (IBAction)btnPCutClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnPCut) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"P";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_cutArray removeObject:strCut];
            NSLog(@"Cut Array=%@",_cutArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnPCut) {
            NSString *strCut=@"P";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_cutArray addObject:strCut];
            
           // [self showToastShape:strCut];
            
            NSLog(@"Cut Array=%@",_cutArray);
        }
        
    }

}

#pragma mark - IBAction For Polish
- (IBAction)btnIPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnIPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strPolish=@"I";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strPolish];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnIPolish) {
            NSString *strPolish=@"I";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strPolish];
            
          //  [self showToastShape:strPolish];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }

    
}


- (IBAction)btnEXPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEXPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strPolish=@"Ex";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strPolish];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEXPolish) {
            NSString *strPolish=@"Ex";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strPolish];
            
           // [self showToastShape:strPolish];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }

    
    
    
}

- (IBAction)btnVGPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVGPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strPolish=@"VG";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strPolish];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVGPolish) {
            NSString *strPolish=@"VG";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strPolish];
            
          //  [self showToastShape:strPolish];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }
    
}

- (IBAction)btnGPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnGPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"G";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strCut];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnGPolish) {
            NSString *strCut=@"G";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strCut];
            
        //    [self showToastShape:strCut];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }
    
}

- (IBAction)btnFPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"F";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strCut];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFPolish) {
            NSString *strCut=@"F";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strCut];
            
         //   [self showToastShape:strCut];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }
    
}

- (IBAction)btnPPolishClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnPPolish) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"P";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_polishArray removeObject:strCut];
            NSLog(@"Polish Array=%@",_polishArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnPPolish) {
            NSString *strCut=@"P";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_polishArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Polish Array=%@",_polishArray);
        }
        
    }
    
}

#pragma mark - IBAction For Symmetry

- (IBAction)btnISymmetryClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnISymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"I";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnISymmetry) {
            NSString *strCut=@"I";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
           // [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }

    
}

- (IBAction)btnEXSymmetryClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEXSymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"Ex";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEXSymmetry) {
            NSString *strCut=@"Ex";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
           // [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }

    
    
}

- (IBAction)btnVGSymmetryClicked:(UIButton *)sender {
   
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVGSymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"VG";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVGSymmetry) {
            NSString *strCut=@"VG";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }
    
}

- (IBAction)btnGSymmetryClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnGSymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"G";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnGSymmetry) {
            NSString *strCut=@"G";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }

    
}

- (IBAction)btnFSymmetryClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFSymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"F";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFSymmetry) {
            NSString *strCut=@"F";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }

    
}

- (IBAction)btnPSymmetryClicked:(UIButton *)sender {
  
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnPSymmetry) {
            //[_btnOval setSelected:YES];
            
            NSString *strCut=@"P";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_symmetryArray removeObject:strCut];
            NSLog(@"Symmetry Array=%@",_symmetryArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnPSymmetry) {
            NSString *strCut=@"P";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_symmetryArray addObject:strCut];
            
          //  [self showToastShape:strCut];
            
            NSLog(@"Symmetry Array=%@",_symmetryArray);
        }
        
    }

    
}

#pragma mark - IBAction For Lab

- (IBAction)btnGIALabClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnGIALab) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"GIA";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_LabArray removeObject:strLab];
            NSLog(@"Lab Array=%@",_LabArray);
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnGIALab) {
            NSString *strLab=@"GIA";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_LabArray addObject:strLab];
            
         //   [self showToastShape:strLab];
            
            NSLog(@"Lab Array=%@",_LabArray);
        }
        
    }
    
    
}

- (IBAction)btnHRDLabClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnHRDLab) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"HRD";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_LabArray removeObject:strLab];
            NSLog(@"Lab Array=%@",_LabArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnHRDLab) {
            NSString *strLab=@"HRD";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_LabArray addObject:strLab];
            
         //   [self showToastShape:strLab];
            
            NSLog(@"Lab Array=%@",_LabArray);
        }
        
    }

    
}


- (IBAction)btnIGLLabClicked:(id)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnIGLLab) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"IGI";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_LabArray removeObject:strLab];
            NSLog(@"Lab Array=%@",_LabArray);
            
            
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnIGLLab) {
            NSString *strLab=@"IGI";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_LabArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Lab Array=%@",_LabArray);
        }
        
    }


    
    
}

- (IBAction)btnEGLLabClicked:(id)sender {

    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnEGLLab) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"EGL";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_LabArray removeObject:strLab];
            NSLog(@"Lab Array=%@",_LabArray);
        
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnEGLLab) {
            NSString *strLab=@"EGL";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_LabArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Lab Array=%@",_LabArray);
        }
        
    }


    
}

- (IBAction)btnAGSLabClicked:(id)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnAGSLab) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"AGS";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_LabArray removeObject:strLab];
            NSLog(@"Lab Array=%@",_LabArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnAGSLab) {
            NSString *strLab=@"AGS";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_LabArray addObject:strLab];
            
         //   [self showToastShape:strLab];
            
            NSLog(@"Lab Array=%@",_LabArray);
        }
        
    }

    
    
}

#pragma mark - IBAction For Fluorescent

- (IBAction)btnNFluorescentClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnNFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"N";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnNFluorescent) {
            NSString *strLab=@"N";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
           // [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }
    
}

- (IBAction)btnVSLFluorescentClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVSLFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"VSL";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVSLFluorescent) {
            NSString *strLab=@"VSL";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }

}

- (IBAction)btnFFluorescentClicked:(UIButton *)sender {
   
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnFFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"F";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnFFluorescent) {
            NSString *strLab=@"F";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
           // [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }
}

- (IBAction)btnMFluorescentClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnMFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"M";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
  }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnMFluorescent) {
            NSString *strLab=@"M";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }

}

- (IBAction)btnSBFluorescentClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnSBFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"SB";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnSBFluorescent) {
            NSString *strLab=@"SB";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }

    
}

- (IBAction)btnVSTBFluorescentClicked:(UIButton *)sender {
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
        if (sender == _btnVSTBFluorescent) {
            //[_btnOval setSelected:YES];
            
            NSString *strLab=@"VSTB";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_fluorescentArray removeObject:strLab];
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
            
            
        }
        
    }
    
    else
    {
        [sender setSelected:YES];
        
        if (sender == _btnVSTBFluorescent) {
            NSString *strLab=@"VSTB";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_fluorescentArray addObject:strLab];
            
          //  [self showToastShape:strLab];
            
            NSLog(@"Fluorescent Array=%@",_fluorescentArray);
        }
        
    }
    
}

#pragma mark - IBAction For Price

- (IBAction)btnCTPriceClicked:(UIButton *)sender {
    
    
    _txtPriceFrom.text=@"";
    _txtPriceTo.text=@"";
    
    flag=1;
    NSLog(@"CTPriceClicked");
    
    //Selected
    _btnCTPrice.backgroundColor=[UIColor darkGrayColor];
    [_btnCTPrice setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnDiscountPrice.backgroundColor=[UIColor whiteColor];
    [_btnDiscountPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    _btnTotalPrice.backgroundColor=[UIColor whiteColor];
    [_btnTotalPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
//    _strCaretfrom=_txtPriceFrom.text;
//    _strCaretTo=_txtPriceto.text;
//    
//    _txtPriceFrom.text=@"";
//    _txtPriceto.text=@"";
    
    
}

- (IBAction)btnDiscountPriceClicked:(UIButton *)sender {
    
    _txtPriceFrom.text=@"";
    _txtPriceTo.text=@"";
    
    flag=2;
    NSLog(@"DicountCLicked");
    
    
    //Selected
    _btnDiscountPrice.backgroundColor=[UIColor darkGrayColor];
    [_btnDiscountPrice setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnCTPrice.backgroundColor=[UIColor whiteColor];
    [_btnCTPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    _btnTotalPrice.backgroundColor=[UIColor whiteColor];
    [_btnTotalPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
//    
//    _strDiscountfrom=_txtPriceFrom.text;
//    _strDiscountto=_txtPriceto.text;
//
////    _txtPriceFrom.text=@"";
////    _txtPriceto.text=@"";
    
}

- (IBAction)btnTotalPriceClicked:(UIButton *)sender {
    flag=3;
    
    _txtPriceFrom.text=@"";
    _txtPriceTo.text=@"";
    
    NSLog(@"TotalPriceClicked");
    
    
    
    //Selected
    _btnTotalPrice.backgroundColor=[UIColor darkGrayColor];
    [_btnTotalPrice setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    
    //Not selected
    _btnCTPrice.backgroundColor=[UIColor whiteColor];
    [_btnCTPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    _btnDiscountPrice.backgroundColor=[UIColor whiteColor];
    [_btnDiscountPrice setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    

//    _strTotalfrom=_txtPriceFrom.text;
//    _strTotalto=_txtPriceto.text;
//    _txtPriceFrom.text=@"";
//    _txtPriceto.text=@"";
    
}


#pragma mark - IBAction For PopupView

- (IBAction)btnPopupViewCutClicked:(id)sender {
    
    [[KGModal sharedInstance] showWithContentView:_popUpViewCutPolishSymmetry];
    
}

- (IBAction)btnPopupViewPolishClicked:(id)sender {
    
    [[KGModal sharedInstance] showWithContentView:_popUpViewCutPolishSymmetry];
}


- (IBAction)btnPopupViewFluorescentClicked:(id)sender {
    
    [[KGModal sharedInstance] showWithContentView:_popUpViewFluorescent];
}
- (IBAction)btnPopupViewSymmetryClicked:(id)sender {
    
     [[KGModal sharedInstance] showWithContentView:_popUpViewCutPolishSymmetry];
    
}
#pragma mark UITextFieldDelegate


-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField==_txtPriceFrom || textField==_txtPriceTo)
    {
        
        if (flag==1)
        {
            
      //    _strCaretfrom=_txtPriceFrom.text;
        //   _strCaretTo=_txtPriceTo.text;
            _strDiscountfrom=@"";
            _strDiscountto=@"";
            _strTotalfrom=@"";
            _strTotalto=@"";

            
        }
        else if (flag==2)
        {
            NSLog(@"Discount");
            _strDiscountfrom=_txtPriceFrom.text;
            _strDiscountto=_txtPriceTo.text;
            _strTotalfrom=@"";
            _strTotalto=@"";
            _strCaretfrom=@"";
            _strCaretTo=@"";
            
        }
        else
        {
            NSLog(@"Total");
            
            _strTotalfrom=_txtPriceFrom.text;
            _strTotalto=_txtPriceTo.text;
            _strDiscountfrom=@"";
            _strDiscountto=@"";
            _strCaretfrom=@"";
            _strCaretTo=@"";

            
        }
    }
}
- (void)showStatus:(NSString *)message timeout:(double)timeout {
    
    statusAlert = [[UIAlertView alloc] initWithTitle:nil
                                             message:message
                                            delegate:nil
                                   cancelButtonTitle:nil
                                   otherButtonTitles:nil];
    [statusAlert show];
    [NSTimer scheduledTimerWithTimeInterval:timeout
                                     target:self
                                   selector:@selector(timerExpired:)
                                   userInfo:nil
                                    repeats:NO];
}

- (void)timerExpired:(NSTimer *)timer {
    [statusAlert dismissWithClickedButtonIndex:0 animated:YES];
}
- (IBAction)btnAdvancedSearchCicked:(id)sender {
   
//   _btnAdvancedSearch.hidden=NO;
//   _btnAdvancedSearchConstraint.constant=0.1f;

    
    _UIViewForTesting.hidden=NO;
    _UIviewTestingConstraintHeight.constant=555.0f;
    [UIView animateWithDuration:0.3 animations:^{
        
         _inerViewHeight.constant=_inerViewHeight.constant+520.0f;
       
    }];
    
    _btnAdvancedSearch.userInteractionEnabled=false;

    _btn3XOutle.userInteractionEnabled=true;
    _btnEXOutlet.userInteractionEnabled=true;
    _btnVGPlusOutlet.userInteractionEnabled=true;
    _btnVGMinusOutlet.userInteractionEnabled=true;

}


- (IBAction)btnLabMoreClicked:(id)sender {
    //flag2=2;
    [[KGModal sharedInstance] showWithContentView:_UIViewMoreLab];
    [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];
    

}

- (IBAction)btnColorMoreClicked:(id)sender {
    //flag2=3;
   [[KGModal sharedInstance] showWithContentView:_UIviewMoreColor];
   [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];

    
}

- (IBAction)btnShapeMoreClicked:(id)sender {
    //flag2=1;
    
    [[KGModal sharedInstance] showWithContentView:_UIViewMoreShape];
    [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];

  
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - MorePopup
- (IBAction)btnMoreLabClicked:(id)sender {
    
      [[KGModal sharedInstance] hide];
}
- (IBAction)btnOKColorClicked:(id)sender {
    [[KGModal sharedInstance] hide];
    
}
- (IBAction)btnOKShapeClicked:(id)sender {
    [[KGModal sharedInstance] hide];
}

-(void)btnShapeClicked:(UIButton *)button
{
 
    NSLog(@"Button Clicked:");
 
//    [button setImage:[UIImage imageNamed:@"Pear_Black"] forState:UIControlStateNormal];
//      [button setImage:[UIImage imageNamed:@"pear_blue"] forState:UIControlStateSelected];
//
//    [button setImage:[UIImage imageNamed:@"Round_Black"] forState:UIControlStateNormal];
    
      NSLog(@"indexPath =%@",selectedIndexPath);
    
      [button setImage:[UIImage imageNamed:@"round_blue"] forState:UIControlStateSelected];
    
    
    if ([button isSelected]) {
        [button setSelected:NO];
        
        if (button == _btnRound) {
            //[_btnOval setSelected:YES];
            
            NSString *Round=@"Round";
            // [self showStatus:@"Deselected" timeout:0.1];
            
            [_ShapeArray removeObject:Round];
            NSLog(@"Shape Array=%@",_ShapeArray);
            
        }
        
    }
    else
    {
        [button setSelected:YES];
        
        if (button == _btnRound) {
            NSString *Round=@"Round";
            
            //[self showStatus:@"Selected" timeout:0.1];
            
            //[_btnOval setSelected:NO];
            
            [_ShapeArray addObject:Round];
            NSLog(@"Shape Array=%@",_ShapeArray);
        }
        
    }

}

-(void)showToast:(NSString *)msg andArray:(NSMutableArray *)array andCurretText:(NSString *)str
{
    @try
    {
      //  [NSString stringWithFormat:@"%@ to %@ selected",array[0],array[1]];
        
        [self.parentViewController.view makeToast:[NSString stringWithFormat:@"%@ %@ %@ %@",array[0],NSLocalizedString(@"TO", @"TO"),array[1],NSLocalizedString(@"SELECTED", @"SELECTED")] duration:1.0 position:CSToastPositionCenter];

    } @catch (NSException *exception)
    {
    }
}


-(void)showToastShape:(NSString *)msg
{
     [self.parentViewController.view makeToast:msg duration:1.0 position:CSToastPositionCenter];
}
- (IBAction)txtCaratFromClicked:(id)sender {
    
    _txtCaratFrom.text=@"";
}

- (IBAction)txtCaratToClicked:(id)sender {
    
    _txtCaratTo.text=@"";
}
#pragma mark-Keypad done and Cancel button
//-(void)kepadDoneCancel
//{
//    _txtCaratTo.inputAccessoryView=[self doneAndCancelButton];
//    _txtCaratFrom.inputAccessoryView=[self doneAndCancelButton];
//}

//-(UIToolbar *)doneAndCancelButton
//{
//    UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
//    numberToolbar.barStyle = UIBarStyleBlackTranslucent;
//    numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelNumberPad)],
//                            [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
//                            [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)]];
//    [numberToolbar sizeToFit];
//    
//    return numberToolbar;
//    
//}

-(void)cancelNumberPad{
    
    //NSString *numberFromTheKeyboard = _perDayTxtFieldOutlet.text;
//    [_txtCaratTo resignFirstResponder];
//    [_txtCaratFrom resignFirstResponder];
}

-(void)doneWithNumberPad{
    
    //NSString *numberFromTheKeyboard = _perDayTxtFieldOutlet.text;
//    [_txtCaratTo resignFirstResponder];
//    [_txtCaratFrom resignFirstResponder];
}

- (IBAction)btn3XClicked:(UIButton *)sender {
    
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
          _strFinish =@"";
        
        _btnAdvancedSearch.userInteractionEnabled=false;
            _UIViewForTesting.hidden=NO;
            _UIviewTestingConstraintHeight.constant=555.0f;
            [UIView animateWithDuration:0.3 animations:^{
                
                _inerViewHeight.constant=_inerViewHeight.constant+520.0f;
                
            }];

           }
    
    else
    {
        [sender setSelected:YES];
        [_btnEXOutlet setSelected:NO];
        [_btnVGMinusOutlet setSelected:NO];
        [_btnVGPlusOutlet setSelected:NO];
        
            _UIViewForTesting.hidden=YES;
            _UIviewTestingConstraintHeight.constant=0.1f;
            
            //    for (UIView *subView in _UIViewForTesting.subviews) {
            //        subView.hidden = YES;
            //    }
        
    
           _strFinish =@"3X";
        
            NSLog(@"View constant :%f",_inerViewHeight.constant);
        
            [UIView animateWithDuration:0.3 animations:^{
                
                
                if (_inerViewHeight.constant!=1340)
                {
                     _inerViewHeight.constant=_inerViewHeight.constant-520.0f;
                }
            }];
    }

  
}

- (IBAction)btnEXClicked:(UIButton *)sender {
    
      if ([sender isSelected]) {
        [sender setSelected:NO];
        
           _UIViewForTesting.hidden=NO;
           _UIviewTestingConstraintHeight.constant=555.0f;
           _btnAdvancedSearch.userInteractionEnabled=false;
           _strFinish=@"";
            [UIView animateWithDuration:0.3 animations:^{
                
                _inerViewHeight.constant=_inerViewHeight.constant+520.0f;
                
            }];
        
    }
    
    else
    {
        [sender setSelected:YES];
        [_btnVGPlusOutlet setSelected:NO];
        [_btnVGMinusOutlet setSelected:NO];
        [_btn3XOutle setSelected:NO];
        
      
       
           _strFinish=@"EX+";
 
            _UIViewForTesting.hidden=YES;
            _UIviewTestingConstraintHeight.constant=0.1f;
            
            //    for (UIView *subView in _UIViewForTesting.subviews) {
            //        subView.hidden = YES;
            //    }
            
            [UIView animateWithDuration:0.3 animations:^{
                
                if (_inerViewHeight.constant!=1340)
                {
                    _inerViewHeight.constant=_inerViewHeight.constant-520.0f;
                }
                
            }];
        
        
    }

}

- (IBAction)btnVGPlusClicked:(UIButton *)sender {
    
    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
              _strFinish=@"";
              _UIViewForTesting.hidden=NO;
              _UIviewTestingConstraintHeight.constant=555.0f;
              _btnAdvancedSearch.userInteractionEnabled=false;
              [UIView animateWithDuration:0.3 animations:^{
                
                _inerViewHeight.constant=_inerViewHeight.constant+520.0f;
                
             }];
        
        
            NSLog(@"View constant :%f",_inerViewHeight.constant);
        
    }
    
    else
    {
        [sender setSelected:YES];
        [_btnEXOutlet setSelected:NO];
        [_btnVGMinusOutlet setSelected:NO];
        [_btn3XOutle setSelected:NO];
       
                     _strFinish=@"VG+";
            _UIViewForTesting.hidden=YES;
            _UIviewTestingConstraintHeight.constant=0.1f;
            
            //    for (UIView *subView in _UIViewForTesting.subviews) {
            //        subView.hidden = YES;
            //    }
            
            [UIView animateWithDuration:0.3 animations:^{
                
                if (_inerViewHeight.constant!=1340)
                {
                     _inerViewHeight.constant=_inerViewHeight.constant-520.0f;
                }
                
            }];
        
        }

}

- (IBAction)btnVGMinusClicked:(UIButton *)sender {

    
    if ([sender isSelected]) {
        [sender setSelected:NO];
        
            _strFinish=@"";
            _UIViewForTesting.hidden=NO;
            _UIviewTestingConstraintHeight.constant=555.0f;
           _btnAdvancedSearch.userInteractionEnabled=false;
            [UIView animateWithDuration:0.3 animations:^{
                
                _inerViewHeight.constant=_inerViewHeight.constant+520.0f;
                
            }];
        
        
    }
    
    else
    {
        
        [_btnEXOutlet setSelected:NO];
        [_btnVGPlusOutlet setSelected:NO];
        [_btn3XOutle setSelected:NO];
        [sender setSelected:YES];
      
    
           _strFinish=@"VG-";
        
            _UIViewForTesting.hidden=YES;
            _UIviewTestingConstraintHeight.constant=0.1f;
            
            //    for (UIView *subView in _UIViewForTesting.subviews) {
            //        subView.hidden = YES;
            //    }
            
            [UIView animateWithDuration:0.3 animations:^{
                
                if (_inerViewHeight.constant!=1340)
                {
                    _inerViewHeight.constant=_inerViewHeight.constant-520.0f;
                }
                
            }];
        
    }

}
@end
