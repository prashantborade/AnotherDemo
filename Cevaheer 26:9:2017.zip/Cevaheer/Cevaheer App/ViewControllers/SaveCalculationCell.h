//
//  SaveCalculationCell.h
//  Cevaheer App
//
//  Created by SMS on 13/02/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SaveCalculationCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *checkBoxOutlet;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UILabel *lblDicountValue;
@property (strong, nonatomic) IBOutlet UILabel *lblRapCtValue;
@property (strong, nonatomic) IBOutlet UILabel *lblTotal;
@property (strong, nonatomic) IBOutlet UILabel *lblCartClarityValue;

@end
