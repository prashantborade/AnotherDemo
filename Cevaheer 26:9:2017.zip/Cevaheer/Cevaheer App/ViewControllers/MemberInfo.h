//
//  MemberInfo.h
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MemberInfoModel.h"
@interface MemberInfo : UIViewController

#pragma mark - Outlets

@property (strong, nonatomic) IBOutlet UIImageView *memberInfoImgView;

@property (strong, nonatomic) IBOutlet UILabel *memberNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *membershipExpireDateLbl;
@property (strong, nonatomic) IBOutlet UILabel *compNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *locationLbl;
@property (strong, nonatomic) IBOutlet UILabel *compTypeLbl;
@property (strong, nonatomic) IBOutlet UILabel *ceveheerIDLbl;
@property (strong, nonatomic) IBOutlet UILabel *cityLbl;
@property (strong, nonatomic) IBOutlet UILabel *countryLbl;
@property (strong, nonatomic) IBOutlet UILabel *stateLbl;
@property (strong, nonatomic) IBOutlet UILabel *telephoneLbl;
@property (strong, nonatomic) IBOutlet UILabel *diamondsListedLbl;
@property (strong, nonatomic) IBOutlet UILabel *websiteLbl;
@property(nonatomic,strong) MemberInfoModel *memberInfo;


#pragma mark -Navigation Parameter
@property(nonatomic,strong) NSString *memberName;
@property(nonatomic,strong) NSString *membershipExpireDate;
@property(nonatomic,strong) NSString *compName;
@property(nonatomic,strong) NSString *location;
@property(nonatomic,strong) NSString *compType;
@property(nonatomic,strong) NSString *ceveheerID;
@property(nonatomic,strong) NSString *city;
@property(nonatomic,strong) NSString *country;
@property(nonatomic,strong) NSString *state;
@property(nonatomic,strong) NSString *telephone;
@property(nonatomic,strong) NSString *diamondsListed;
@property(nonatomic,strong) NSString *website;


- (IBAction)btnBackClicked:(id)sender;

@end
