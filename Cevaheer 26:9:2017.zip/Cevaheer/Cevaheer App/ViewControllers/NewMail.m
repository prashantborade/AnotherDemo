//
//  NewMail.m
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "NewMail.h"

@interface NewMail ()

@end

@implementation NewMail

- (void)viewDidLoad {
    [super viewDidLoad];
    
    arrOfEmails=[[NSMutableArray alloc] init];
    searchArray=[[NSMutableArray alloc] init];
    
    
    [self callServiceForBuyerEmails:GET_BUYERS_EMAIL paraeters:nil];
    [self callServiceForSuplierEmails:GET_SUPLIERS_EMAIL paraeters:nil];
    
    

    self.searchTable.backgroundColor =[UIColor clearColor];
    self.searchTable.hidden=YES;

    
    [self.txtTo addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];

    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
     strReciverID= [defaults valueForKey:@"EmailAddress"];
    [defaults synchronize];
    webserviceClass=[[WebserviceClass alloc]init];
    
    _textViewBody.text=NSLocalizedString(@"TEXTVIEW_MESSAGE", @"Type your message...");
    
    _txtTo.text=_sellerEmailID;
    
    if (_sellerEmailID) {
        NSString *Subject=[NSString stringWithFormat:@"ITEM DESCRIPTION-%@#-%@-%@-%@-%@",_strStockNumber,_strShape,_strCarat,_strColor,_strClarity];
      _txtSubject.text=Subject;
        
    }


}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textView:(UITextView *)txtView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        return YES;
    }
    
    [txtView resignFirstResponder];
    return NO;
    
}
-(void)textFieldDidChange:(UITextField *)textField
{
    self.searchTable.hidden = NO;
    
    searchTextString=textField.text;
    [self updateSearchArray:searchTextString];
}
//- (IBAction) textFieldDidChange: (UITextField*) textField
//{
//    [UIView animateWithDuration:0.1 animations:^{
//        [textField invalidateIntrinsicContentSize];
//    }];
//}
- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnSendClicked:(id)sender {
    
    if (![self validateEmailWithString:[_txtTo text]])
    {
        [self showMessage:NSLocalizedString(@"EMAIL", @"Please provide valid email !")];
       _txtTo.text= @"";
       [_txtTo becomeFirstResponder];
    }else if ([_textViewBody.text isEqualToString:@""]){
        
         [self showMessage:@"Type your message !"];
        [_textViewBody becomeFirstResponder];
    }
    else
    {
       [self newEmail];
    }

}

- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}

#pragma mark Webservice Methods
-(void)newEmail
{
    
    NSString *strRequest=SEND_MESSAGE;
    NSString *parameterString=[NSString stringWithFormat:@"SenderID=%@&ReceiverID=%@&MessageSubject=%@&MessageContent=%@",[NSString stringWithFormat:@"%@",strReciverID],[NSString stringWithFormat:@"%@",_txtTo.text],_txtSubject.text,_textViewBody.text];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
      NSUTF8StringEncoding];

    strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];

    

}
- (void)requestSucceeded:(NSString *)response
{
    self.view.userInteractionEnabled=YES;
    NSError *error;
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    self.view.userInteractionEnabled=YES;
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];

    if(json == nil)
    {
        // [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if (![Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];
        }
        else
        {
            [self showMessage];
            [self.navigationController popViewControllerAnimated:YES];
        
        }
        
    }
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"MSG_TITLE",@"Congratulations") message:NSLocalizedString(@"MSG",@"your message has been sent") delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"ok"),nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:3.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    [_textViewBody setText:@""];
  
}

#pragma Search Seller And Buyer Email
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(isFilter)
    {
        return [searchArray count];
    }
    else
        return  [arrOfEmails count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    self.searchTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    [cell.textLabel sizeToFit];
    cell.textLabel.font=[UIFont fontWithName:@"Arial" size:16];
    
    if(isFilter)
        
    {
        cell.textLabel.text=[searchArray objectAtIndex:indexPath.row];

    }
    else
    {
        cell.textLabel.text=[arrOfEmails objectAtIndex:indexPath.row];
    }
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(isFilter)
    {
        _txtTo.text=[searchArray objectAtIndex:indexPath.row];
        
    }
    else
    {
        _txtTo.text=[arrOfEmails objectAtIndex:indexPath.row];
    }
    
    _searchTable.hidden=YES;
}

-(void)updateSearchArray:(NSString *)searchText
{
    if(searchText.length==0)
    {
        isFilter=NO;
    }
    else{
        
        isFilter=YES;
        searchArray=[[NSMutableArray alloc]init];
        for(NSString *string in arrOfEmails){
            
            NSRange stringRange=[string rangeOfString:searchText options:NSCaseInsensitiveSearch];
            if(stringRange.location !=NSNotFound){
                
                [searchArray addObject:string];
            }
        }
        [self.searchTable reloadData];}
}

-(void)callServiceForBuyerEmails:(NSString *)completeURL paraeters:(NSString *)param
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
        
        //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:completeURL];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
        NSString *params = param;
        [urlRequest setHTTPMethod:@"GET"];
        [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
        [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
        [urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
        
        //Create task
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
            NSError* error1;
            NSDictionary *json1 = [NSJSONSerialization
                                   JSONObjectWithData:data options:kNilOptions error:&error1];
            
            NSDictionary *resultDict=[json1  valueForKey:@"Result"];
            
            NSArray *tableArray=[resultDict valueForKey:@"Table"];
            
            for (NSDictionary *result in tableArray) {
                
                NSString *strEmail=[result valueForKey:@"Email"];
                
                [arrOfEmails addObject:strEmail];
                
            }
            
        
        }];
        [dataTask resume];
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
}
-(void)callServiceForSuplierEmails:(NSString *)completeURL paraeters:(NSString *)param
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
        
        //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:completeURL];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
        NSString *params = param;
        [urlRequest setHTTPMethod:@"GET"];
        [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
        [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
        [urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
        
        //Create task
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
            NSError* error1;
            NSDictionary *json1 = [NSJSONSerialization
                                   JSONObjectWithData:data options:kNilOptions error:&error1];
            
            NSDictionary *resultDict=[json1  valueForKey:@"Result"];
            
            NSArray *tableArray=[resultDict valueForKey:@"Table"];
            
            for (NSDictionary *result in tableArray) {
                
                NSString *strEmail=[result valueForKey:@"Email"];
                
                [arrOfEmails addObject:strEmail];
                
            }
            
            
            
            
        }];
        [dataTask resume];
        
        
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
    
    [self.searchTable reloadData];
    
}


//- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
//    //  Make the textView visible in-case the keyboard has covered it
//    _textViewBody.text=@"";
//
//    return YES;
//}
//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
//
//    if([text isEqualToString:@"\n"]) {
//        [textView resignFirstResponder];
//        return NO;
//    }
//
//    return YES;
//}
@end
