//
//  SaveCalculation.h
//  Cevaheer App
//
//  Created by SMS on 13/02/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SaveCalculationCell.h"


@interface SaveCalculation : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *lblAvgPPCValue;
@property (strong, nonatomic) IBOutlet UILabel *lblTotalCarats;
@property (strong, nonatomic) IBOutlet UILabel *lblTotalPriceValue;
@property (strong, nonatomic) IBOutlet UIButton *btnMinus;
@property (strong, nonatomic) IBOutlet UILabel *lblDiscountValue;
@property (strong, nonatomic) IBOutlet UIButton *btnPlus;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;

- (IBAction)btnMinusClicked:(id)sender;
- (IBAction)btnPlusClicked:(id)sender;

- (IBAction)saveCalculationClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *tableViewSaveCalculation;
- (IBAction)btnCancelClicked:(id)sender;

@end
