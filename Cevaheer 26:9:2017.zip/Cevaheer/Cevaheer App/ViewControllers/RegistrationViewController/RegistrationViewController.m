//
//  RegistrationViewController.m
//  Cevaheer App

//  Created by   on 12/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.

#import "RegistrationViewController.h"

@interface RegistrationViewController ()

@end

@implementation RegistrationViewController
#pragma mark - Lifecycle
- (void)viewDidLoad {
  
    [super viewDidLoad];
    [self initializeView];
    [self setPaddingToTextField:_firstNameOutlet];
    [self setPaddingToTextField:_LastNameOutlet];
    
     [self setPaddingToTextField:_companyNameOutlet];
     [self setPaddingToTextField:_phoneOutlet];
     [self setPaddingToTextField:_emailOutlet];
     [self setPaddingToTextField:_passwordOutlet];
     [self setPaddingToTextField:_confirmPasswordOutlet];
    
     [_phoneOutlet setKeyboardType:UIKeyboardTypeNumberPad];
    
     flag=0;
//
//    NSAttributedString *titleString = [[NSAttributedString alloc] initWithString:_checkBoxOutlet.titleLabel.text attributes:@{NSUnderlineStyleAttributeName : @(NSUnderlineStyleSingle | NSUnderlinePatternSolid)}];
//    
//    //use the setAttributedTitle method
//    [_checkBoxOutlet setAttributedTitle:titleString forState:UIControlStateNormal];
    
//    THANK  YOU FOR CHOOSING CEVAHEER- 1oI-Y7-tdL
//    A CEVAHEER TEAM MEMBER WILL CONTACT YOU SOON... - wue-Uq-gC7
    
    // Do any additional setup after loading the view.
    
      self.screenName=@"Sign up";
   
    Lid=@"";
    language = [[NSLocale preferredLanguages] objectAtIndex:0];
    isFromCompanyType=NO;
    
    
    
    
 
    
//    
//    NSMutableArray *secondArray = [[NSMutableArray alloc]init];
//  
//    
//    
//    
//    NSArray * arrImage = [[NSArray alloc] init];
//    arrImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"apple.png"], nil];
//    
//    
//    
//    
//    
//     CGFloat f = 0;
//    
//    dropDown = [[NIDropDown alloc]showDropDown:_btnCompanyTypeOutlet :&f :nil :arrImage :@"down"];
//    dropDown.delegate = self;

    
      [_btnCompanyTypeOutlet setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateNormal];
    
}


-(void)initializeView
{
    self.upperImageViewOutlet.backgroundColor=[UIColor colorWithHexString:APP_GREY_COLOR];
    [_termAndConditionOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_accpetermAndConditionOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_registerBtnOutlet setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    [_btnLoginPopup setTitleColor:[UIColor colorWithHexString:APP_BLUE_COLOR] forState:UIControlStateNormal];
    
    _firstNameOutlet.layer.borderWidth=1.0F;
    _LastNameOutlet.layer.borderWidth=1.0F;
    
    _companyNameOutlet.layer.borderWidth=1.0F;
    _phoneOutlet.layer.borderWidth=1.0F;
    _emailOutlet.layer.borderWidth=1.0F;
    _passwordOutlet.layer.borderWidth=1.0F;
    _confirmPasswordOutlet.layer.borderWidth=1.0F;
    _registerBtnOutlet.layer.borderWidth=1.0F;
    _btnLoginPopup.layer.borderWidth=1.0F;
       _btnCompanyTypeOutlet.layer.borderWidth=1.0F;
    
    
    _firstNameOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _LastNameOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
    _companyNameOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _phoneOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _emailOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _passwordOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _confirmPasswordOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _registerBtnOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    _btnLoginPopup.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
    _btnCompanyTypeOutlet.layer.borderColor=[UIColor colorWithHexString:APP_BLUE_COLOR].CGColor;
    
    
    
    [_checkBoxOutlet setImage:[UIImage imageNamed:@"uncheck_color"]
                  forState:UIControlStateNormal];
    [_checkBoxOutlet setImage:[UIImage imageNamed:@"check_color"]
                  forState:UIControlStateSelected];
    [_checkBoxOutlet setImage:[UIImage imageNamed:@"check_color"]
                  forState:UIControlStateHighlighted];
    _checkBoxOutlet.adjustsImageWhenHighlighted=YES;
    
    [_checkBoxEmail setImage:[UIImage imageNamed:@"uncheck-box"]
                     forState:UIControlStateNormal];
    [_checkBoxEmail setImage:[UIImage imageNamed:@"check-box"]
                     forState:UIControlStateSelected];
    [_checkBoxEmail setImage:[UIImage imageNamed:@"check-box"]
                     forState:UIControlStateHighlighted];
    _checkBoxEmail.adjustsImageWhenHighlighted=YES;

    
    [_checkBoxSms setImage:[UIImage imageNamed:@"uncheck-box"]
                    forState:UIControlStateNormal];
    [_checkBoxSms setImage:[UIImage imageNamed:@"check-box"]
                    forState:UIControlStateSelected];
    [_checkBoxSms setImage:[UIImage imageNamed:@"check-box"]
                    forState:UIControlStateHighlighted];
    _checkBoxSms.adjustsImageWhenHighlighted=YES;

     webserviceClass=[[WebserviceClass alloc]init];
    
}
#pragma mark - IBActions
- (IBAction)termAndConditionAction:(id)sender
{
    
}

- (IBAction)acceptTermsAndConditionAction:(id)sender
{
    if(_checkBoxOutlet.isSelected)
    {
     [_checkBoxOutlet setSelected:NO];
    }else
    {
        [_checkBoxOutlet setSelected:YES];
        flag=1;
    }
}

- (IBAction)ConditionByEmail:(id)sender {
    
    if(_checkBoxEmail.isSelected)
    {
        [_checkBoxEmail setSelected:NO];
    }else
    {
        [_checkBoxEmail setSelected:YES];
    }

}

- (IBAction)ConditionBySms:(id)sender {
    
    if(_checkBoxSms.isSelected)
    {
        
        [_checkBoxSms setSelected:NO];
        
    }else
    {
        
        [_checkBoxSms setSelected:YES];
        
    }

}

- (IBAction)termAndConditionLink:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.cevaheer.com/en/termsandconditions"]];
    flag =1;
}

- (IBAction)registerBtnAction:(id)sender {
    
//    if ([_firstNameOutlet.text isEqualToString:@""])
//    {
//        
//        [self showMessage:NSLocalizedString(@"NAME",@"Please Enter your Name !")];
//    
//    } else if([_LastNameOutlet.text isEqualToString:@""])
//        
//    {
//        [self showMessage:NSLocalizedString(@"SURNAME",@"Please Enter your Surname !")];
//        
//    } else if ([_companyNameOutlet.text isEqualToString:@""])
//        
//    {
//         [self showMessage:NSLocalizedString(@"COMPANY_NAME",@"Please Enter companyName !")];
//        
//    }else
        if ([_emailOutlet.text isEqualToString:@""])
        
    {
           [self showMessage:NSLocalizedString(@"VALIDATE_EMAIL", @"Please Enter Valid User id !")];
            _emailOutlet.text= @"";
            [_emailOutlet becomeFirstResponder];
    }else if (_passwordOutlet.text.length <8)
        
    {
        [self showMessage:NSLocalizedString(@"PASSWORD",@"Please Enter your password !")];
    }else if (![_passwordOutlet.text isEqualToString:_confirmPasswordOutlet.text])
    {
        [self showMessage:NSLocalizedString(@"CONFIRM_PASSWORD",@"ConfirmPassword not matched with Password !")];
    } else if ([_phoneOutlet.text isEqualToString:@""])
        
    {
        [self showMessage:NSLocalizedString(@"BUSINESS_NUMBER",@"Please Enter a Valid Business number !")];
      
    }
    else
    {
        isFromCompanyType=NO;//_phoneOutlet
        if (flag ==1 )
        {
            [self.view resignFirstResponder];
            
            
            NSString *companyName,*companyType,*firstName,*lastName;
            
            
            if ([_firstNameOutlet.text isEqualToString:@""])
            {
                firstName=@"iOS";
            }else
            {
                firstName=_firstNameOutlet.text;
            }
            
            
            if ([_LastNameOutlet.text isEqualToString:@""])
            {
                lastName=@"iOS";
            }else
            {
                lastName=_LastNameOutlet.text;
            }
            
            if ([_companyNameOutlet.text isEqualToString:@""])
            {
                companyName=@"iOS";
            }else
            {
                companyName=_companyNameOutlet.text;
            }
            
            if ([_btnCompanyTypeOutlet.titleLabel.text isEqualToString:@"   Company Type"])
            {
                companyType=@"iOS";
            }else
            {
                companyType=_btnCompanyTypeOutlet.titleLabel.text;
            }
            
            // Action to be called on Submit button touch
            NSString *parameterString=[NSString stringWithFormat:@"FirstName=%@&LastName=%@&Email=%@&Password=%@&Phone=%@&Companyname=%@&companyType=%@",firstName,lastName,_emailOutlet.text,_passwordOutlet.text,_phoneOutlet.text,companyName,companyType];
            
            [webserviceClass callServcieUsingRequestAndPOST:SIGN_UP_URL :parameterString andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
            
            flag=0;
        }else
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:NSLocalizedString(@"CONFIRM_CONDITION", @"Please confirm the terms and conditions.") delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
        //  [self initializeAllField];
    }



}
-(void)initializeAllField
{
    _firstNameOutlet.text=@"";
    _LastNameOutlet.text=@"";
    _companyNameOutlet.text=@"";
    _passwordOutlet.text=@"";
    _emailOutlet.text=@"";
    _confirmPasswordOutlet.text=@"";
    
}
- (IBAction)btnLoginClicked:(id)sender
{
    LoginViewController *loginViewController=[[self storyboard]instantiateViewControllerWithIdentifier:@"LoginViewController"];
    
    [self.navigationController pushViewController:loginViewController animated:YES];
    
    [[KGModal sharedInstance] hide];
}

- (IBAction)btnOnRegisterClicked:(id)sender {
     LoginViewController *loginViewController=[[self storyboard]instantiateViewControllerWithIdentifier:@"LoginViewController"];
    
    [self.navigationController pushViewController:loginViewController animated:YES];
    
}

- (IBAction)btnCompanyType:(UIButton *)sender
{
    isFromCompanyType=YES;
    
    if ([language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@" en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"]) {
        
        Lid=@"2";
    }
    else
    {
        Lid=@"1";
    }
   
   // [_companyTypeArray removeAllObjects];
    // _pickerViewCompanyType.hidden=NO;
    [self getComapanyType];
    
}
- (BOOL)validatePhone:(NSString *)phoneNumber
{
    NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    
    return [phoneTest evaluateWithObject:phoneNumber];
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
  
    if (textField == _phoneOutlet)
    {
        if ([_phoneOutlet.text length] <10 )
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:NSLocalizedString(@"BUSINESS_NUMBER",@"Please Enter a Valid Business number !") delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
    }
    return YES;
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}

#pragma mark Webservice Methods

-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    NSLog(@"json === %@", json);
    
    if(json == nil)
    {
        //  [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        if (isFromCompanyType)
        {
            _companyTypeArray=[[NSMutableArray alloc]init];
            {
                NSError* error;
                json = [NSJSONSerialization
                        JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
                
                if(json == nil)
                {
                    // [constants_class showAlert:@"Error connecting server."];
                }
                else
                {
                    
                    Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
                    Message =[json objectForKey:@"Message"];
                    
                    if (![Statuscode isEqualToString:@"1"]) {
                        
                        //[self showMessage];
                        
                    }
                    else
                    {
                        if (![json objectForKey:@"Result"])
                        {
                           // [self showMessage];
                        }
                        else
                        {
                            
                            NSDictionary *subDict= [json objectForKey:@"Result"];
                            _jsonArrayCompanyType =[subDict objectForKey:@"Table"];
                            
                            for (NSDictionary *result in _jsonArrayCompanyType) {
                                
                                
                                if (![[result objectForKey:@"Type"] isEqualToString:@"null"])
                                {
                                    [_companyTypeArray addObject:[result objectForKey:@"Type"]];
                                }
                                
                            }
                            
                            NSMutableArray *secondArray = [[NSMutableArray alloc]init];
                            secondArray = [[NSMutableArray alloc]initWithArray:_companyTypeArray];
                            //    NSArray * arr1 = [[NSArray alloc] init];
                            //    arr1 = [NSArray arrayWithObjects:@"Hello 0", @"Hello 1", @"Hello 2", @"Hello 3", @"Hello 4", @"Hello 5", @"Hello 6", @"Hello 7", @"Hello 8", @"Hello 9",nil];
                            NSArray * arrImage = [[NSArray alloc] init];
                            arrImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], nil];
                            if(dropDown == nil) {
                                CGFloat f = 250;
                                dropDown = [[NIDropDown alloc]showDropDown:_btnCompanyTypeOutlet :&f :secondArray :arrImage :@"down"];
                                dropDown.delegate = self;
                            }
                            else {
                                [dropDown hideDropDown:self];
                                //[self rel];
                                dropDown=nil;
                            }
                            
                            //[_pickerViewCompanyType reloadAllComponents];
                        }
                    }
                    
                }
                
            }
            
        }else
        {
            
        
        
        JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithDictionary:json error:&error];
        if ([objJSONUtility.Statuscode isEqualToString:@"1"])
        {
            [[KGModal sharedInstance] showWithContentView:_popUpLoginView];
            [[KGModal sharedInstance] setCloseButtonType:KGModalCloseButtonTypeNone];


        }
        else
        {
            [webserviceClass showAlert:objJSONUtility.Message];
        }
            
      }
    }
    
}

-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
#pragma mark - TextFieldLeftPadding
-(void)setPaddingToTextField:(UITextField*)textField
{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}



-(void)getComapanyType
{
    
    NSString* parameterString=[NSString stringWithFormat:@"%@Lid=%@",GET_BUSSINESSTYPE,Lid];
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    NSLog(@"%@",parameterString);
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender
{
    // [self rel];
    NSLog(@"%@", _btnCompanyTypeOutlet.titleLabel.text);
    
    NSLog(@"Company is selected  %x",_btnCompanyTypeOutlet.selected);
    
    [_btnCompanyTypeOutlet setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    [_btnCompanyTypeOutlet setBackgroundImage:[UIImage imageNamed:@"dropdown"] forState:UIControlStateNormal];
    dropDown=nil;
}
@end
