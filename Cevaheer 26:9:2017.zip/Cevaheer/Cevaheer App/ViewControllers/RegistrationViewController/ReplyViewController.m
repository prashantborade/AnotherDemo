//
//  ReplyViewController.m
//  Cevaheer App
//
//  Created by Avion on 7/10/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "ReplyViewController.h"

@interface ReplyViewController ()

@end

@implementation ReplyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strReciverID= [defaults valueForKey:@"EmailAddress"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];
    webserviceClass=[[WebserviceClass alloc]init];
    
    _txtTo.text=_replyTOEmail;
    _txtSubject.text=@"";
    _txtTextViewBody.text=NSLocalizedString(@"REPLY_MSG_CONTENT",@"Reply your message...");
    
    _txtSubject.enablesReturnKeyAutomatically=NO;
    

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBackClicked:(id)sender {
    
     [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnSendClicked:(id)sender {
    
    if ([_txtTextViewBody.text isEqualToString:@""])
    {
       
        [self showMessage:@"Reply your message !"];
        [_txtTextViewBody becomeFirstResponder];
    }
    else
    {
        [self replyEmail];
    }

    
}

-(void)replyEmail
{
    
    NSString *strRequest=SEND_MESSAGE;
    NSString *parameterString=[NSString stringWithFormat:@"SenderID=%@&ReceiverID=%@&MessageSubject=%@&MessageContent=%@",[NSString stringWithFormat:@"%@",strReciverID],[NSString stringWithFormat:@"%@",_txtTo.text],_txtSubject.text,_txtTextViewBody.text];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];
    
    strRequest=[strRequest stringByAppendingString:encodedUrl];
    
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];

    NSLog(@"URL=%@",parameterString);
    
}

-(void)showMessage:(NSString *)msg
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:nil message:msg delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"Ok"),nil];
    [alertMsg show];
    
}

- (void)requestSucceeded:(NSString *)response
{
    self.view.userInteractionEnabled=YES;
    NSError *error;
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    self.view.userInteractionEnabled=YES;
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    if(json == nil)
    {
        // [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if (![Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];
        }
        else
        {
            [self showMessage];
            [self.navigationController popViewControllerAnimated:YES];
            
        }
        
    }
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"MSG_TITLE",@"Congratulations") message:NSLocalizedString(@"MSG",@"your message has been sent") delegate:self cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK",@"ok"),nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:3.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    [_txtTextViewBody setText:@""];
    
}
- (BOOL)textView:(UITextView *)txtView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        return YES;
    }
    
    [txtView resignFirstResponder];
    return NO;
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
@end
