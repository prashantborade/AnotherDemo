//
//  RegistrationViewController.h
//  Cevaheer App
//
//  Created by   on 12/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GAITrackedViewController.h"


@class WebserviceClass;


@interface RegistrationViewController : GAITrackedViewController<WebserviceProtocol>
{
    
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *language;
    NSString *Lid;
    
    NSString *Statuscode;
    NSString *Message;
    
    BOOL flag,isFromCompanyType;
    NIDropDown *dropDown;
}

@property(nonatomic,strong) NSMutableArray *jsonArrayCompanyType;
@property(nonatomic,strong) NSMutableArray *companyTypeArray;
#pragma  mark - IBOutletes

@property (strong, nonatomic) IBOutlet UITextField *firstNameOutlet;
@property (strong, nonatomic) IBOutlet UITextField *LastNameOutlet;

@property (strong, nonatomic) IBOutlet UITextField *companyNameOutlet;
@property (strong, nonatomic) IBOutlet UITextField *phoneOutlet;
@property (strong, nonatomic) IBOutlet UITextField *emailOutlet;
@property (strong, nonatomic) IBOutlet UITextField *passwordOutlet;
@property (strong, nonatomic) IBOutlet UITextField *confirmPasswordOutlet;
@property (strong, nonatomic) IBOutlet UIButton *termAndConditionOutlet;

@property (strong, nonatomic) IBOutlet UIButton *checkBoxOutlet;
@property (strong, nonatomic) IBOutlet UIButton *checkBoxEmail;
@property (strong, nonatomic) IBOutlet UIButton *checkBoxSms;



@property (strong, nonatomic) IBOutlet UIButton *accpetermAndConditionOutlet;
@property (strong, nonatomic) IBOutlet UIButton *registerBtnOutlet;

@property (strong, nonatomic) IBOutlet UIImageView *upperImageViewOutlet;

@property (strong, nonatomic) IBOutlet UIView *popUpLoginView;
@property (strong, nonatomic) IBOutlet UIButton *btnLoginPopup;
@property (weak, nonatomic) IBOutlet UIButton *btnCompanyTypeOutlet;

#pragma mark - IBAction
- (IBAction)termAndConditionAction:(id)sender;
- (IBAction)acceptTermsAndConditionAction:(id)sender;
- (IBAction)ConditionByEmail:(id)sender;
- (IBAction)ConditionBySms:(id)sender;

- (IBAction)termAndConditionLink:(id)sender;

- (IBAction)registerBtnAction:(id)sender;
- (IBAction)btnLoginClicked:(id)sender;
- (IBAction)btnOnRegisterClicked:(id)sender;
- (IBAction)btnCompanyType:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UILabel *lblDeepNote;



@end
