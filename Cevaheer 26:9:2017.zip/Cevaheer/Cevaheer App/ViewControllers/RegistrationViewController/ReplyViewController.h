//
//  ReplyViewController.h
//  Cevaheer App
//
//  Created by Avion on 7/10/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReplyViewController : UIViewController<WebserviceProtocol,MBProgressHUDDelegate>
{
    UIAlertView *alert;
    WebserviceClass *webserviceClass;
    NSDictionary *json;
    NSString *Statuscode;
    NSString *Message;

    NSString *strReciverID;
}
@property (strong, nonatomic) IBOutlet UITextField *txtTo;
@property (strong, nonatomic) IBOutlet UITextField *txtSubject;
@property (strong, nonatomic) IBOutlet UITextView *txtTextViewBody;
@property(nonatomic,strong) NSString *replyTOEmail;
- (IBAction)btnBackClicked:(id)sender;

- (IBAction)btnSendClicked:(id)sender;




@end
