//
//  FindPeopleSearchResult.m
//  Cevaheer App
//
//  Created by  on 9/27/16.

//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "FindPeopleSearchResult.h"
#import "WelcomeViewController.h"
#import "Constant.h"
@interface FindPeopleSearchResult ()
{
    NSString *urlString;
}
@end

@implementation FindPeopleSearchResult

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Lid=@"";
    language = [[NSLocale preferredLanguages] objectAtIndex:0];
     isFiltered = NO;
     flag=0;
    _btnReset.hidden=YES;
    _btnSearch.hidden=YES;
    _jsonArray=[[NSMutableArray alloc] init];
    _searchBar.delegate=self;
    _searchBar.enablesReturnKeyAutomatically=NO;
    webserviceClass=[[WebserviceClass alloc]init];
    
   // _searchBar.keyboardType=UIKeyboardTypeWebSearch;
    [self callServiceForBanerAd];
    
    [_searchBar setKeyboardType:UIKeyboardTypeWebSearch];
    [self findPeopleResult];
   
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (isFiltered) {
        
        return [filteredArray count];
    }
    else
    {
            return _jsonArray.count;
    }

    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"SearchCell";
    
    SearchCell *cell = (SearchCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[SearchCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    
    
   // cell.userInteractionEnabled=NO;
    
    if (!isFiltered){
        flag=0;
        
        NSLog(@"_jsonArray =%lu",(unsigned long)_jsonArray.count);
        
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    NSString *strCompanyName=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
    
    if (strCompanyName ==(id)[NSNull null] || [strCompanyName isEqualToString:@""] || strCompanyName==nil || [strCompanyName length]==0) {
        cell.comNameLbl.text=@"";
        
    }
    else
    {
        cell.comNameLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
    }
    
    NSString *strCity=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
    
    if (strCity ==(id)[NSNull null] || [strCity isEqualToString:@""] || strCity==nil || [strCity length]==0) {
         cell.locationLbl.text=@"";
        
    }
    else
    {
        cell.locationLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
    }
    
    
    NSString *strCavaheerID=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
    
    if (strCavaheerID ==(id)[NSNull null] || [strCavaheerID isEqualToString:@""] || strCavaheerID==nil || [strCavaheerID length]==0) {
        cell.cavaheerIDLbl.text=@"";
    }
    else
    {
          cell.cavaheerIDLbl.text=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
    }
    
    
    NSString *strCompanyType=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
    
    if (strCompanyType ==(id)[NSNull null] || [strCompanyType isEqualToString:@""] || strCompanyType==nil || [strCompanyType length]==0) {
        cell.compTypeLbl.text=@"";
        
    }
    else
    {
           cell.compTypeLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
    
    }
    
    NSString *strRating=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Rating"];
    
    if (strRating ==(id)[NSNull null] || [strRating isEqualToString:@""] || strRating==nil || [strRating length]==0) {
        cell.ratingLbl.text=@"";
        
        
    }
    else
    {
          cell.ratingLbl.text=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Rating"];
    }
    
     cell.StarRatingView.value=2;
        
    cell.StarRatingView.userInteractionEnabled=NO;
        
 //   [cell.ratingLbl setUserInteractionEnabled:NO];

        
     }else{
           flag=1;
         
         NSLog(@"filteredArray =%lu",(unsigned long)filteredArray.count);
         
         cell.selectionStyle=UITableViewCellSelectionStyleNone;
         
         NSString *strCompanyName=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
         
         if (strCompanyName ==(id)[NSNull null] || [strCompanyName isEqualToString:@""] || strCompanyName==nil || [strCompanyName length]==0) {
             cell.comNameLbl.text=@"";
             
         }
         else
         {
             cell.comNameLbl.text=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
         }
         
         NSString *strCity=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
         
         if (strCity ==(id)[NSNull null] || [strCity isEqualToString:@""] || strCity==nil || [strCity length]==0) {
             cell.locationLbl.text=@"";
             
         }
         else
         {
             cell.locationLbl.text=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
         }
         
         
         NSString *strCavaheerID=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
         
         if (strCavaheerID ==(id)[NSNull null] || [strCavaheerID isEqualToString:@""] || strCavaheerID==nil || [strCavaheerID length]==0) {
             cell.cavaheerIDLbl.text=@"";
         }
         else
         {
             cell.cavaheerIDLbl.text=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
         }
         
         
         NSString *strCompanyType=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
         
         if (strCompanyType ==(id)[NSNull null] || [strCompanyType isEqualToString:@""] || strCompanyType==nil || [strCompanyType length]==0) {
             cell.compTypeLbl.text=@"";
             
         }
         else
         {
             cell.compTypeLbl.text=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
             
         }
         
         NSString *strRating=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Rating"];
         
         if (strRating ==(id)[NSNull null] || [strRating isEqualToString:@""] || strRating==nil || [strRating length]==0) {
             cell.ratingLbl.text=@"";
             
         }
         else
         {
             cell.ratingLbl.text=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Rating"];
            
         }

         cell.StarRatingView.value=2;
         
          cell.StarRatingView.userInteractionEnabled=NO;
         
       //  [cell.ratingLbl setUserInteractionEnabled:NO];
         
    }
    
   
    if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
        //        cell.lblSubjectHeight.constant=60;
        //        cell.lblSubjectIDHeight.constant=60;
    }
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (flag == 0) {
        
    MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
    
    
    NSString *strMemberName=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"MemberName"];
    
    if (strMemberName ==(id)[NSNull null] || [strMemberName isEqualToString:@""] || strMemberName==nil || [strMemberName length]==0)
    {
        MemberInfoVC.memberName=@"";
    }
    else
    {
        MemberInfoVC.memberName=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"MemberName"];
    }
    
    NSString *strExpireDate=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"ValidTo"]];
    
    if (strExpireDate ==(id)[NSNull null] || [strExpireDate isEqualToString:@""] || strExpireDate==nil || [strExpireDate length]==0)
    {
        MemberInfoVC.membershipExpireDate=@"";
    }
    else
    {
        MemberInfoVC.membershipExpireDate=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"ValidTo"]];
    }
    
    NSString *strCompanyName=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
    
    if (strCompanyName ==(id)[NSNull null] || [strCompanyName isEqualToString:@""] || strCompanyName==nil || [strCompanyName length]==0)
    {
       MemberInfoVC.compName=@"";
    }
    else
    {
        MemberInfoVC.compName=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
    }
    NSString *strCity=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
    NSString *strState=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"];
    NSString *strCountry=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
        
    if ((strCity ==(id)[NSNull null] || [strCity isEqualToString:@""] || strCity==nil || [strCity length]==0) || (strState ==(id)[NSNull null] || [strState isEqualToString:@""] || strState==nil || [strState length]==0) || (strCountry ==(id)[NSNull null] || [strCountry isEqualToString:@""] || strCountry==nil || [strCountry length]==0) )
    {
        MemberInfoVC.city=@"";
        MemberInfoVC.state=@"";
        MemberInfoVC.country=@"";
        
        MemberInfoVC.location=[NSString stringWithFormat:@"%@%@%@",MemberInfoVC.city,MemberInfoVC.state,MemberInfoVC.country];
        
        
    }
    else
    {
       MemberInfoVC.city=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
       MemberInfoVC.state=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"];
       MemberInfoVC.country=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"];

        MemberInfoVC.location=[NSString stringWithFormat:@"%@,%@,%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"],[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"],[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"]];
    }
     
    NSString *strCity1=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
        
    if (strCity1 ==(id)[NSNull null] || [strCity1 isEqualToString:@""] || strCity1==nil || [strCity1 length]==0)
    {
        MemberInfoVC.city=@"";
    }
    else
    {
        MemberInfoVC.city=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"City"];
    }

    NSString *strState1=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"];
        
    if (strState1 ==(id)[NSNull null] || [strState1 isEqualToString:@""] || strState1==nil || [strState1 length]==0)
    {
        MemberInfoVC.state=@"";
    }
    else
    {
        MemberInfoVC.state=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"State"];
    }
    NSString *strCountry1=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
        
    if (strCountry1 ==(id)[NSNull null] || [strCountry1 isEqualToString:@""] || strCountry1==nil || [strCountry1 length]==0)
    {
        MemberInfoVC.country=@"";
    }
    else
    {
        MemberInfoVC.country=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
    }
   
    
    NSString *strCompanyType=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
    
    if (strCompanyType ==(id)[NSNull null] || [strCompanyType isEqualToString:@""] || strCompanyType==nil || [strCompanyType length]==0)
    {
        MemberInfoVC.compType=@"";
    }
    else
    {
        MemberInfoVC.compType=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
    }
    
    NSString *strCavaheerID=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
    
    if (strCavaheerID ==(id)[NSNull null] || [strCavaheerID isEqualToString:@""] || strCavaheerID==nil || [strCavaheerID length]==0)
    {
        MemberInfoVC.ceveheerID=@"";
    }
    else
    {
        MemberInfoVC.ceveheerID=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
    }
    
    
    NSString *strTelephone=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Telephone"]];
    
    if (strTelephone ==(id)[NSNull null] || [strTelephone isEqualToString:@"<null>"] ||[strTelephone isEqualToString:@""] || strTelephone==nil || [strTelephone length]==0)
    {
       MemberInfoVC.telephone=@"";
    }
    else
    {
        MemberInfoVC.telephone=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Telephone"]];
    }

    NSString *strDiamond=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Dimondlistingcount"]];
    
    if (strDiamond ==(id)[NSNull null] || [strDiamond isEqualToString:@""] || strDiamond==nil || [strDiamond length]==0)
    {
        MemberInfoVC.diamondsListed=@"";
    }
    else
    {
       MemberInfoVC.diamondsListed=[NSString stringWithFormat:@"%@",[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Dimondlistingcount"]];
    }

    NSString *strEmail=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Email"];
    
    if (strEmail ==(id)[NSNull null] || [strEmail isEqualToString:@""] || strEmail==nil || [strEmail length]==0)
    {
        MemberInfoVC.website=@"";
    }
    else
    {
        MemberInfoVC.website=[[_jsonArray objectAtIndex:indexPath.row] valueForKey:@"Email"];
    }
    
    
    [self.navigationController pushViewController:MemberInfoVC animated:YES];
        
    }
    else{
        
        MemberInfo *MemberInfoVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberInfo"];
        
        
        NSString *strMemberName=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"MemberName"];
        
        if (strMemberName ==(id)[NSNull null] || [strMemberName isEqualToString:@""] || strMemberName==nil || [strMemberName length]==0)
        {
            MemberInfoVC.memberName=@"";
        }
        else
        {
            MemberInfoVC.memberName=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"MemberName"];
        }
        
        NSString *strExpireDate=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"ValidTo"]];
        
        if (strExpireDate ==(id)[NSNull null] || [strExpireDate isEqualToString:@""] || strExpireDate==nil || [strExpireDate length]==0)
        {
            MemberInfoVC.membershipExpireDate=@"";
        }
        else
        {
            MemberInfoVC.membershipExpireDate=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"ValidTo"]];
        }
        
        NSString *strCompanyName=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
        
        if (strCompanyName ==(id)[NSNull null] || [strCompanyName isEqualToString:@""] || strCompanyName==nil || [strCompanyName length]==0)
        {
            MemberInfoVC.compName=@"";
        }
        else
        {
            MemberInfoVC.compName=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyName"];
        }
        NSString *strCity=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
        NSString *strState=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"State"];
        NSString *strCountry=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
        
        if ((strCity ==(id)[NSNull null] || [strCity isEqualToString:@""] || strCity==nil || [strCity length]==0) || (strState ==(id)[NSNull null] || [strState isEqualToString:@""] || strState==nil || [strState length]==0) || (strCountry ==(id)[NSNull null] || [strCountry isEqualToString:@""] || strCountry==nil || [strCountry length]==0) )
        {
            MemberInfoVC.city=@"";
            MemberInfoVC.state=@"";
            MemberInfoVC.country=@"";
            
            MemberInfoVC.location=[NSString stringWithFormat:@"%@%@%@",MemberInfoVC.city,MemberInfoVC.state,MemberInfoVC.country];
            
            
        }
        else
        {
            MemberInfoVC.city=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
            MemberInfoVC.state=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"State"];
            MemberInfoVC.country=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
            
            MemberInfoVC.location=[NSString stringWithFormat:@"%@,%@,%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"],[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"State"],[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Country"]];
        }
        
        NSString *strCity1=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
        
        if (strCity1 ==(id)[NSNull null] || [strCity1 isEqualToString:@""] || strCity1==nil || [strCity1 length]==0)
        {
            MemberInfoVC.city=@"";
        }
        else
        {
            MemberInfoVC.city=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"City"];
        }
        
        NSString *strState1=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"State"];
        
        if (strState1 ==(id)[NSNull null] || [strState1 isEqualToString:@""] || strState1==nil || [strState1 length]==0)
        {
            MemberInfoVC.state=@"";
        }
        else
        {
            MemberInfoVC.state=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"State"];
        }
        NSString *strCountry1=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
        
        if (strCountry1 ==(id)[NSNull null] || [strCountry1 isEqualToString:@""] || strCountry1==nil || [strCountry1 length]==0)
        {
            MemberInfoVC.country=@"";
        }
        else
        {
            MemberInfoVC.country=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Country"];
        }
        
        
        NSString *strCompanyType=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
        
        if (strCompanyType ==(id)[NSNull null] || [strCompanyType isEqualToString:@""] || strCompanyType==nil || [strCompanyType length]==0)
        {
            MemberInfoVC.compType=@"";
        }
        else
        {
            MemberInfoVC.compType=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CompanyType"];
        }
        
        NSString *strCavaheerID=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
        
        if ( strCavaheerID ==(id)[NSNull null] || [strCavaheerID isEqualToString:@""] || strCavaheerID==nil || [strCavaheerID isEqualToString:@"<null>"] || [strCavaheerID length]==0 )
        {
            MemberInfoVC.ceveheerID=@"";
        }
        else
        {
            MemberInfoVC.ceveheerID=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"CavaheerID"]];
        }
        
        NSString *strTelephone=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Telephone"]];
        
        if (strTelephone ==(id)[NSNull null] || [strTelephone isEqualToString:@"<null>"]|| [strTelephone isEqualToString:@""] || strTelephone==nil || [strTelephone length]==0)
        {
            MemberInfoVC.telephone=@"";
        }
        else
            
        {
            MemberInfoVC.telephone=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Telephone"]];
        }
        
        NSString *strDiamond=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Dimondlistingcount"]];
        
        if (strDiamond ==(id)[NSNull null] || [strDiamond isEqualToString:@""] || strDiamond==nil || [strDiamond length]==0)
        {
            MemberInfoVC.diamondsListed=@"";
        }
        else
        {
            MemberInfoVC.diamondsListed=[NSString stringWithFormat:@"%@",[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Dimondlistingcount"]];
        }
        
        NSString *strEmail=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Email"];
        
        if (strEmail ==(id)[NSNull null] || [strEmail isEqualToString:@""] || strEmail==nil || [strEmail length]==0)
        {
            MemberInfoVC.website=@"";
        }
        else
        {
            MemberInfoVC.website=[[filteredArray objectAtIndex:indexPath.row] valueForKey:@"Email"];
        }
        
    
        [self.navigationController pushViewController:MemberInfoVC animated:YES];
    
        
    }
    

}

//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
////    return [NSArray arrayWithObjects:@"A", @"B", @"C", @"D", @"E",@"F", @"G", @"H", @"I", @"J",@"K", @"L", @"M", @"N", @"O",@"P", @"Q", @"R", @"S", @"T",@"U", @"V", @"W", @"X", @"Y",@"Z", nil];
//}
- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    return _jsonArray.count;
}
-(void)viewDidAppear:(BOOL)animated
{
    [_tableView reloadData];
}

#pragma mark - UISearchBarDelegate
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    NSLog(@"searchText =%@",searchText);
    
    
    if (_searchBar.text.length == 0 ) {
     
     
        isFiltered = NO;
        
    }
    else
    {
        if ([searchText isEqualToString:@""]) {
            
        }
        else
        {
            
        }
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            //background processing goes here
            isFiltered = YES;
            
            filteredArray =[[NSMutableArray alloc] init];
            
            
            for (NSDictionary *str in _jsonArray) {
                
                NSString *compNameStr=[str valueForKey:@"CompanyName"];
                
                NSString *CavaheerIDStr=[NSString stringWithFormat:@"%@",[str objectForKey:@"CavaheerID"]];
                NSRange stringRang=[compNameStr rangeOfString:_searchBar.text options:NSCaseInsensitiveSearch];
                NSRange stringRang2=[CavaheerIDStr rangeOfString:_searchBar.text options:NSCaseInsensitiveSearch];
                
                
                if (stringRang.location != NSNotFound || stringRang2.location != NSNotFound)
                {
                    
                    [ filteredArray addObject:str];
                    
                    NSLog(@"FilteredArray =%lu",(unsigned long)filteredArray.count);
                    
                }
            }

            dispatch_async(dispatch_get_main_queue(), ^{
                //update UI here
            [_tableView reloadData];
         

                
            });
        });
        
    }
    
    // Do the search...
    
    
   [_tableView reloadData];
    
    
}

//-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
//{
//    
//    if (searchText.length == 0) {
//        
//        isFiltered = NO;
//    }
//    else
//    {
//        isFiltered = YES;
//        
//        filteredArray =[[NSMutableArray alloc] init];
//        
//        
//        for (NSDictionary *str in _jsonArray) {
//            
//            NSString *compNameStr=[str valueForKey:@"CompanyName"];
//            
//            NSString *CavaheerIDStr=[NSString stringWithFormat:@"%@",[str objectForKey:@"CavaheerID"]];
//            NSRange stringRang=[compNameStr rangeOfString:searchText options:NSCaseInsensitiveSearch];
//            NSRange stringRang2=[CavaheerIDStr rangeOfString:searchText options:NSCaseInsensitiveSearch];
//            
//            
//            if (stringRang.location != NSNotFound || stringRang2.location != NSNotFound)
//            {
//                
//                [ filteredArray addObject:str];
//                
//                NSLog(@"FilteredArray =%@",filteredArray);
//                
//            }
//        }
//    }
//    
//    [_tableView reloadData];

//    
//}
- (IBAction)btnResetClicked:(id)sender {
    [sender resignFirstResponder];
    _searchBar.text=@"";
    
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    
       [_tableView resignFirstResponder];
       [searchBar resignFirstResponder];

}
- (IBAction)btnSerchingClicked:(id)sender {
    
    
    if (_searchBar.text.length == 0) {
        
        isFiltered = NO;
    }
    else
    {
        isFiltered = YES;
        
        filteredArray =[[NSMutableArray alloc] init];
        
        
        for (NSDictionary *str in _jsonArray) {
            
            NSString *compNameStr=[str valueForKey:@"CompanyName"];
            
            NSString *CavaheerIDStr=[NSString stringWithFormat:@"%@",[str objectForKey:@"CavaheerID"]];
            NSRange stringRang=[compNameStr rangeOfString:_searchBar.text options:NSCaseInsensitiveSearch];
            NSRange stringRang2=[CavaheerIDStr rangeOfString:_searchBar.text options:NSCaseInsensitiveSearch];
            
            
            if (stringRang.location != NSNotFound || stringRang2.location != NSNotFound)
            {
                
                [ filteredArray addObject:str];
                
                NSLog(@"FilteredArray =%@",filteredArray);
                
            }
        }
    }
    
    [_tableView reloadData];
}

- (IBAction)btnMenuClicked:(id)sender {
    // go to back
    
    [self.navigationController popToRootViewControllerAnimated:YES];
//    SWRevealViewController *revealController = [self revealViewController];
//    [revealController revealToggle:sender];
}

#pragma mark Webservice Methods
-(void)findPeopleResult
{
    
    if ( [language isEqualToString:@"en-US"] || [language isEqualToString:@"en-IN"] || [language isEqualToString:@" en-AU"] || [language isEqualToString:@"en-CA"] || [language isEqualToString:@"en-IE"] || [language isEqualToString:@"en-NZ"] || [language isEqualToString:@"en-SG"] || [language isEqualToString:@"en-ZA"] || [language isEqualToString:@"en-GB"])
    {
        
        Lid=@"1";
    }
    else
    {
        Lid=@"2";
    }

    NSString* parameterString=[NSString stringWithFormat:@"%@CompanyName=%@&MemberName=%@&CompanyType=%@&Country=%@&City=%@&State=%@&Telephone=%@&Rating=%@&CavaheerID=%@&Lid=%@",FIND_PEOPLE,_strCompName,_strMemberName,_strCompType,_strCountry,_strCity,_strState,_strTelephone,@"",_strCevaheerId,Lid];

    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                            NSUTF8StringEncoding];
    [webserviceClass callServcieUsingRequestAndGET:encodedUrl:nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    NSLog(@"URL=%@",parameterString);

}
- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
   // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    
    if(json == nil)
    {
       // [constants_class showAlert:@"Error connecting server."];
        
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if (![Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];

        }
        else
        {
                  NSDictionary *subDict= [json objectForKey:@"Result"];
                 _jsonArray = [subDict objectForKey:@"Table"];
        }
        
    }

    
[self.tableView reloadData];
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles:@"ok", nil];
    [alertMsg show];
}
-(BOOL)textFieldShouldReturn:(UISearchBar *)textField
{
    [textField resignFirstResponder];
    [_searchBar resignFirstResponder];
    
    return YES;
}


- (IBAction)btnHomeClicked:(id)sender {
    
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];

}
- (IBAction)btnMyListingClicked:(id)sender {
    
    MyListings *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MyListings"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnMessageClicked:(id)sender {
    
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnFindDiamondClicked:(id)sender {
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnMemberClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];

}
-(void)callServiceForBanerAd
{
    
    Reachability* reach = [Reachability reachabilityWithHostName:@"www.google.com"];
    
    if ([reach isReachable])
    {
        
        
        //Init the NSURLSession with a configuration
        NSURLSessionConfiguration *defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        NSURLSession *defaultSession = [NSURLSession sessionWithConfiguration: defaultConfigObject delegate: nil delegateQueue: [NSOperationQueue mainQueue]];
        
        //Create an URLRequest
        NSURL *url1 = [NSURL URLWithString:@"http://webservice.cevaheer.com/api/Banner?PageName=Find%20Member"];
        NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url1];
        
        //Create POST Params and add it to HTTPBody
        
        
        [urlRequest setHTTPMethod:@"GET"];
        [urlRequest addValue:@"cevaheer" forHTTPHeaderField:@"UserName"];
        [urlRequest addValue:@"cevaheer@!@#" forHTTPHeaderField:@"Password"];
        //[urlRequest setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
        
        //Create task
        NSURLSessionDataTask *dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)    {
            NSError* error1;
            NSDictionary *json1 = [NSJSONSerialization
                                   JSONObjectWithData:data options:kNilOptions error:&error1];
            
            NSNumber *strStatus=[json1 valueForKey:@"Statuscode"];
            
            if (strStatus.integerValue==0 )
            {
                
                _BanerAdImageView.hidden=YES;
                _footerView.hidden=YES;
                _footerViewContraintHeight.constant=0.1f;
                
            }
            else
            {
                _BanerAdImageView.hidden=NO;

            NSDictionary *resultDict=[json1  valueForKey:@"Result"];
            
            NSArray *tableArray=[resultDict valueForKey:@"Table"];
            
            for (NSDictionary *result in tableArray) {
                
                urlString=[result valueForKey:@"Bannerimage"];
                
                //   _BanerAdImageView = [UIImage animatedImageWithAnimatedGIFURL:[NSURL URLWithString:urlString]];
                NSLog(@"callServiceForBanerAd :%@",json1);
                
                dispatch_queue_t imageQueue = dispatch_queue_create("Image Queue",NULL);
                dispatch_async(imageQueue, ^{
                    
                    NSURL *url = [NSURL URLWithString:urlString];
                    //                    NSData *imageData = [NSData dataWithContentsOfURL:url];
                    //                    UIImage *image = [UIImage imageWithData:imageData];
                    
                    UIImage *loadingImage = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:url]];
                    
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // Update the UI
                        //   [_BanerAdImageView setImage:image];
                        
                        _BanerAdImageView.animationImages = loadingImage.images;
                        _BanerAdImageView.animationDuration = loadingImage.duration;
                        
                        // [NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector:@selector(runMethod) userInfo:nil repeats:YES];
                        
                        
                        _BanerAdImageView.animationRepeatCount = 0;
                        
                        
                        _BanerAdImageView.image = loadingImage.images.lastObject;
                        [_BanerAdImageView startAnimating];
                    });
                    
                });
                
                }
            
            }
            
            // [Constant setDateFromService:truncated];
        }];
        [dataTask resume];
    }else
    {
        UIAlertController *alrtController=[UIAlertController alertControllerWithTitle:@"Alert" message:@"No internet connection." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *okAction=[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        
        [alrtController addAction:okAction];
        
        [self presentViewController:alrtController animated:YES completion:nil];
    }
}

@end
