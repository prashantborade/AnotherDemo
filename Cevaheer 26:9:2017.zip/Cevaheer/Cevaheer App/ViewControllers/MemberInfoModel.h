//
//  MemberInfoModel.h
//  Cevaheer App
//
//  Created by SMS Systems on 11/18/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MemberInfoModel : NSObject

@property(nonatomic,strong) NSString *memberName;
@property(nonatomic,strong) NSString *membershipExpireDate;
@property(nonatomic,strong) NSString *compName;
@property(nonatomic,strong) NSString *location;
@property(nonatomic,strong) NSString *compType;
@property(nonatomic,strong) NSString *ceveheerID;
@property(nonatomic,strong) NSString *city;
@property(nonatomic,strong) NSString *country;
@property(nonatomic,strong) NSString *state;
@property(nonatomic,strong) NSString *telephone;
@property(nonatomic,strong) NSString *diamondsListed;
@property(nonatomic,strong) NSString *website;

@end
