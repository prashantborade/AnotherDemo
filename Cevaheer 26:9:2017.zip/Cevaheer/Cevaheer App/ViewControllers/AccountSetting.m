//
//  AccountSetting.m
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "AccountSetting.h"
#import "WelcomeViewController.h"

@interface AccountSetting ()

@end

@implementation AccountSetting

- (void)viewDidLoad {
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [self.navigationItem setHidesBackButton:YES];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strEmail= [defaults valueForKey:@"EmailAddress"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];

  
}
- (SWRevealViewController*)revealViewController
{
    UIViewController *parent = self;
    Class revealClass = [SWRevealViewController class];
    while ( nil != (parent = [parent parentViewController]) && ![parent isKindOfClass:revealClass] ) {}
    return (id)parent;
}


#pragma mark - IBAction
- (IBAction)btnBackClicked:(id)sender {
    
    WelcomeViewController *WelcomeViewControllerVC=[self.storyboard instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    
    [self.navigationController pushViewController:WelcomeViewControllerVC animated:YES];

//    
//    SWRevealViewController *revealController = [self revealViewController];
//    [revealController revealToggle:sender];
    //[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnEditClicked:(id)sender {
    
    EditProfile *EditProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"EditProfile"];
    
    [self.navigationController pushViewController:EditProfileVC animated:YES];
}
-(void)viewWillAppear:(BOOL)animated
{
    webserviceClass =[[WebserviceClass alloc] init];
    [self accountSetting];
    
}

#pragma mark Webservice Methods
-(void)accountSetting
{
    NSString *strRequest=ACCOUNT_SETTING;
    NSString *parameterString=[NSString stringWithFormat:@"EmailId=%@",strEmail];
    

    strRequest=[strRequest stringByAppendingString:parameterString];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    
    NSLog(@"URL=%@",parameterString);

    
}
- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    if(json == nil)
    {
        // [constants_class showAlert:@"Error connecting server."];
    }
    else
    {
        
        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
        Message =[json objectForKey:@"Message"];
        
        if (![Statuscode isEqualToString:@"1"]) {
            
            [self showMessage];
            
        }
        else
        {
            if (![json objectForKey:@"Result"]) {
                
                
            }
            else
            {
                NSDictionary *subDict= [json objectForKey:@"Result"];
                _jsonArray = [subDict objectForKey:@"Table"];
                
                for (NSDictionary *result in _jsonArray) {
                    
                    NSString *strFirstName=[result objectForKey:@"FirstName"];
                    
                    if (strFirstName ==(id)[NSNull null] || [strFirstName isEqualToString:@""] || strFirstName==nil || [strFirstName length]==0 || [strFirstName isEqualToString:@"<null>"]) {
                        
                        _strFirstName=@"";
                        
                    }
                    else
                    {
                       _strFirstName=[result objectForKey:@"FirstName"];
                    }
                    
                    NSString *strLastName=[result objectForKey:@"LastName"];
                    
                    if (strLastName ==(id)[NSNull null] || [strLastName isEqualToString:@""] || strLastName==nil || [strLastName length]==0 || [strLastName isEqualToString:@"<null>"]) {
                        
                        _strLastName=@"";
                        
                    }
                    else
                    {
                        _strLastName=[result objectForKey:@"LastName"];
                    }

                    _textViewUserName.text=[NSString stringWithFormat:@"%@ %@",_strFirstName,_strLastName];
                    
                    NSString *strCompanyName=[result objectForKey:@"CompanyName"];
                    
                    if (strCompanyName ==(id)[NSNull null] || [strCompanyName isEqualToString:@""] || strCompanyName==nil || [strCompanyName length]==0 || [strCompanyName isEqualToString:@"<null>"]) {
                      
                        _textViewCompName.text=@"";
                        
                    }
                    else
                    {
                       _textViewCompName.text=[result objectForKey:@"CompanyName"];
                    }
                    
                    NSString *strBusinessPhone=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                    
                    if (strBusinessPhone ==(id)[NSNull null] || [strBusinessPhone isEqualToString:@""] || strBusinessPhone==nil || [strBusinessPhone length]==0 || [strBusinessPhone isEqualToString:@"<null>"]) {
                        
                        _textViewPhone.text=@"";
                        
                    }
                    else
                    {
                         _textViewPhone.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                    }
                    
                    NSString *strPassword=[NSString stringWithFormat:@"%@",[result objectForKey:@"Password"]];
                    
                    if (strPassword ==(id)[NSNull null] || [strPassword isEqualToString:@""] || strPassword==nil || [strPassword length]==0) {
                        
                         _textViewPassword.text=@"";
                        
                    }
                    else
                    {
                         _textViewPassword.text=[result objectForKey:@"Password"];
                    }

                   
                    
                }

            }
            
            
        }
        
    }
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:1.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}

@end
