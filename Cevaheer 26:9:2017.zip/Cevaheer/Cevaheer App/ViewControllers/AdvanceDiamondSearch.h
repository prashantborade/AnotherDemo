//
//  AdvanceDiamondSearch.h
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchDiamondResult.h"
#import "MoreCell.h"

@interface AdvanceDiamondSearch : UIViewController
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSearchClicked:(id)sender;
- (IBAction)btnCuletMoreClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *tblVwMore;

@end
