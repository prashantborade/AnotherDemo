//
//  SaveCalculation.m
//  Cevaheer App
//
//  Created by SMS on 13/02/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//



#import "SaveCalculation.h"

@interface SaveCalculation ()

@end

@implementation SaveCalculation

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"SaveCalculationCell";
    
    SaveCalculationCell *cell = (SaveCalculationCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[SaveCalculationCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
        //        cell.lblSubjectHeight.constant=60;
        //        cell.lblSubjectIDHeight.constant=60;
    }
    
    
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90.0f; // Normal height
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnMinusClicked:(id)sender {
}

- (IBAction)btnPlusClicked:(id)sender {
}

- (IBAction)saveCalculationClicked:(id)sender {
    

    
}
- (IBAction)btnCancelClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
@end
