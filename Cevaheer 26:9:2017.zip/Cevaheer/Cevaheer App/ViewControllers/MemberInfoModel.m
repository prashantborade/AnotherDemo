//
//  MemberInfoModel.m
//  Cevaheer App
//
//  Created by SMS Systems on 11/18/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MemberInfoModel.h"

@implementation MemberInfoModel

@end
