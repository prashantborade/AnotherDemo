//
//  UpdateProfile.m
//  Cevaheer App
//
//  Created by  on 10/3/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "UpdateProfile.h"

@interface UpdateProfile ()

@end

@implementation UpdateProfile
#pragma mark - Lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
     flag=0;
    _jsonArray=[[NSMutableArray alloc] init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    strEmail= [defaults valueForKey:@"EmailAddress"];
    strUserId= [defaults valueForKey:@"UserId"];
    NSLog(@"Email Address = %@",[defaults valueForKey:@"EmailAddress"]);
    [defaults synchronize];
   webserviceClass=[[WebserviceClass alloc] init];
    
    [self memberProfile];
}
   
-(void)textFieldInitialize
{
    _txtFirstName.text=@"";
    _txtLastName.text=@"";
    _txtCompName.text=@"";
    _txtCompType.text=@"";
    _txtCevaheerId.text=@"";
    _txtLocation.text=@"";
    _txtCountry.text=@"";;
    _txtState.text=@"";
    _txtCity.text=@"";
    _txtTelephone.text=@"";
    _txtDiamondCount.text=@"";
    _txtWebsite.text=@"";
}

#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
#pragma mark - UIActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;

    
    switch (buttonIndex) {
        case 0:
        {
                        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            
           
        }
            break;
        case 1:
        {
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                
                UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                      message:@"Device has no camera"
                                                                     delegate:nil
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles: nil];
                
                [myAlertView show];
                
            }
            else{
            
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            
            
            }
        }
            break;
            
        default:
            break;
    }
     [self presentViewController:picker animated:YES completion:NULL];
}
-(void)actionSheetCancel:(UIActionSheet *)actionSheet
{

}
#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    [self.btnUploadPhoto setImage:chosenImage forState:UIControlStateNormal];
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
#pragma mark - IBActions

- (IBAction)btnUploadPhotoClicked:(id)sender {
    
    UIActionSheet *actionSheet=[[UIActionSheet alloc]initWithTitle:@"Select image from" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Gallery",@"Camera", nil];
    [actionSheet showInView:self.view];
}

- (IBAction)btnResetClicked:(id)sender {
    [self textFieldInitialize];
}

- (IBAction)btnSaveClicked:(id)sender {
    
    NSLog(@"Save Clicked");
    flag=1;
    
    [self editUserProfile];

}

- (IBAction)btnBackClicked:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Webservice Methods
-(void)editUserProfile
{
 
    
    NSString *strRequest=EDIT_USER_PROFILE;
    NSString *parameterString=[NSString stringWithFormat:@"UserId=%@&FirstName=%@&LastName=%@&Companyname=%@&CompanyType=%@&CompanyId=%@&Location=%@&Country=%@&State=%@&City=%@&Telephone=%@&Website=%@",strUserId,_txtFirstName.text,_txtLastName.text,_txtCompName.text,_txtCompType.text,@"",_txtLocation.text,_txtCountry.text,_txtState.text,_txtCity.text,_txtTelephone.text,_txtWebsite.text];
    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
                             NSUTF8StringEncoding];

     strRequest=[strRequest stringByAppendingString:encodedUrl];
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];

    NSLog(@"URL=%@",strRequest);

}

-(void)memberProfile
{

    NSString *strRequest=ACCOUNT_SETTING;
    NSString *parameterString=[NSString stringWithFormat:@"EmailId=%@",strEmail];
    
    
    strRequest=[strRequest stringByAppendingString:parameterString];
    
    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
    
    
    NSLog(@"URL=%@",parameterString);
    
    
}
- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
    
    if (flag == 1) {
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
            }
            else
            {
                [self showMessage];
                [self.navigationController popViewControllerAnimated:YES];
                
            }
            
        }

    }
    else{
       
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
                [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                    [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArray = [subDict objectForKey:@"Table"];
                    
                    for (NSDictionary *result in _jsonArray) {
                        
                        NSString *FirstName=[result objectForKey:@"FirstName"];
                        NSString *LastName=[result objectForKey:@"LastName"];
                        
                        if ((FirstName ==(id)[NSNull null] || [FirstName isEqualToString:@""] || FirstName==nil || [FirstName length]==0 || [FirstName  isEqualToString:@"<null>"]) || (LastName ==(id)[NSNull null] || [LastName isEqualToString:@""] || LastName==nil || [LastName length]==0 || [LastName  isEqualToString:@"<null>"]))
                        {
                            _txtFirstName.text=@"";
                            _txtLastName.text=@"";
                            
                        }
                        else
                        {
                            _txtFirstName.text=[result objectForKey:@"FirstName"];
                            _txtLastName.text=[result objectForKey:@"LastName"];
                        }
                        
                        
                        NSString *CompanyName=[NSString stringWithFormat:@"%@",[result objectForKey:@"CompanyName"]];
                        
                        if (CompanyName == (id)[NSNull null] ||[CompanyName isEqualToString:@""] || CompanyName == nil || [CompanyName length] ==0 || [CompanyName  isEqualToString:@"<null>"])
                        {
                            _txtCompName.text=@"";
                        }
                        else
                        {
                            _txtCompName.text=[result objectForKey:@"CompanyName"];
                        }
                        
                        NSString *TypeOfBusiness=[NSString stringWithFormat:@"%@",[result objectForKey:@"TypeOfBusiness"]];
                        
                        if (TypeOfBusiness == (id)[NSNull null] ||[TypeOfBusiness isEqualToString:@""] || TypeOfBusiness == nil || [TypeOfBusiness length] ==0 || [TypeOfBusiness  isEqualToString:@"<null>"])
                        {
                            _txtCompType.text=@"";
                        }
                        else
                        {
                            _txtCompType.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"TypeOfBusiness"]];
                        }
                        
                        
                        NSString *CityID=[NSString stringWithFormat:@"%@",[result objectForKey:@"CityName"]];
                        
                        if (CityID == (id)[NSNull null] ||[CityID isEqualToString:@""] || CityID == nil || [CityID length] ==0 || [CityID  isEqualToString:@"<null>"])
                        {
                            _txtCity.text=@"";
                        }
                        else
                        {
                            _txtCity.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"CityName"]];
                        }
                        
                        NSString *CountryName=[result objectForKey:@"CountryName"];
                        
                        if (CountryName == (id)[NSNull null] ||[CountryName isEqualToString:@""] || CountryName == nil || [CountryName length] ==0 || [CountryName  isEqualToString:@"<null>"])
                        {
                            _txtCountry.text=@"";
                        }
                        else
                        {
                            _txtCountry.text=[result objectForKey:@"CountryName"];
                        }
                        
                        NSString *StateID=[NSString stringWithFormat:@"%@",[result objectForKey:@"StateName"]];
                        
                        if (StateID == (id)[NSNull null] ||[StateID isEqualToString:@""] || StateID == nil || [StateID length] ==0 || [StateID  isEqualToString:@"<null>"])
                        {
                            _txtState.text=@"";
                        }
                        else
                        {
                            _txtState.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"StateName"]];
                        }
                        
                        NSString *MobileNumber=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        
                        if (MobileNumber == (id)[NSNull null] ||[MobileNumber isEqualToString:@""] || MobileNumber == nil || [MobileNumber length] ==0 || [MobileNumber  isEqualToString:@"<null>"])
                        {
                            _txtTelephone.text=@"";
                        }
                        else
                        {
                            _txtTelephone.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"BusinessPhone"]];
                        }
                        
                        NSString *Dimondlistingcount=[NSString stringWithFormat:@"%@",[result objectForKey:@"Dimondlistingcount"]];
                        
                        if (Dimondlistingcount == (id)[NSNull null] ||[Dimondlistingcount isEqualToString:@""] || Dimondlistingcount == nil || [Dimondlistingcount length] ==0 || [Dimondlistingcount  isEqualToString:@"<null>"])
                        {
                            _txtDiamondCount.text=@"";
                        }
                        else
                        {
                            _txtDiamondCount.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"Dimondlistingcount"]];
                        }
                        
                        NSString *Email=[NSString stringWithFormat:@"%@",[result objectForKey:@"Email"]];
                        
                        if (Email == (id)[NSNull null] ||[Email isEqualToString:@""] || Email == nil || [Email length] ==0 || [Email  isEqualToString:@"<null>"])
                        {
                            _txtWebsite.text=@"";
                        }
                        else
                        {
                            _txtWebsite.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"Email"]];
                        }
                        
                        NSString *Address=[NSString stringWithFormat:@"%@",[result objectForKey:@"Address"]];
                        
                        if (Address == (id)[NSNull null] ||[Address isEqualToString:@""] || Address == nil || [Address length] ==0 || [Address  isEqualToString:@"<null>"])
                        {
                            _txtLocation.text=@"";
                        }
                        else
                        {
                            _txtLocation.text=[NSString stringWithFormat:@"%@",[result objectForKey:@"Address"]];
                        }
                        
                    }
                    
                }
                
                
            }
            
        }
    }
    
    
}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}
-(void)showMessage
{
    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
    [alertMsg show];
    
    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:2.0];
}
-(void)dismiss:(UIAlertView*)alertMessage
{
    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
}




//#pragma mark Webservice Methods
//-(void)editUserProfile
//{
//    
//    NSString *strRequest=EDIT_USER_PROFILE;
//    NSString *parameterString=[NSString stringWithFormat:@"UserId=%@&FirstName=%@&LastName=%@&Companyname=%@&CompanyType=%@&CompanyId=%@&Location=%@&Country=%@&State=%@&City=%@&Telephone=%@&Website=%@",strUserId,_txtFirstName.text,_txtLastName.text,_txtCompName.text,_txtCompType.text,@"",_txtLocation.text,_txtCountry.text,_txtState.text,_txtCity.text,_txtTelephone.text,_txtWebsite.text];
//    NSString  *encodedUrl = [parameterString stringByAddingPercentEscapesUsingEncoding:
//                             NSUTF8StringEncoding];
//    
//     strRequest=[strRequest stringByAppendingString:encodedUrl];
//    [webserviceClass callServcieUsingRequestAndPOST:strRequest :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];
//    
//    NSLog(@"URL=%@",strRequest);
//    
//}
//- (void)requestSucceeded:(NSString *)response
//{
//    
//    self.view.userInteractionEnabled=YES;
//    NSError *error;
//    // NSLog(@"Response : %@",response);
//    [SVProgressHUD dismiss];
//    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
//    
//    
//}
//- (void)requestFailed:(NSString *)response
//{
//    [SVProgressHUD dismiss];
//    
//    self.view.userInteractionEnabled=YES;
//    
//    //NSLog(@"requestFailed : %@",response);
//}
//
//#pragma mark Webservice Methods
//-(void)sendResponse:(NSMutableData *)dataResponseArray
//{
//    NSError* error;
//    json = [NSJSONSerialization
//            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
//    
//    if(json == nil)
//    {
//        // [constants_class showAlert:@"Error connecting server."];
//    }
//    else
//    {
//        
//        Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
//        Message =[json objectForKey:@"Message"];
//        
//        if (![Statuscode isEqualToString:@"1"]) {
//            
//            [self showMessage];
//            
//        }
//        else
//        {
//            [self.navigationController popoverPresentationController];
//            
//        }
//        
//    }
//    
//}
//-(void)sendError :(NSError *) error
//{
//    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
//}
//-(void)showMessage
//{
//    UIAlertView *alertMsg=[[UIAlertView alloc] initWithTitle:@"Message!!!" message:Message delegate:self cancelButtonTitle:nil otherButtonTitles: nil];
//    [alertMsg show];
//    
//    [self performSelector:@selector(dismiss:) withObject:alertMsg afterDelay:3.0];
//}
//-(void)dismiss:(UIAlertView*)alertMessage
//{
//    [alertMessage dismissWithClickedButtonIndex:0 animated:YES];
//}
//
@end
