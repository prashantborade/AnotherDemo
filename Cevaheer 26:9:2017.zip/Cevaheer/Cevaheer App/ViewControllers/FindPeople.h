//
//  FindPeople.h
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StarRatingView.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "FindPeopleSearchResult.h"
#import "WebserviceClass.h"
#import "Result.h"

@class WebserviceClass;

@interface FindPeople : UIViewController<UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scroll;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnCompanyHeight;
@property (strong, nonatomic) IBOutlet UIButton *btnCompany;
@property (strong, nonatomic) IBOutlet UIButton *btnMember;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btnMemberHeight;

#pragma mark - Outlets

@property (strong, nonatomic) IBOutlet UITextField *txtCompName;
@property (strong, nonatomic) IBOutlet UITextField *txtMemberName;
@property (strong, nonatomic) IBOutlet UITextField *txtCompType;
@property (strong, nonatomic) IBOutlet UITextField *txtCountry;
@property (strong, nonatomic) IBOutlet UITextField *txtCity;
@property (strong, nonatomic) IBOutlet UITextField *txtTelephone;
@property (strong, nonatomic) IBOutlet UITextField *txtState;

@property (strong, nonatomic) IBOutlet UITextField *txtCevaheerId;

@property (strong, nonatomic) IBOutlet HCSStarRatingView *StarRatingView;

@property(nonatomic,strong) NSString *starRatingValue;


#pragma mark - IBAction 

- (IBAction)btnSearchClicked:(id)sender;
- (IBAction)btnMenuClicked:(id)sender;
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)didChangeValue:(id)sender;




@end
