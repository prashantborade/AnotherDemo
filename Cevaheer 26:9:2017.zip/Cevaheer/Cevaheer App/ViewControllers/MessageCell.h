//
//  MessageCell.h
//  Cevaheer App
//
//  Created by  on 9/26/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIView *userImgViewLeft;
@property (strong, nonatomic) IBOutlet UIImageView *userImgViewRight;
@property (strong, nonatomic) IBOutlet UILabel *lblUserName;
@property (strong, nonatomic) IBOutlet UILabel *lblSubject;

@property (strong, nonatomic) IBOutlet UILabel *lblMessageContent;
@property (strong, nonatomic) IBOutlet UILabel *lblTime;

@end
