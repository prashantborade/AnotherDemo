//
//  ParcelDiamondSearch.h
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchDiamondResult.h"
#import "MoreCell.h"

@interface ParcelDiamondSearch : UIViewController
- (IBAction)btnResetClicked:(id)sender;
- (IBAction)btnSearchClicked:(id)sender;





@property (strong, nonatomic) IBOutlet UITableView *tblVwMore;
@property (weak, nonatomic) IBOutlet UIButton *btnRound;
@property (weak, nonatomic) IBOutlet UIButton *btnEmeraId;
@property (weak, nonatomic) IBOutlet UIButton *btnPear;
@property (weak, nonatomic) IBOutlet UIButton *btnPrincess;
@property (weak, nonatomic) IBOutlet UIButton *btnOval;
@property (weak, nonatomic) IBOutlet UIButton *btnCushion;
@property (weak, nonatomic) IBOutlet UIButton *btnCusMod;
@property (weak, nonatomic) IBOutlet UIButton *btnHeart;
@property (weak, nonatomic) IBOutlet UIButton *btnMarquise;
@property (weak, nonatomic) IBOutlet UIButton *btnRadiant;




- (IBAction)btnRoundClicked:(id)sender;
- (IBAction)btnEmeraIdClicked:(id)sender;
- (IBAction)btnPearClicked:(id)sender;
- (IBAction)btnPrincessClicked:(id)sender;
- (IBAction)btnOvalClicked:(id)sender;
- (IBAction)btnCushionClicked:(id)sender;
- (IBAction)btnCusModClicked:(id)sender;
- (IBAction)btnHeartClicked:(id)sender;
- (IBAction)btnMarquiseClicked:(id)sender;
- (IBAction)btnRadiantClicked:(id)sender;

- (IBAction)btnShapeMoreClicked:(id)sender;
- (IBAction)btnColorMoreClicked:(id)sender;

















@end
