//
//  CityCell.h
//  Cevaheer App
//
//  Created by SMS on 30/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityCell : UITableViewCell

@end
