//
//  FindDiamond.h
//  Cevaheer App
//
//  Created by  on 9/29/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSString+FontAwesome.h"
#import "UIImage+FontAwesome.h"
#import "WhiteDiamondSearch.h"
#import "AdvanceDiamondSearch.h"
#import "ParcelDiamondSearch.h"
#import "FancyDiamondSearch.h"
#import "WelcomeViewController.h"
#import "MyListingCell.h"
#import "Messages.h"
#import "Calculator.h"
#import "MemberProfile.h"
@interface FindDiamond : UIViewController<UISearchBarDelegate,UISearchControllerDelegate>

@property (weak, nonatomic) IBOutlet UIButton *btnFancySearch;
@property (weak, nonatomic) IBOutlet UIButton *btnWhiteSearch;
@property (weak, nonatomic) IBOutlet UIButton *btnParcelSearch;
@property (weak, nonatomic) IBOutlet UIButton *btnAdvanceSearch;

@property (strong, nonatomic) IBOutlet UIImageView *BanerAdImageView;
@property (strong, nonatomic) IBOutlet UIView *footerView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *footerViewConstraintHeight;


@property (nonatomic, strong) NSArray *iconIdentiferArray;
@property (nonatomic, strong) NSArray *iconSearchArray;
@property (weak, nonatomic) IBOutlet UILabel *lblDiamond;
@property (weak, nonatomic) IBOutlet UIScrollView *scroll;

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

- (IBAction)btnWhiteSearchClicked:(id)sender;

- (IBAction)btnFancySearchClicked:(id)sender;

- (IBAction)btnParcelSearchClicked:(id)sender;
- (IBAction)btnAdvanceSearchClicked:(id)sender;

- (IBAction)btnMenuClicked:(id)sender;


// Calculator Search
@property(nonatomic,strong) NSString *strcaratValue;
@property(nonatomic,strong) NSString *strYourPrice;
@property(nonatomic,strong) NSString *strYourPriceTotal;
@property(nonatomic,strong) NSString *Shape;
@property(nonatomic,strong) NSString *Color;
@property(nonatomic,strong) NSString *Clarity;
@property(nonatomic,strong) NSString *Discount;


#pragma mark - Footer Menu
- (IBAction)btnHomeClicked:(id)sender;
- (IBAction)btnMyListingClicked:(id)sender;
- (IBAction)btnMessageClicked:(id)sender;
- (IBAction)btnCalculatorClicked:(id)sender;
- (IBAction)btnMemberProfileClicked:(id)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchBarHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *parcelSearchHeight;

@end
