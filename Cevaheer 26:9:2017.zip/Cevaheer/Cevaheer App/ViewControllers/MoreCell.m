//
//  MoreCell.m
//  Cevaheer App
//
//  Created by  on 10/7/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MoreCell.h"

@implementation MoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnMoreShapeClicked:(id)sender {
    
    
    
    
}
@end
