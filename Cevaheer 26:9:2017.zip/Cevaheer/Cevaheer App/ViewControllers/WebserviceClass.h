//
//  WebserviceClass.h
//  WaitTimerApp
//
//  Created by Mobile Team on 14/04/16.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"
@class WebserviceClass;
@protocol WebserviceProtocol;

@protocol WebserviceProtocol <NSObject>
@required
-(void)sendResponse :(NSMutableData *) dataResponseArray ;
-(void)sendError :(NSError *) error ;


@end


@interface WebserviceClass : NSObject<NSURLConnectionDelegate,NSURLConnectionDataDelegate,MBProgressHUDDelegate>
{
    BOOL internetActive;
    BOOL hostActive;
    NSURLConnection *theConnection;
    NSURLConnection *currentConnection;
    NSMutableURLRequest *request;

    
    MBProgressHUD *HUD , *HUDImage;
    UIView *current_view;
 }
@property(nonatomic,retain)NSMutableData *apiReturnData;


@property (nonatomic, assign) id<WebserviceProtocol> delegate;


-(void)callServcieUsingRequestAndGET :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *)HUD andViewController :(UIView *) view;


-(void)callServcieUsingRequestAndPOST :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *)HUD andViewController :(UIView *) view;


-(void)getDataUsingRequestToPost_Image :(NSString *) strRequest :  (NSDictionary *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view andHUDText : (NSString *) hudlabelText;

-(void)getDataUsingRequestToPost_Image_try :(NSString *) strRequest :  (NSString *) dataRequest andDelegate:(id<WebserviceProtocol>)delegateObject andProgressHud:(MBProgressHUD *) _HUD andViewController :(UIView *) view andHUDText : (NSString *) _hudlabelText;

-(void) showAlert : (NSString *) messageToShow;

@end
