//
//  CityCell.m
//  Cevaheer App
//
//  Created by SMS on 30/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "CityCell.h"

@implementation CityCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
