//
//  Calculator.m
//  Cevaheer App
//
//  Created by  on 9/28/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "Calculator.h"

@interface Calculator ()
{
    int count;
}
@end

@implementation Calculator
#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [self.navigationItem setHidesBackButton:YES];
   
    _jsonArray=[[NSMutableArray alloc] init];
    
    
    _UIScrollViewOutlets.scrollEnabled = NO;
    
    _UIViewAvg.hidden=YES;
 
    //[_lblDiscount setAdjustsFontSizeToFitWidth:YES];
    // for pickerView
    _shapePickerArray=[[NSMutableArray alloc] initWithObjects:@"Round",@"Pear", nil];
    _colorPickerArray=[[NSMutableArray alloc] initWithObjects:@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N", nil];
    _clarityPickerArray=[[NSMutableArray alloc] initWithObjects:@"FL",@"IF",@"VVS1",@"VVS2",@"VS1",@"VS2",@"SI1",@"SI2",@"SI3",@"I1",@"I2",@"I3", nil];
    
    _DiscountPickerArray=[[NSMutableArray alloc] initWithObjects:@"-99%",@"-98%",@"-97%",@"-96%",@"-95%",@"-94%",@"-93%",@"-92%",@"-91%",@"-90%",@"-89%",@"-88%",@"-87%",@"-86%",@"-85%",@"-84%",@"-83%",@"-82%",@"-81%",@"-80%",@"-79%",@"-78%",@"-77%",@"-76%",@"-75%",@"-74%",@"-73%",@"-72%",@"-71%",@"-70%",@"-69%",@"-68%",@"-67%",@"-66%",@"-65%",@"-64%",@"-63%",@"-62%",@"-61%",@"-60%",@"-59%",@"-58%",@"-57%",@"-56%",@"-55%",@"-54%",@"-53%",@"-52%",@"-51%",@"-50%",@"-49%",@"-48%",@"-47%",@"-46%",@"-45%",@"-44%",@"-43%",@"-42%",@"-41%",@"-40%",@"-39%",@"-38%",@"-37%",@"-36%",@"-35%",@"-34%",@"-33%",@"-32%",@"-31%",@"-30%",@"-29%",@"-28%",@"-27%",@"-26%",@"-25%",@"-24%",@"-23%",@"-22%",@"-21%",@"-20%",@"-19%",@"-18%",@"-17%",@"-16%",@"-15%",@"-14%",@"-13%",@"-12%",@"-11%",@"-10%",@"-9%",@"-8%",@"-7%",@"-6%",@"-5%",@"-4%",@"-3%",@"-2%",@"-1%",@"1%",@"2%",@"3%",@"4%",@"5%",@"6%",@"7%",@"8%",@"9%",@"10%",@"11%",@"12%",@"13%",@"14%",@"15%",@"16%",@"17%",@"18%",@"19%",@"20%",@"21%",@"22%",@"23%",@"24%",@"25%",@"26%",@"27%",@"28%",@"29%",@"30%",@"31%",@"32%",@"33%",@"34%",@"35%",@"36%",@"37%",@"38%",@"39%",@"40%",@"41%",@"42%",@"43%",@"44%",@"45%",@"46%",@"47%",@"48%",@"49%",@"50%",@"51%",@"52%",@"53%",@"54%",@"55%",@"56%",@"57%",@"58%",@"59%",@"60%",@"61%",@"62%",@"63%",@"64%",@"65%",@"66%",@"67%",@"68%",@"69%",@"70%",@"71%",@"72%",@"73%",@"74%",@"75%",@"76%",@"77%",@"78%",@"79%",@"80%",@"81%",@"82%",@"83%",@"84%",@"85%",@"86%",@"87%",@"88%",@"89%",@"90%",@"91%",@"92%",@"93%",@"94%",@"95%",@"96%",@"97%",@"98%",@"99%",nil];
    
    
    // flag set for dot button
    flag=0;
    count=0;
    webserviceClass=[[WebserviceClass alloc] init];
    _strShape=[_shapePickerArray objectAtIndex:0];
    _strColor=[_colorPickerArray objectAtIndex:0];
    _strClarity=[_clarityPickerArray objectAtIndex:1];
    [_clarityPicker selectRow:1 inComponent:0 animated:YES];
    
    _LblDisplayValue.text=@"";
    //_strdiscount=[_DiscountPickerArray objectAtIndex:0];
    
    
   // UIPickerViewDelegate *delegate = _discountPicker.delegate;
  //  NSString *titleYouWant = [self pickerView:_discountPicker titleForRow:[_discountPicker selectedRowInComponent:0] forComponent:0];
    
    _strdiscount=[_DiscountPickerArray objectAtIndex:69];
    [_discountPicker selectRow:69 inComponent:0 animated:YES];
    //[self storeData];
    NSLog(@"shape array=%@",_shapePickerArray);
    
    _btnAvg.userInteractionEnabled=NO;
    
    self.screenName=@"Calculator";

    
    NSString *finalDate = [Constant getDateFromService];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormatter dateFromString:finalDate];
    NSLog(@"Actual truncated date : %@",[dateFormatter stringFromDate:date]);
    
    
    NSDate *dateFromLastUpdated=[dateFormatter dateFromString:[Constant getLastPriceUpdatedDate]]
    ;
    NSLog(@"Last updated: %@",[dateFormatter stringFromDate:dateFromLastUpdated]);
    
   
     if (!([dateFromLastUpdated compare:date]==NSOrderedDescending))
     {
         NSLog(@"If part");
         if (([dateFromLastUpdated compare:date]==NSOrderedSame))
         {
             NSLog(@"NSOrderedSame");
           
             if (dateFromLastUpdated==nil)
             {
                 [self getPriceList];
                 [self createDatabase];
                 
             }
         }else
         {
             NSLog(@"NSOrdered Ascending");
             [self getPriceList];
             [self createDatabase];
         }
     }else
     {
         NSLog(@"Else part");
     }
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    _scroll.contentSize=CGSizeMake(self.view.frame.size.width, 570);
    
}
//- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
//    UILabel* tView = (UILabel*)view;
//    if (!tView){
//        tView = [[UILabel alloc] init];
//        [tView setFont:[UIFont systemFontOfSize:12]];
//            }
//    
//    return tView;
//}

-(void)viewWillDisappear:(BOOL)animated{
   // [self deleteAllData];
}
#pragma mark - Picker View Data source
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{

    if(pickerView==_shapePicker)
    {
    return _shapePickerArray.count;
    }
    else if (pickerView == _colorPicker)
    {
        return _colorPickerArray.count;
    }
    else if (pickerView == _clarityPicker)
    {
        return _clarityPickerArray.count;
    }
    else
    {
        return _DiscountPickerArray.count;
    }
    
}
#pragma mark- Picker View Delegate

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
   // [myTextField setText:[pickerArray objectAtIndex:row]];
    
    if(pickerView==_shapePicker)
    {
       _strShape =[_shapePickerArray objectAtIndex:row];
        
    }
    else if (pickerView == _colorPicker)
    {
      _strColor=[_colorPickerArray objectAtIndex:row];
    }
    else if (pickerView == _clarityPicker)
    {
        _strClarity=[_clarityPickerArray objectAtIndex:row];
        
    }
    else
    {
        _strdiscount=[_DiscountPickerArray objectAtIndex:row];
    }

    
    [self searchClarity];
    
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if(pickerView==_shapePicker)
    {
        return [_shapePickerArray objectAtIndex:row];

    }
    else if (pickerView == _colorPicker)
    {
        return [_colorPickerArray objectAtIndex:row];

    }
    else if (pickerView == _clarityPicker)
    {
        return [_clarityPickerArray objectAtIndex:row];

    }
    else
        
        
        
    {
        return [_DiscountPickerArray objectAtIndex:row];

    }

}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 30;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    
    if(pickerView==_shapePicker)
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:17]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            //[tView setTextAlignment:UITextAlignmentLeft];
            
        }
        // Fill the label text here
        tView.text=[_shapePickerArray objectAtIndex:row];
        return tView;
        
    }
    else if (pickerView == _colorPicker)
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:17]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            //[tView setTextAlignment:UITextAlignmentLeft];
           
        }
        // Fill the label text here
        tView.text=[_colorPickerArray objectAtIndex:row];
        return tView;
        
    }
    else if (pickerView == _clarityPicker)
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:17]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            //[tView setTextAlignment:UITextAlignmentLeft];
          
        }
        // Fill the label text here
        tView.text=[_clarityPickerArray objectAtIndex:row];
        return tView;
        
    }
    else
    {
        UILabel* tView = (UILabel*)view;
        if (!tView)
        {
            tView = [[UILabel alloc] init];
            [tView setFont:[UIFont fontWithName:@"Helvetica" size:17]];
            [tView setTextAlignment:NSTextAlignmentCenter];
            
        }
        // Fill the label text here
        tView.text=[_DiscountPickerArray objectAtIndex:row];
        return tView;
        
    }
    
}
- (IBAction)btnSavedCalculationsClicked:(id)sender {
    SavedCalculations *SavedCalculationsVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"SavedCalculations"];
    [self.navigationController pushViewController:SavedCalculationsVC animated:YES];
}
- (IBAction)btnMenuClicked:(id)sender {
    SWRevealViewController *revealController = [self revealViewController];
    [revealController revealToggle:sender];
}

#pragma mark - IBAction For Calculator Keyboard

- (IBAction)btn9Clicked:(UIButton *)sender {
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    

    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
   sender.selected=NO;
    
   self.mainResult=@"";
    
    [self searchClarity];
    
    
}

- (IBAction)btn8Clicked:(UIButton *)sender {
  
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    
    
}

- (IBAction)btn7Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";

    [self searchClarity];
    
}

- (IBAction)btn6Clicked:(UIButton *)sender {
    
    
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    
}

- (IBAction)btn5Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    

}


- (IBAction)btn4Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    

}

- (IBAction)btn3Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    
}

- (IBAction)btn2Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    
}

- (IBAction)btn1Clicked:(UIButton *)sender {
   
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    
    [self searchClarity];
    

}

- (IBAction)btnZeroClicked:(UIButton *)sender {
    
    sender.selected=!sender.selected;
    
    self.mainResult=sender.titleLabel.text;
    
    
    if ([sender isSelected]) {
        
        if ([_LblDisplayValue.text isEqualToString:@""]) {
            
            _LblDisplayValue.text=self.mainResult;
        }
        else
        {
            _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
        }
    }
    else
    {
        _LblDisplayValue.text=@"";
    }
    
    sender.selected=NO;
    
    self.mainResult=@"";
    

    [self searchClarity];

}

- (IBAction)btnDotClicked:(UIButton *)sender {
 
    NSString *str=_LblDisplayValue.text;
    
    if ([str containsString:@"."]) {
    
    }
    else
    {
        sender.selected=!sender.selected;
        
        self.mainResult=sender.titleLabel.text;
        
        
        if ([sender isSelected]) {
            
            if ([_LblDisplayValue.text isEqualToString:@""]) {
                
                _LblDisplayValue.text=self.mainResult;
            }
            else
            {
                _LblDisplayValue.text=[_LblDisplayValue.text stringByAppendingString:self.mainResult];
            }
        }
        else
        {
            _LblDisplayValue.text=@"";
        }
        
        sender.selected=NO;
        
        self.mainResult=@"";
    }
    
}

- (IBAction)btnBackClicked:(id)sender {
    
        NSString * str = _LblDisplayValue.text;
        if ( [str length] > 0 )
            str = [str substringToIndex:[str length] - 1];
        _LblDisplayValue.text = str;

}
- (IBAction)btnResetClicked:(id)sender {
    _LblDisplayValue.text=@"";
    _lblListPrice.text=@"";
    _lblListPriceTotal.text=@"";
    _LblYourPrice.text=@"";
    _LblYourPriceTotal.text=@"";
    
}

- (IBAction)btnCompareClicked:(id)sender {
    
    Compare *comp=[[self storyboard]instantiateViewControllerWithIdentifier:@"Compare"];
    comp.strcaratValue=_LblDisplayValue.text;
    comp.strYourPrice=_LblYourPrice.text;
    comp.strYourPriceTotal=_LblYourPriceTotal.text;
    comp.Shape=_strShape;
    comp.Color=_strColor;
    comp.Clarity=_strClarity;
    comp.Discount=_strdiscount;
    
    [self.navigationController pushViewController:comp animated:YES];
    
}

- (IBAction)btnAvgClicked:(id)sender {
    
//    [UIView transitionWithView:self.storyTextView
//                      duration:0.5
//                       options:UIViewAnimationOptionTransitionCrossDissolve
//                    animations:^{
//                        [self.storyTextView setText:withStory.storyText];
//                    }
//                    completion:nil];
    
    _UIViewAllButtons.hidden=NO;
    CGRect newFrame = _UIViewAllButtons.frame;
    newFrame.size.width -= 320;
    
    [UIView animateWithDuration:2.2 animations:^(void){
       // _UIViewAllButtons.hidden=YES;
      _btn9.hidden=YES;
      _btn8.hidden=YES;
      _btn7.hidden=YES;
      _btn6.hidden=YES;
      _btn5.hidden=YES;
      _btn4.hidden=YES;
      _btn3.hidden=YES;
      _btn2.hidden=YES;
      _btn1.hidden=YES;
      _btnBack.hidden=YES;
      _btnZero.hidden=YES;
      _btnDot.hidden=YES;
      _btnReset.hidden=YES;
      _btnCompare.hidden=YES;
      _btnSearch.hidden=YES;
      _btnAvg.hidden=YES;

        _UIViewAllButtons.frame = newFrame;
      
//        [UIView animateWithDuration:1.2 animations:^{
//           _UIViewAllButtons.hidden=YES;
//       }];
        
    }];
    
 
}

- (IBAction)btnSearchClicked:(id)sender {
    
    FindDiamond *FindDiamondVC = [[self storyboard] instantiateViewControllerWithIdentifier:@"FindDiamond"];

    FindDiamondVC.strcaratValue=_LblDisplayValue.text;
    FindDiamondVC.strYourPrice=_LblYourPrice.text;
    FindDiamondVC.strYourPriceTotal=_LblYourPriceTotal.text;
    FindDiamondVC.Shape=_strShape;
    FindDiamondVC.Color=_strColor;
    FindDiamondVC.Clarity=_strClarity;
    FindDiamondVC.Discount=_strdiscount;

    
    [self.navigationController pushViewController:FindDiamondVC animated:YES];

}

#pragma mark - Create Databasse
-(void)createDatabase
{
    
    NSArray *dirPaths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSLog(@"dirPaths= %@",dirPaths);
    NSString *docDir=dirPaths[0];
    NSLog(@"docDir = %@",docDir);
    
    _databasePath=[[NSString alloc] initWithString:[docDir stringByAppendingPathComponent:@"CEVAHEER.db"]];
    
    NSLog(@"DatabasePath=%@",_databasePath);
    

    //create NSFileManager object
    
    NSFileManager *filemanager=[NSFileManager defaultManager];
    
    if ([filemanager fileExistsAtPath:_databasePath] == NO) {
        
        const char *dbPath=[_databasePath UTF8String];
        
        if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
            
            char *errrMsg;
            const char *sql_statement="CREATE TABLE IF NOT EXISTS  PriceList (ID INTEGER PRIMARY KEY AUTOINCREMENT,COLOR TEXT,SHAPE TEXT,CARAT_MIN_RANGE REAL,CARAT_MAX_RANGE REAL,FL TEXT,IF TEXT,VVS1 TEXT,VVS2 TEXT,VS1 TEXT,VS2 TEXT,SI1 TEXT,SI2 TEXT,SI3 TEXT,I1 TEXT,I2 TEXT,I3 TEXT)";
            
            
            if (sqlite3_exec(_DB, sql_statement, NULL,NULL, &errrMsg) != SQLITE_OK) {
                
               // [self showUIAlertWithMessage:@"Failed to Create TAble" andTitle:@"Error"];
                NSLog(@"Database created");
                
            }
            sqlite3_close(_DB);
        }
        else{
            //[self showUIAlertWithMessage:@"Failed to Open/create Table " andTitle:@"Error"];
        }
    }

}
-(void)storeData
{
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *string = [dateFormatter stringFromDate:[NSDate date]];
    NSLog(@"Date to set : %@",string);
    
    [Constant setLastPriceUpdatedDate:string];
    
    [self deleteAllData];
    
    
    
    sqlite3_stmt *statement = NULL;
    const char *dbPath=[_databasePath UTF8String];
    
    if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
        
    
        for (NSDictionary *result in _jsonArray) {
            
        NSString *insertSQL=[NSString stringWithFormat:@"INSERT INTO PriceList(COLOR,SHAPE,CARAT_MIN_RANGE,CARAT_MAX_RANGE,FL,IF,VVS1,VVS2,VS1,VS2,SI1,SI2,SI3,I1,I2,I3) VALUES (\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\",\"%@\")",[result objectForKey:@"Color"],[result objectForKey:@"Shape"],[result objectForKey:@"Range_lower"],[result objectForKey:@"Range_higher"],[result objectForKey:@"FL"],[result objectForKey:@"IF"],[result objectForKey:@"VVS1"],[result objectForKey:@"VVS2"],[result objectForKey:@"VS1"],[result objectForKey:@"VS2"],[result objectForKey:@"SI1"],[result objectForKey:@"SI2"],[result objectForKey:@"SI3"],[result objectForKey:@"I1"],[result objectForKey:@"I2"],[result objectForKey:@"I3"]];
        
        const char *insert_statement=[insertSQL UTF8String];
        
        sqlite3_prepare(_DB, insert_statement, -1, &statement, NULL);
        
        NSLog(@"state=%s",insert_statement);
        
        if (sqlite3_step(statement)== SQLITE_DONE) {
           // [self showUIAlertWithMessage:@"Employee added to the database" andTitle:@"Message"];
            
            
        }
        else{
           // [self showUIAlertWithMessage:@"Failed to Add Emp" andTitle:@"Error"];
        }
        
        }
        sqlite3_finalize(statement);
        sqlite3_close(_DB);
        
    }

}
-(void)fetchData
{
    sqlite3_stmt *statement;
    const char *dbPath=[_databasePath UTF8String];
    NSMutableSet *set=[[NSMutableSet alloc] init];

    
    if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
        
        NSString *insertSQL=[NSString stringWithFormat:@"SELECT *From  PriceList"];
        const char *query_statement=[insertSQL UTF8String];
        
        if (sqlite3_prepare(_DB, query_statement, -1, &statement, NULL) == SQLITE_OK) {
            
            while (sqlite3_step(statement) == SQLITE_ROW) {
            
                
                [set addObject:[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 1)]];
                NSString *COLOR=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 1)];
            
                 NSString *SHAPE=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 2)];
                
                 NSString *CARAT_MIN_RANGE=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 3)];
                
                 NSString *CARAT_MAX_RANGE=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 4)];
                
                 NSString *CLARITY_FL=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 5)];
                
                 NSString *CLARITY_IF=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 6)];
                
                 NSString *CLARITY_VVS1=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 7)];
                
                 NSString *CLARITY_VVS2=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 8)];
                
                 NSString *CLARITY_VS1=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 9)];
                
                 NSString *CLARITY_VS2=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 10)];
                
                 NSString *CLARITY_SI1=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 11)];
                
                 NSString *CLARITY_SI2=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 12)];
                
                 NSString *CLARITY_SI3=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 13)];
                
                 NSString *CLARITY_I1=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 14)];
                
                 NSString *CLARITY_I2=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 15)];
                
                 NSString *CLARITY_I3=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 16)];
                
                NSLog(@"COLOR=%@",COLOR);
                NSLog(@"SHAPE=%@",SHAPE);
                NSLog(@"CARAT_MIN_RANGE=%@",CARAT_MIN_RANGE);
                NSLog(@"CARAT_MAX_RANGE=%@",CARAT_MAX_RANGE);
                NSLog(@"CLARITY_FL=%@",CLARITY_FL);
                NSLog(@"CLARITY_IF=%@",CLARITY_IF);
                NSLog(@"CLARITY_VVS1=%@",CLARITY_VVS1);
                NSLog(@"CLARITY_VVS2=%@",CLARITY_VVS2);
                NSLog(@"CLARITY_VS1=%@",CLARITY_VS1);
                NSLog(@"CLARITY_VS2=%@",CLARITY_VS2);
                NSLog(@"CLARITY_SI1=%@",CLARITY_SI1);
                NSLog(@"CLARITY_SI2=%@",CLARITY_SI2);
                NSLog(@"CLARITY_SI3=%@",CLARITY_SI3);
                NSLog(@"CLARITY_I1=%@",CLARITY_I1);
                NSLog(@"CLARITY_I2=%@",CLARITY_I2);
                NSLog(@"CLARITY_I3=%@",CLARITY_I3);
                
                count++;
                NSLog(@"count =%d",count);
                
                
            }
            sqlite3_finalize(statement);
            sqlite3_close(_DB);
        }
    }

    NSLog(@"set values =%@",set);
}
-(void)searchClarity
{
    
    
    NSArray *dirPaths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSLog(@"dirPaths= %@",dirPaths);
    NSString *docDir=dirPaths[0];
    NSLog(@"docDir = %@",docDir);
    
    _databasePath=[[NSString alloc] initWithString:[docDir stringByAppendingPathComponent:@"CEVAHEER.db"]];
    
    sqlite3_stmt *statement;
    const char *dbPath=[_databasePath UTF8String];
    
    NSLog(@"%@",_strShape);
    NSLog(@"%@",_strClarity);
    NSLog(@"%@",_strColor);

    if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
        
//        NSString *insertSQL=[NSString stringWithFormat:@"SELECT %@ From  PriceList WHERE SHAPE=\"%@\"  AND COLOR=\"%@\" AND CARAT_MIN_RANGE<=\"%@\" AND CARAT_MAX_RANGE >=\"%@\"",_strClarity,_strShape,_strColor,_LblDisplayValue.text,_LblDisplayValue.text];
        
        NSString *insertSQL=[NSString stringWithFormat:@"SELECT %@ From  PriceList WHERE COLOR=\"%@\"  AND SHAPE=\"%@\" AND CARAT_MIN_RANGE<=\"%@\" AND CARAT_MAX_RANGE >=\"%@\"",_strClarity,_strColor,_strShape,_LblDisplayValue.text,_LblDisplayValue.text];

        
        
        const char *query_statement=[insertSQL UTF8String];
        
        
        NSLog(@"insertSQL=%@",insertSQL);
        
        if (sqlite3_prepare(_DB, query_statement, -1, &statement, NULL) == SQLITE_OK) {
            
            if (sqlite3_step(statement) == SQLITE_ROW) {
        
                
                _lblListPrice.text=[[NSString alloc] initWithUTF8String:(const char *) sqlite3_column_text(statement, 0)];
                
                NSLog(@"List Price %@",_lblListPrice.text);
                
                double value1=[_lblListPrice.text doubleValue];
                double value2=[_LblDisplayValue.text doubleValue];
                
                _lblListPriceTotal.text=[NSString stringWithFormat:@"%.0f",value1*value2];
            
                
                int value3=[_strdiscount intValue];
                double value4=(value1*value3)/100;
                double value5=value1+value4;
                _LblYourPrice.text = [NSString stringWithFormat:@"%.0f",value5];
                _LblYourPriceTotal.text = [NSString stringWithFormat:@"%.0f",value5*value2];
                
                NSLog(@"value3=%d",value3);
            }
            else
            {
                _lblListPrice.text=@"";
                _lblListPriceTotal.text=@"";
                _LblYourPrice.text=@"";
                _LblYourPriceTotal.text=@"";
                
            }
            sqlite3_finalize(statement);
            sqlite3_close(_DB);
        }
    }

}
-(void)deleteAllData
{
    const char *dbPath=[_databasePath UTF8String];
    
    char *errorMessage;

    if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
        
        NSString*query=[NSString stringWithFormat:@"DELETE from PriceList"];
        const char *query_statement=[query UTF8String];
        
        if (sqlite3_exec(_DB, query_statement, NULL, NULL, &errorMessage) == SQLITE_OK) {
            
             NSLog(@"deleted Cevaheer Table");
        }
        else{
              NSLog(@"not deleted Cevaheer Table");
        }
    }
    

}
#pragma mark Webservice Methods
-(void)getPriceList
{
   // http://webservice.cevaheer.com/api/CalculatePrice
    NSString* parameterString=[NSString stringWithFormat:@"%@",PRICE_LIST];
    
    [webserviceClass callServcieUsingRequestAndGET:parameterString :nil andDelegate:self andProgressHud:[[MBProgressHUD alloc] init] andViewController:self.view];

    NSLog(@"parameterString=%@",parameterString);
    
}

- (void)requestSucceeded:(NSString *)response
{
    
    self.view.userInteractionEnabled=YES;
    NSError *error;
    // NSLog(@"Response : %@",response);
    [SVProgressHUD dismiss];
    JSONUtility *objJSONUtility=[[JSONUtility alloc]initWithString:response error:&error];
    
    
}
- (void)requestFailed:(NSString *)response
{
    [SVProgressHUD dismiss];
    
    self.view.userInteractionEnabled=YES;
    
    //NSLog(@"requestFailed : %@",response);
}

#pragma mark Webservice Methods
-(void)sendResponse:(NSMutableData *)dataResponseArray
{
    NSError* error;
    json = [NSJSONSerialization
            JSONObjectWithData:dataResponseArray options:kNilOptions error:&error];
    
        
        if(json == nil)
        {
            // [constants_class showAlert:@"Error connecting server."];
        }
        else
        {
            
            Statuscode=[NSString stringWithFormat:@"%@",[json objectForKey:@"Statuscode"]];
            Message =[json objectForKey:@"Message"];
            
            if (![Statuscode isEqualToString:@"1"]) {
                
               // [self showMessage];
                
            }
            else
            {
                if (![json objectForKey:@"Result"]) {
                    
                   // [self showMessage];
                }
                else
                {
                    
                    NSDictionary *subDict= [json objectForKey:@"Result"];
                    _jsonArray = [subDict objectForKey:@"Price"];
                    
                    NSLog(@"_jsonArray=%@",_jsonArray);
                    NSLog(@"_jsonArray=%lu",(unsigned long)_jsonArray.count);
                    
                    [self storeData];
                    
                    
                    [self searchClarity];
                    
                  // [self fetchData];
                    

                    
                }
                
          }
     }
    

}
-(void)sendError :(NSError *) error
{
    [webserviceClass showAlert:[NSString stringWithFormat:@"%@",error.localizedDescription]];
}

- (IBAction)btnMessageClicked:(id)sender {
    Messages *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"Messages"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnHomeClicked:(id)sender {
    
    WelcomeViewController *WelcomeVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"WelcomeViewController"];
    [self.navigationController pushViewController:WelcomeVC animated:YES];

}

- (IBAction)btnMyListingClicked:(id)sender {
 
    MyListings *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MyListings"];
    [self.navigationController pushViewController:objVC animated:YES];

}

- (IBAction)btnMemberProfileClicked:(id)sender {
    
    MemberProfile *MemberProfileVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"MemberProfile"];
    [self.navigationController pushViewController:MemberProfileVC animated:YES];

}

- (IBAction)btnFindDiamondClicked:(id)sender {
    
   
    
    FindDiamond *objVC=[[self storyboard]instantiateViewControllerWithIdentifier:@"FindDiamond"];
    
    objVC.strcaratValue=_LblDisplayValue.text;
    objVC.strYourPrice=_LblYourPrice.text;
    objVC.strYourPriceTotal=_LblYourPriceTotal.text;
    objVC.Shape=_strShape;
    objVC.Color=_strColor;
    objVC.Clarity=_strClarity;
    objVC.Discount=_strdiscount;

    
    [self.navigationController pushViewController:objVC animated:YES];

}





@end
