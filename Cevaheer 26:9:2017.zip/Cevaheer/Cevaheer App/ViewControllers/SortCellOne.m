//
//  SortCellOne.m
//  Cevaheer App
//
//  Created by SMS on 11/01/17.
//  Copyright © 2017 Mobility Team. All rights reserved.
//

#import "SortCellOne.h"

@implementation SortCellOne

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnCancelClicked:(id)sender {
}
@end
