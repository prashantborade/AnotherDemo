//
//  NSString+AlertMessages.m
//  SharpTruth
//
//  Created by  on 7/22/16.
//
//

#import "NSString+AlertMessages.h"

@implementation NSString (AlertMessages)
+(NSString *)passwordDontMatch
{
    return @"Confirmed password does not match the New password";
}
+(NSString*)blankEmail
{
    return @"Email address required";
}
+(NSString*)blankNewEmail
{
    return @"New email address required";
}
+(NSString*)blankPassword
{
    return @"Please enter password";
}
+(NSString*)blankConfirmPassword
{
    return @"Please enter confirm password";
}
+(NSString*)invalidEmail
{
    return @"Please enter valid Email ID";
}
+(NSString*)invalidNewEmail
{
    return @"Please enter valid New Email ID";
}
+(NSString*)blankCurrentPassword
{
    return @"Please enter current password";
}
+(NSString*)blankNewPassword
{
    return @"Please enter new password";
}
+(NSString*)blankSubjectID
{
    return @"Please enter a subject";
}
+(NSString*)blankFirstName
{
    return @"Please enter first name";
}
+(NSString*)blankLastName
{
    return @"Please enter last name";
}
+(NSString*)blankConfirmEmail
{
    return @"Please enter confirm Email ID";
}
+(NSString*)invalidConfirmEmail
{
    return @"Please enter valid confirm Email ID";
}
+(NSString*)invalidPassword
{
    return @"Password format: minimum 4 and maximum 10 characters";
}
+(NSString*)reminderAdded
{
    return @"Reminder set";
}
+(NSString*)deleteConfirmation
{
    return @"Are you sure you want to delete your account?";
}
+(NSString *)singleWordAllowed
{
    return @"Only single word allowed";
}
+(NSString*)spaceNotAllowed
{
    return @"Blank space not allowed in password";
}
+(NSString*)acceptTerms
{
    return @"Please accept Terms & Policies";
}
+(NSString *)emailDontMatch
{
    return @"Confirmed email does not match the email";
}
+(NSString *)favouriteAdded
{
    return @"The verse has been added to your favourites";
}
+(NSString *)favouriteRemoved
{
    return @"This verse has been removed from your favourite";
}
+(NSString*)passwordReset
{
    return @"Password has been reset";
}
+(NSString*)accountDeleted
{
    return @"Your account has been deleted";
}
+(NSString *)passwordChanged
{
    return @"Password changed";
}
+(NSString *)emailChanged
{
    return @"Email ID changed";
}
+(NSString*)favouriteExists
{
    return @"The verse already exist in your favourites";
}
+(NSString *)favouriteAlreadyRemoved
{
    return @"This verse no longer exists in your favourites";
}
+(NSString*)invalidFirstName
{
    return @"Please enter valid first name";
}
+(NSString*)invalidLastName
{
    return @"Please enter valid last name";
}
+(NSString*)reminderAlreadyCleared
{
    return @"Reminder already has been removed";
}
+(NSString*)reminderCleared
{
    return @"Reminder removed";
}
+(NSString*)setReminderFromCalender
{
    return @"Set reminder from calendar";
}
+(NSString*)reminderAlreadySet
{
    return @"Reminder already set for this verse";
}
@end
