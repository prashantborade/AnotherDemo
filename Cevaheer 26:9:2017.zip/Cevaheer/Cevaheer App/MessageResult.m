//
//  MessageResult.m
//  Cevaheer App
//
//  Created by SMS Systems on 11/21/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "MessageResult.h"

@implementation MessageResult

@end
