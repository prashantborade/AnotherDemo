//
//  Constant.m
//  SharpTruth
//
//  Created by  on 7/27/16.
//
//

#import "Constant.h"

@implementation Constant

+(void)setIsAlreadyLogin:(BOOL)flag
{
    [[NSUserDefaults standardUserDefaults] setBool:flag forKey:isAlredyLogin];
}
+(BOOL)getIsAlreadyLogin
{
    return [[NSUserDefaults standardUserDefaults]boolForKey:isAlredyLogin];
}
+(void)setIsLogout:(BOOL)flag
{
    [[NSUserDefaults standardUserDefaults] setBool:flag forKey:isLogout];
}
+(BOOL)getIsLogout
{
    return [[NSUserDefaults standardUserDefaults]boolForKey:isLogout];
}
+(void)setSelectedDates:(NSArray*)dates
{
    [[NSUserDefaults standardUserDefaults]setObject:dates forKey:@"selectedDates"];
}
+(NSArray*)getSelectedDates
{
    return [[NSUserDefaults standardUserDefaults]valueForKey:@"selectedDates"];
}




+(void)setLastPriceUpdatedDate:(NSString *)str
{
             [[NSUserDefaults standardUserDefaults]setObject:str forKey:@"LAST_PRICE_UPDATED_DATE"];
}
+(NSString *)getLastPriceUpdatedDate
{
    return [[NSUserDefaults standardUserDefaults]valueForKey:@"LAST_PRICE_UPDATED_DATE"];
}


+(void)setDateFromService:(NSString *)str
{
    [[NSUserDefaults standardUserDefaults]setObject:str forKey:@"setDateFromService"];
}
+(NSString *)getDateFromService
{
    return [[NSUserDefaults standardUserDefaults]valueForKey:@"setDateFromService"];
    
}




@end
