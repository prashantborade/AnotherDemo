//
//  MessageResult.h
//  Cevaheer App
//
//  Created by SMS Systems on 11/21/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "JSONModel.h"

@interface MessageResult : JSONModel
@property (strong,nonatomic) NSString <Optional>*Body;
@property (strong,nonatomic) NSString <Optional>*FromEmail;
@property (strong,nonatomic) NSString <Optional>*MessageID;
@property (strong,nonatomic) NSString <Optional>*SentBy;
@property (strong,nonatomic) NSString <Optional>*SentBy1;
@property (strong,nonatomic) NSString <Optional>*SentDate;
@property (strong,nonatomic) NSString <Optional>*SentTo;
@property (strong,nonatomic) NSString <Optional>*Subject;
@property (strong,nonatomic) NSString <Optional>*ToEmail;


@end
