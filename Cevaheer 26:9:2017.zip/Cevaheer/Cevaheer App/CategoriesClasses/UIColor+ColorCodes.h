//Project name:-   Cevaheer App
//Class name:-     UIColor+ColorCodes.h
//Created by:-     Mobile Team
//Creation date:-  on 12/09/16.
//Usage:-          This class is going to be used hexdeciomal color



#import <UIKit/UIKit.h>

@interface UIColor (ColorCodes)


+ (UIColor *) colorWithHexString: (NSString *) hexString;
@end
