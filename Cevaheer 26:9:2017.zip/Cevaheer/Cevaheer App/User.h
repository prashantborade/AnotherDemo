//
//  User.h
//  Cevaheer App
//
//  Created by SMS Systems on 11/22/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "JSONModel.h"

@interface User : JSONModel
@property (strong,nonatomic) NSString <Optional>*CompanyName;
@property (strong,nonatomic) NSString <Optional>*Email;
@property (strong,nonatomic) NSString <Optional>*UserId;

@property (strong,nonatomic) NSString <Optional>*AdditionalAddress;
@property (strong,nonatomic) NSString <Optional>*Address;
@property (strong,nonatomic) NSString <Optional>*BusinessPhone;

@property (strong,nonatomic) NSString <Optional>*Buyrequestcount;
@property (strong,nonatomic) NSString <Optional>*CityID;
@property (strong,nonatomic) NSString <Optional>*CityName;

@property (strong,nonatomic) NSString <Optional>*CountryName;
@property (strong,nonatomic) NSString <Optional>*CreatedOn;
@property (strong,nonatomic) NSString <Optional>*Dimondlistingcount;

@property (strong,nonatomic) NSString <Optional>*FirstName;
@property (strong,nonatomic) NSString <Optional>*IsActive;
@property (strong,nonatomic) NSString <Optional>*IsDelete;

@property (strong,nonatomic) NSString <Optional>*IsJeweler;
@property (strong,nonatomic) NSString <Optional>*LastName;
@property (strong,nonatomic) NSString <Optional>*MembershipPackageID;

@property (strong,nonatomic) NSString <Optional>*MobileNumber;
@property (strong,nonatomic) NSString <Optional>*Password;
@property (strong,nonatomic) NSString <Optional>*StateID;

@property (strong,nonatomic) NSString <Optional>*StateName
;
@property (strong,nonatomic) NSString <Optional>*TypeOfBusiness;
@property (strong,nonatomic) NSString <Optional>*UserID;

@property (strong,nonatomic) NSString <Optional>*ValidFrom;
@property (strong,nonatomic) NSString <Optional>*ValidTo;
@property (strong,nonatomic) NSString <Optional>*Website;
@property (strong,nonatomic) NSString <Optional>*ZipCode;



@end
