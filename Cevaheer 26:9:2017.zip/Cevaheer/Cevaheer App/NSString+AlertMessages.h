//
//  NSString+AlertMessages.h
//  SharpTruth
//
//  Created by  on 7/22/16.
//
//

#import <Foundation/Foundation.h>

@interface NSString (AlertMessages)
+(NSString*)passwordDontMatch;
+(NSString*)blankEmail;
+(NSString*)blankPassword;
+(NSString*)blankConfirmPassword;
+(NSString*)invalidEmail;
+(NSString*)blankCurrentPassword;
+(NSString*)blankNewPassword;
+(NSString*)blankSubjectID;
+(NSString*)blankFirstName;
+(NSString*)blankLastName;
+(NSString*)blankConfirmEmail;
+(NSString*)invalidConfirmEmail;
+(NSString*)invalidPassword;
+(NSString*)reminderAdded;
+(NSString*)deleteConfirmation;
+(NSString*)singleWordAllowed;
+(NSString*)spaceNotAllowed;
+(NSString*)acceptTerms;
+(NSString*)emailDontMatch;
+(NSString*)favouriteAdded;
+(NSString*)favouriteRemoved;
+(NSString*)passwordReset;
+(NSString*)accountDeleted;
+(NSString*)passwordChanged;
+(NSString*)emailChanged;
+(NSString*)favouriteExists;
+(NSString*)favouriteAlreadyRemoved;
+(NSString*)invalidFirstName;
+(NSString*)invalidLastName;
+(NSString*)reminderAlreadySet;
+(NSString*)reminderAlreadyCleared;
+(NSString*)reminderCleared;
+(NSString*)setReminderFromCalender;
+(NSString*)invalidNewEmail;
+(NSString*)blankNewEmail;
@end
