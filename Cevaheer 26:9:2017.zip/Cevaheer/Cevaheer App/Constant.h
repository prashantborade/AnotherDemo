//
//  Constant.h
//  SharpTruth
//
//  Created by  on 7/27/16.
//
//

#import <Foundation/Foundation.h>

@interface Constant : NSObject
+(void)setIsAlreadyLogin:(BOOL)flag;
+(BOOL)getIsAlreadyLogin;
+(void)setIsLogout:(BOOL)flag;
+(BOOL)getIsLogout;
+(void)setSelectedDates:(NSArray*)dates;
+(NSArray*)getSelectedDates;

+(void)setLastPriceUpdatedDate:(NSString *)str;
+(NSString *)getLastPriceUpdatedDate;


+(void)setDateFromService:(NSString *)str;
+(NSString *)getDateFromService;


@end
