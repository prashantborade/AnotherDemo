//
//  WebServices.h
//  WeddSource
//
//  Created by appsplanet on 10/31/15.
//  Copyright (c) 2015 AppsPlanet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) //1

@interface WebServices : NSObject
{
    NSMutableData * jsonData;
    NSMutableDictionary * jsonDictionary;
}
@property(nonatomic, strong) UIWindow *window;
@property(nonatomic,retain)NSDictionary *responseDict;

//+ (NSString *)getUrl;
+(void)getDataFromServer:(SEL)strSelector target:(id)class withParameter:(NSString *)parameter;
//+(void)getDataFromServersync:(SEL)strSelector target:(id)class withParameter:(NSString *)parameter;
@end
