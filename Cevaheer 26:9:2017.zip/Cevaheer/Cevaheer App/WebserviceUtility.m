//
//  WebserviceUtility.m
//  DDEBBIE passenger
//
//  Created by Admin on 19/02/16.
//  Copyright © 2016 appsplanet. All rights reserved.
//

#import "WebserviceUtility.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"


@implementation WebserviceUtility

//DataParameter *dataVC;
@synthesize delegate;
@synthesize callback, errorCallback;



- (void)performPostRequestWithString:(NSString *)string stringDictionary:(NSDictionary *)stringParam dataDictionary:(NSDictionary *)dataDictionary delegate:(id)requestDelegate requestSelector:(SEL)requestSelector errorSelector:(SEL)errorSelector auth:(BOOL)authorization reqType:(NSString*)type
{
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    if (internetStatus != NotReachable) {
        //my web-dependent code
        
        localCopy = self;
        
        self.delegate = requestDelegate;
        self.callback = requestSelector;
        self.errorCallback = errorSelector;
        
        NSURL *url;
                    //url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",appBaseURL,string]];
        //NSString* parameterString=[NSString stringWithFormat:@"%@username=%@&password=%@",LOGIN_URL,_userNameOutlet.text,_passwordOutlet.text];
 
        url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",appBaseURL,string]];
        if ([type isEqualToString:@"GET"])
        {
            getRequest=[[ASIHTTPRequest alloc]initWithURL:url];
            [getRequest setDelegate:self];
            [getRequest setRequestMethod:type];
            
            [getRequest addRequestHeader:@"Content-Type" value:@"application/json"];
            [getRequest addRequestHeader:@"UserName" value:@"cevaheer"];
            [getRequest addRequestHeader:@"Password" value:@"cevaheer@!@#"];
            [getRequest setTimeOutSeconds:15.0];
            getRequest.shouldAttemptPersistentConnection = NO;
            [getRequest startAsynchronous];
        }
        else{
            postRequest = [[ASIFormDataRequest alloc] initWithURL:url];
            [postRequest setDelegate:self];
            [postRequest setRequestMethod:type];
            
            [postRequest addRequestHeader:@"Content-Type" value:@"application/json"];
            [postRequest addRequestHeader:@"UserName" value:@"cevaheer"];
            [postRequest addRequestHeader:@"Password" value:@"cevaheer@!@#"];
            //        if (stringParam)
            //        {
            //            //NSString *postString=[NSString stringWithFormat:@"%@",[JsonUtils getJSONfromDictinory:stringDictionary]];
            //
            //
            //            NSString *postString=[NSString stringWithFormat:@"%@",[JsonUtils getJSONfromDictinory:stringParam]];
            //            NSLog(@"%@",postString);
            //            NSArray *allKeys=[stringParam allKeys];
            //            NSArray *allValues=[stringParam allValues];
            //            for (int i=0; i<stringParam.count; i++)
            //            {
            //                [postRequest addPostValue:[allValues objectAtIndex:i] forKey:[allKeys objectAtIndex:i]];
            //            }
            //            //[postRequest addPostValue:@"3" forKey:@"member_id"];
            //           // [postRequest setPostBody:[NSMutableData dataWithData:[postString  dataUsingEncoding:NSUTF8StringEncoding]]];
            //        }
            [postRequest setTimeOutSeconds:15.0];
            postRequest.shouldAttemptPersistentConnection = NO;
            [postRequest startAsynchronous];

        }
        
        
        
        
        
    }
    else {
        //there-is-no-connection warning
        UIView *view=[[[[UIApplication sharedApplication] keyWindow] subviews] lastObject];
        view.userInteractionEnabled=YES;
        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"Please check network connection.",nil)];
    }


    
}

- (void)performPostRequestForURL:(NSString *)string stringDictionary:(NSDictionary *)stringDictionary dataDictionary:(NSDictionary *)dataDictionary delegate:(id)requestDelegate requestSelector:(SEL)requestSelector errorSelector:(SEL)errorSelector auth:(BOOL)authorization reqType:(NSString*)type
{
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    if (internetStatus != NotReachable) {
        //my web-dependent code
        
        localCopy = self;
        
        self.delegate = requestDelegate;
        self.callback = requestSelector;
        self.errorCallback = errorSelector;
        
        NSURL *url;
        
            url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",appBaseURL,string]];        
        
        postRequest = [ASIFormDataRequest requestWithURL:url];
        [postRequest setDelegate:self];
        [postRequest setRequestMethod:type];
        [postRequest addRequestHeader:@"Content-Type" value:@"application/json"];
//        if (authorization)
//        {
//            NSLog(@"Token : %@",[Constant getAPIToken]);
//            [postRequest addRequestHeader:@"Authorization" value:[Constant getAPIToken]];
//        }
        
        if (stringDictionary && [type isEqualToString:@"POST"])
        {
            NSString *postString=[NSString stringWithFormat:@"%@",[JsonUtils getJSONfromDictinory:stringDictionary]];
                        [postRequest setPostBody:[NSMutableData dataWithData:[postString  dataUsingEncoding:NSUTF8StringEncoding]]];
        }
        
        
        [postRequest setTimeOutSeconds:10.0];
        postRequest.shouldAttemptPersistentConnection = NO;
        [postRequest startAsynchronous];
        
    }
    else {
        //there-is-no-connection warning
        [SVProgressHUD showErrorWithStatus:@"Network Failure"];
    }
    
    
    
}

#pragma mark - ASIHTTPRequest Delegate Implementation

- (void)requestFinished:(ASIHTTPRequest *)crequest {
    NSString *status = [crequest responseString];
    
    if (self.delegate && self.callback) {
        if([self.delegate respondsToSelector:self.callback])
            [self.delegate performSelectorOnMainThread:self.callback withObject:status waitUntilDone:YES];
        else
            NSLog(@"No response from delegate");
    }
    localCopy = nil;
}
- (void)requestFailed:(ASIHTTPRequest *)crequest {
    if (self.delegate && self.errorCallback) {
        if([self.delegate respondsToSelector:self.errorCallback])
            [self.delegate performSelectorOnMainThread:self.errorCallback withObject:crequest.error waitUntilDone:YES];
        else
            NSLog(@"No response from delegate");
    }
    localCopy = nil;
}

@end
