//
//  Result.m
//  Cevaheer App
//
//  Created by   on 28/09/16.
//  Copyright © 2016 Mobility Team. All rights reserved.
//

#import "Result.h"

@implementation Result

@end
