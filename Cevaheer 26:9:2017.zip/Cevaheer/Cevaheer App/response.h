//
//  response.h
//  Larvik By
//
//  Created by AppsPlanet on 18/06/16.
//  Copyright © 2016 AppsPlanet. All rights reserved.
//

#import "JSONModel.h"

@interface response : JSONModel
@property (strong,nonatomic) NSString <Optional>*city;
@property (strong,nonatomic) NSString <Optional>*token;
@property (strong,nonatomic) NSString <Optional>*first_name;
@property (strong,nonatomic) NSString <Optional>*last_name;
@property (strong,nonatomic) NSString <Optional>*address;
@property (strong,nonatomic) NSString <Optional>*postcode;
@property (strong,nonatomic) NSString <Optional>*country;
@property (strong,nonatomic) NSString <Optional>*gender;
@property (strong,nonatomic) NSString <Optional>*created_at;
@property (strong,nonatomic) NSString <Optional>*updated_at;
@property (strong,nonatomic) NSString <Optional>*email;
@property (strong,nonatomic) NSString <Optional>*telephone;
@property (strong,nonatomic) NSString <Optional>*is_verified;
@property(strong,nonatomic)NSString <Optional>*reset_password_token;
@property(strong,nonatomic)NSString <Optional>*tenant_id;
@property(strong,nonatomic)NSString <Optional>*tenant_name;
@property(strong,nonatomic)NSString <Optional>*tenant_country;
@property(strong,nonatomic)NSString <Optional>*tenant_city;
@property(strong,nonatomic)NSString <Optional>*tenant_package_ios;
@property(strong,nonatomic)NSString <Optional>*tenant_package_android;
@property(strong,nonatomic)NSString <Optional>*tenant_center_longitude;
@property(strong,nonatomic)NSString <Optional>*tenant_center_lattitude;
@property(strong,nonatomic)NSString <Optional>*tenant_gps_off_distance;
@property(strong,nonatomic)NSString <Optional>*tenant_gps_on_distance;
@property(strong,nonatomic)NSString <Optional>*tenant_base_url;
@property(strong,nonatomic)NSString <Optional>*is_new_user;
@property(strong,nonatomic)NSString <Optional>*otp_sent;
@property(strong,nonatomic)NSString<Optional>*encrypted_date_of_birth;
@end
